# FlowSync - SaaS Landing Page Template

A modern, professional SaaS landing page template built with Next.js 14 and Tailwind CSS. Perfect for startups and software companies looking to convert visitors into customers.

![FlowSync Template Preview](https://placeholder.com/preview.png)

## Features

- **Modern Design** - Clean, professional design with indigo/purple gradient theme
- **Fully Responsive** - Mobile-first approach, looks great on all devices
- **Dark Mode** - Built-in dark mode support via Tailwind CSS
- **Fast Performance** - Optimized for Core Web Vitals and SEO
- **TypeScript** - Full type safety throughout the codebase
- **Easy to Customize** - Well-organized code with clear component structure
- **SEO Optimized** - Metadata, semantic HTML, and structured content

## Tech Stack

- [Next.js 14](https://nextjs.org/) - React framework
- [Tailwind CSS 3.4](https://tailwindcss.com/) - Utility-first CSS framework
- [TypeScript 5](https://www.typescriptlang.org/) - Type-safe JavaScript
- [Lucide React](https://lucide.dev/) - Beautiful, consistent icons

## Getting Started

### Prerequisites

- Node.js 18.17 or later
- npm, yarn, or pnpm

### Installation

1. Clone or download this template

2. Install dependencies:

```bash
npm install
# or
yarn install
# or
pnpm install
```

3. Start the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Customization Guide

### Branding

#### Logo and Name

1. **Header Logo**: Edit `src/components/Header.tsx` to change the logo icon and brand name
2. **Footer Logo**: Edit `src/components/Footer.tsx` to update the footer branding
3. **Metadata**: Edit `src/app/layout.tsx` to update the site title and description

#### Colors

The template uses a custom indigo/purple gradient theme. To customize:

1. **Primary Colors**: Edit `tailwind.config.js` to change the color palette
2. **Gradient**: Update the gradient classes in `src/app/globals.css`:
   ```css
   .gradient-bg {
     @apply bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500;
   }
   ```

### Content Sections

#### Hero Section

Edit `src/app/page.tsx` and modify the hero section:
- Change the headline and subheadline
- Update CTA button text and links
- Modify the trust badges

#### Features

Update the `features` array in `src/app/page.tsx`:
```typescript
const features = [
  {
    icon: Zap, // Import from lucide-react
    title: 'Your Feature Title',
    description: 'Your feature description',
  },
  // Add more features...
]
```

#### Pricing

Modify the `pricing` array to update plans:
```typescript
const pricing = [
  {
    name: 'Starter',
    price: '29', // Price in euros
    description: 'Plan description',
    features: ['Feature 1', 'Feature 2', ...],
    cta: 'Get Started',
    popular: false, // Set to true for highlighted plan
  },
  // Add more plans...
]
```

#### Testimonials

Update the `testimonials` array:
```typescript
const testimonials = [
  {
    name: 'John Doe',
    role: 'CTO at Company',
    content: 'Your testimonial content here...',
    rating: 5, // 1-5 stars
  },
  // Add more testimonials...
]
```

#### FAQ

Modify the `faqs` array to update questions and answers:
```typescript
const faqs = [
  {
    question: 'Your question here?',
    answer: 'Your answer here...',
  },
  // Add more FAQs...
]
```

### Adding New Sections

1. Create a new component in `src/components/` (optional)
2. Add the section to `src/app/page.tsx`
3. Use the existing section patterns for consistency

### Dark Mode

Dark mode is built-in and toggles automatically based on user preference. To customize:

1. Modify dark mode classes in components (e.g., `dark:bg-gray-900`)
2. Update the base styles in `src/app/globals.css`

### Navigation

Edit the navigation links in `src/components/Header.tsx`:
```typescript
const navLinks = [
  { href: '#features', label: 'Features' },
  { href: '#pricing', label: 'Pricing' },
  { href: '#testimonials', label: 'Testimonials' },
  // Add more links...
]
```

## Project Structure

```
saas-landing/
├── src/
│   ├── app/
│   │   ├── globals.css      # Global styles and Tailwind imports
│   │   ├── layout.tsx       # Root layout with metadata
│   │   └── page.tsx         # Main landing page
│   └── components/
│       ├── Header.tsx       # Sticky header with navigation
│       └── Footer.tsx       # Footer with links and social
├── public/                   # Static assets
├── tailwind.config.js       # Tailwind configuration
├── tsconfig.json            # TypeScript configuration
├── next.config.js           # Next.js configuration
├── postcss.config.js        # PostCSS configuration
└── package.json             # Dependencies and scripts
```

## Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run lint` - Run ESLint

## Deployment

### Vercel (Recommended)

```bash
npm i -g vercel
vercel
```

### Other Platforms

This is a standard Next.js application and can be deployed anywhere that supports Node.js:
- Netlify
- AWS Amplify
- DigitalOcean App Platform
- Self-hosted

## Support

For questions, issues, or customization requests:
- Email: support@example.com
- Documentation: [docs.example.com](https://docs.example.com)

## License

This template is licensed for personal and commercial use. See LICENSE file for details.

---

**Made with passion for the developer community.**
