'use client'

import Link from 'next/link'
import { useState } from 'react'
import {
  Zap, Shield, BarChart3, Globe, Users, Clock, ChevronDown, ArrowRight, Check, Star
} from 'lucide-react'

const features = [
  {
    icon: Zap,
    title: 'Lightning Fast',
    description: 'Built on edge infrastructure for instant page loads and real-time collaboration across your team.',
  },
  {
    icon: Shield,
    title: 'Enterprise Security',
    description: 'SOC 2 compliant with end-to-end encryption, SSO, and advanced access controls to keep your data safe.',
  },
  {
    icon: BarChart3,
    title: 'Advanced Analytics',
    description: 'Deep insights into team performance, project timelines, and resource allocation with custom dashboards.',
  },
  {
    icon: Globe,
    title: 'Global CDN',
    description: 'Deploy worldwide with our global edge network. Your team gets the same fast experience everywhere.',
  },
  {
    icon: Users,
    title: 'Team Collaboration',
    description: 'Real-time editing, comments, and approvals. Keep everyone aligned without the meeting overload.',
  },
  {
    icon: Clock,
    title: 'Time Saving',
    description: 'Automate repetitive tasks and streamline workflows. Teams save an average of 12 hours per week.',
  },
]

const pricing = [
  {
    name: 'Starter',
    price: '29',
    description: 'Perfect for small teams getting started',
    features: ['Up to 5 team members', '10GB storage', 'Basic analytics', 'Email support', 'API access'],
    cta: 'Start Free Trial',
    popular: false,
  },
  {
    name: 'Pro',
    price: '79',
    description: 'For growing teams that need more power',
    features: ['Up to 25 team members', '100GB storage', 'Advanced analytics', 'Priority support', 'Custom integrations', 'SSO authentication'],
    cta: 'Start Free Trial',
    popular: true,
  },
  {
    name: 'Enterprise',
    price: '199',
    description: 'For organizations that need it all',
    features: ['Unlimited team members', 'Unlimited storage', 'Custom analytics', '24/7 dedicated support', 'Custom integrations', 'SSO & SCIM', 'SLA guarantee', 'Dedicated account manager'],
    cta: 'Contact Sales',
    popular: false,
  },
]

const testimonials = [
  {
    name: 'Sarah Chen',
    role: 'CTO at TechFlow',
    content: 'FlowSync transformed how our engineering team ships products. We\'ve cut our release cycle by 40% and the team morale has never been better.',
    rating: 5,
  },
  {
    name: 'Marcus Johnson',
    role: 'Product Lead at ScaleUp',
    content: 'The analytics dashboard alone is worth the price. We finally have visibility into our entire development pipeline without pulling data from 5 different tools.',
    rating: 5,
  },
  {
    name: 'Elena Rodriguez',
    role: 'VP Engineering at DataSync',
    content: 'We evaluated every tool on the market. FlowSync is the only one that actually delivered on its promises. Our team adopted it in under a week.',
    rating: 5,
  },
]

const faqs = [
  {
    question: 'How does the 14-day free trial work?',
    answer: 'Start using FlowSync immediately with full access to all features in your chosen plan. No credit card required. At the end of 14 days, choose to upgrade or continue with our free tier.',
  },
  {
    question: 'Can I change my plan later?',
    answer: 'Absolutely. Upgrade or downgrade at any time from your account settings. Changes take effect immediately, and we\'ll prorate any payments.',
  },
  {
    question: 'Is my data secure?',
    answer: 'Yes. We\'re SOC 2 Type II certified with end-to-end encryption. Your data is stored in secure, redundant data centers with 99.99% uptime SLA.',
  },
  {
    question: 'Do you offer discounts for nonprofits or education?',
    answer: 'Yes! We offer 50% off for verified nonprofits and educational institutions. Contact our sales team with your organization details.',
  },
  {
    question: 'What integrations do you support?',
    answer: 'We integrate with 100+ tools including Slack, GitHub, Jira, Linear, Notion, and more. Pro and Enterprise plans also support custom API integrations.',
  },
]

function FAQItem({ question, answer }: { question: string; answer: string }) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="border-b border-gray-200 dark:border-gray-800">
      <button
        type="button"
        className="w-full flex items-center justify-between py-5 text-left"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="text-base font-medium text-gray-900 dark:text-white">{question}</span>
        <ChevronDown
          size={20}
          className={`text-gray-500 transition-transform duration-200 ${
            isOpen ? 'rotate-180' : ''
          }`}
        />
      </button>
      {isOpen && (
        <div className="pb-5">
          <p className="text-gray-600 dark:text-gray-400">{answer}</p>
        </div>
      )}
    </div>
  )
}

export default function Home() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 sm:pt-40 sm:pb-24 overflow-hidden">
        <div className="absolute inset-0 gradient-bg-subtle" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-300/20 dark:bg-indigo-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-300/20 dark:bg-purple-500/10 rounded-full blur-3xl" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-100 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 text-sm font-medium mb-8">
            <Star size={14} className="fill-current" />
            <span>Trusted by 10,000+ teams worldwide</span>
          </div>
          
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6">
            <span className="text-gray-900 dark:text-white">Ship faster with </span>
            <span className="gradient-text">FlowSync</span>
          </h1>
          
          <p className="text-lg sm:text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto mb-10">
            The all-in-one platform that helps teams collaborate, automate workflows, and deliver products faster. No more context switching.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="#"
              className="inline-flex items-center justify-center gap-2 px-8 py-3.5 text-base font-medium text-white gradient-bg rounded-xl hover:opacity-90 transition-all shadow-xl shadow-indigo-500/25 hover:shadow-indigo-500/40"
            >
              Start Free Trial
              <ArrowRight size={18} />
            </Link>
            <Link
              href="#"
              className="inline-flex items-center justify-center gap-2 px-8 py-3.5 text-base font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 rounded-xl border border-gray-300 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition-all"
            >
              Watch Demo
            </Link>
          </div>
          
          <div className="mt-16 flex flex-col sm:flex-row items-center justify-center gap-8 text-sm text-gray-500 dark:text-gray-400">
            <div className="flex items-center gap-2">
              <Check size={16} className="text-green-500" />
              <span>No credit card required</span>
            </div>
            <div className="flex items-center gap-2">
              <Check size={16} className="text-green-500" />
              <span>14-day free trial</span>
            </div>
            <div className="flex items-center gap-2">
              <Check size={16} className="text-green-500" />
              <span>Cancel anytime</span>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Everything you need to ship faster
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              Powerful features designed to help your team work smarter, not harder. Built for modern development workflows.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature) => (
              <div
                key={feature.title}
                className="group p-8 rounded-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 hover:border-indigo-300 dark:hover:border-indigo-700 hover:shadow-xl hover:shadow-indigo-500/5 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl gradient-bg flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300">
                  <feature.icon size={24} className="text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 sm:py-24 gradient-bg-subtle">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Simple, transparent pricing
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              No hidden fees. No surprises. Choose the plan that fits your team and scale as you grow.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {pricing.map((plan) => (
              <div
                key={plan.name}
                className={`relative flex flex-col p-8 rounded-2xl bg-white dark:bg-gray-900 border ${
                  plan.popular
                    ? 'border-indigo-500 shadow-xl shadow-indigo-500/10 scale-[1.02]'
                    : 'border-gray-200 dark:border-gray-800'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 gradient-bg text-white text-sm font-medium rounded-full">
                    Most Popular
                  </div>
                )}
                
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">{plan.name}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{plan.description}</p>
                
                <div className="mt-6 mb-8">
                  <span className="text-4xl font-bold text-gray-900 dark:text-white">€{plan.price}</span>
                  <span className="text-gray-500 dark:text-gray-400">/month</span>
                </div>
                
                <ul className="space-y-3 mb-8 flex-1">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-3">
                      <Check size={18} className="text-indigo-500 shrink-0 mt-0.5" />
                      <span className="text-sm text-gray-600 dark:text-gray-400">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Link
                  href="#"
                  className={`inline-flex items-center justify-center px-6 py-3 text-sm font-medium rounded-xl transition-all ${
                    plan.popular
                      ? 'gradient-bg text-white hover:opacity-90 shadow-lg shadow-indigo-500/25'
                      : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-gray-700'
                  }`}
                >
                  {plan.cta}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-20 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Loved by teams worldwide
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              See what our customers have to say about transforming their workflows with FlowSync.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial) => (
              <div
                key={testimonial.name}
                className="p-8 rounded-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 hover:shadow-xl transition-shadow duration-300"
              >
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <Star key={i} size={16} className="text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 dark:text-gray-400 mb-6">&ldquo;{testimonial.content}&rdquo;</p>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full gradient-bg flex items-center justify-center text-white font-semibold">
                    {testimonial.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <div className="font-medium text-gray-900 dark:text-white">{testimonial.name}</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">{testimonial.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20 sm:py-24 bg-gray-50 dark:bg-gray-900/50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Frequently asked questions
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400">
              Everything you need to know about FlowSync. Can&apos;t find an answer? Contact our support team.
            </p>
          </div>
          
          <div className="space-y-0">
            {faqs.map((faq) => (
              <FAQItem key={faq.question} question={faq.question} answer={faq.answer} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 sm:py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative rounded-3xl overflow-hidden gradient-bg p-12 sm:p-16 text-center">
            <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10" />
            <div className="relative">
              <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
                Ready to transform your workflow?
              </h2>
              <p className="text-lg text-white/80 max-w-xl mx-auto mb-8">
                Join 10,000+ teams already using FlowSync to ship faster. Start your free trial today.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link
                  href="#"
                  className="inline-flex items-center justify-center gap-2 px-8 py-3.5 text-base font-medium text-indigo-600 bg-white rounded-xl hover:bg-gray-50 transition-all shadow-xl"
                >
                  Start Free Trial
                  <ArrowRight size={18} />
                </Link>
                <Link
                  href="#"
                  className="inline-flex items-center justify-center gap-2 px-8 py-3.5 text-base font-medium text-white border-2 border-white/30 rounded-xl hover:bg-white/10 transition-all"
                >
                  Talk to Sales
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
