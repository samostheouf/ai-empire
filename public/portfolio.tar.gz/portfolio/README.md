# Portfolio Template

A professional, modern developer portfolio template built with Next.js 14 and Tailwind CSS. Features a stunning dark theme, smooth animations, and a fully responsive design.

## Features

- **Modern Stack**: Built with Next.js 14, TypeScript, and Tailwind CSS
- **Dark Theme**: Elegant dark design with accent colors
- **Responsive**: Fully responsive on all devices
- **Animations**: Smooth scroll and hover animations
- **Components**: Reusable React components
- **Contact Form**: Working contact form with validation
- **SEO Optimized**: Built-in metadata and OpenGraph tags

## Quick Start

### Prerequisites

- Node.js 18+ 
- npm, yarn, or pnpm

### Installation

```bash
# Clone or download the template
cd portfolio-template

# Install dependencies
npm install

# Run development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) to view your portfolio.

## Customization

### Personal Information

Edit `src/app/page.tsx` to update:
- Your name and bio
- Skills and technologies
- Work experience
- Featured projects

Edit `src/app/layout.tsx` to update:
- Page title and metadata
- SEO description
- Social media links

### Projects

Edit `src/app/projects/page.tsx` to add or modify projects:

```typescript
const projects = [
  {
    title: 'Your Project',
    description: 'Project description',
    tags: ['React', 'TypeScript'],
    github: 'https://github.com/your-repo',
    live: 'https://your-project.com',
    category: 'Web App', // Web App, Mobile, Open Source, Design
  },
];
```

### Contact Form

The contact form is in `src/app/contact/page.tsx`. To connect it to a real backend:

1. Set up your API endpoint
2. Update the `handleSubmit` function
3. Add environment variables for your API URL

### Styling

- Colors: Edit `tailwind.config.js` to change the color scheme
- Fonts: Modify the Google Fonts import in `src/app/globals.css`
- Animations: Customize keyframes in `tailwind.config.js`

## Project Structure

```
portfolio-template/
├── src/
│   ├── app/
│   │   ├── layout.tsx      # Root layout
│   │   ├── page.tsx        # Homepage
│   │   ├── globals.css     # Global styles
│   │   ├── projects/
│   │   │   └── page.tsx    # Projects page
│   │   └── contact/
│   │       └── page.tsx    # Contact page
│   └── components/
│       ├── Header.tsx      # Navigation header
│       ├── Footer.tsx      # Footer
│       ├── ProjectCard.tsx # Project card
│       └── SkillBadge.tsx  # Skill badge
├── public/                 # Static assets
├── package.json
├── tailwind.config.js
├── tsconfig.json
└── README.md
```

## Deployment

### Vercel (Recommended)

1. Push to GitHub
2. Import project in Vercel
3. Deploy

```bash
# Or deploy via CLI
npx vercel
```

### Other Platforms

Build the project:

```bash
npm run build
```

The `out` directory contains the static export.

## Custom Components

### SkillBadge

```tsx
<SkillBadge name="React" color="bg-cyan-500/20 text-cyan-300 border-cyan-500/30" />
```

### ProjectCard

```tsx
<ProjectCard
  title="My Project"
  description="Description here"
  tags={['React', 'Node.js']}
  github="https://github.com/..."
  live="https://..."
/>
```

## Support

For questions or issues, please open an issue on GitHub.

## License

This template is licensed for personal and commercial use. You may use it for client projects and modify it to fit your needs.

---

Built with Next.js, Tailwind CSS, and Lucide Icons
