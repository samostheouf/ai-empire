interface SkillBadgeProps {
  name: string;
  color?: string;
}

export default function SkillBadge({ name, color = 'bg-zinc-500/20 text-zinc-300 border-zinc-500/30' }: SkillBadgeProps) {
  return (
    <span
      className={`px-4 py-2 rounded-lg text-sm font-medium border transition-all hover:scale-105 ${color}`}
    >
      {name}
    </span>
  );
}
