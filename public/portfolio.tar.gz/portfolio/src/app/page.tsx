'use client';

import { useEffect, useState } from 'react';
import { ArrowDown, Github, Linkedin, Mail, MapPin, Briefcase, GraduationCap, ExternalLink } from 'lucide-react';
import ProjectCard from '@/components/ProjectCard';
import SkillBadge from '@/components/SkillBadge';

const skills = [
  { name: 'React', color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30' },
  { name: 'Next.js', color: 'bg-zinc-500/20 text-zinc-300 border-zinc-500/30' },
  { name: 'TypeScript', color: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
  { name: 'Node.js', color: 'bg-green-500/20 text-green-300 border-green-500/30' },
  { name: 'Python', color: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30' },
  { name: 'PostgreSQL', color: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30' },
  { name: 'Docker', color: 'bg-sky-500/20 text-sky-300 border-sky-500/30' },
  { name: 'AWS', color: 'bg-orange-500/20 text-orange-300 border-orange-500/30' },
  { name: 'Tailwind CSS', color: 'bg-teal-500/20 text-teal-300 border-teal-500/30' },
  { name: 'GraphQL', color: 'bg-pink-500/20 text-pink-300 border-pink-500/30' },
  { name: 'Redis', color: 'bg-red-500/20 text-red-300 border-red-500/30' },
  { name: 'Git', color: 'bg-amber-500/20 text-amber-300 border-amber-500/30' },
];

const featuredProjects = [
  {
    title: 'E-Commerce Platform',
    description: 'A full-stack e-commerce solution with real-time inventory management, secure payments, and an intuitive admin dashboard.',
    tags: ['Next.js', 'TypeScript', 'Stripe', 'PostgreSQL'],
    github: 'https://github.com',
    live: 'https://example.com',
    image: '/projects/ecommerce.jpg',
  },
  {
    title: 'AI Content Generator',
    description: 'Machine learning-powered content generation tool that creates blog posts, social media content, and marketing copy.',
    tags: ['Python', 'FastAPI', 'OpenAI', 'React'],
    github: 'https://github.com',
    live: 'https://example.com',
    image: '/projects/ai-generator.jpg',
  },
  {
    title: 'Real-time Dashboard',
    description: 'Analytics dashboard with live data visualization, customizable widgets, and collaborative features for team insights.',
    tags: ['React', 'D3.js', 'WebSocket', 'Redis'],
    github: 'https://github.com',
    live: 'https://example.com',
    image: '/projects/dashboard.jpg',
  },
];

const experience = [
  {
    role: 'Senior Full Stack Developer',
    company: 'TechCorp Inc.',
    period: '2022 - Present',
    description: 'Lead development of microservices architecture serving 1M+ users. Mentored junior developers and implemented CI/CD pipelines.',
  },
  {
    role: 'Full Stack Developer',
    company: 'StartupXYZ',
    period: '2020 - 2022',
    description: 'Built and scaled the core product from MVP to production. Implemented real-time features and optimized database performance.',
  },
  {
    role: 'Frontend Developer',
    company: 'Digital Agency',
    period: '2018 - 2020',
    description: 'Developed responsive web applications for diverse clients. Collaborated with designers to implement pixel-perfect UIs.',
  },
];

export default function Home() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  return (
    <div className="relative">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-500/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl" />
        </div>
        
        <div className={`relative z-10 max-w-4xl mx-auto text-center ${mounted ? 'animate-fade-in' : 'opacity-0'}`}>
          <div className="mb-6 inline-flex items-center gap-2 px-4 py-2 rounded-full glass-effect text-sm text-zinc-400">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            Available for new projects
          </div>
          
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold mb-6 tracking-tight">
            Hi, I'm <span className="gradient-text">John Doe</span>
          </h1>
          
          <p className="text-xl sm:text-2xl text-zinc-400 mb-8 max-w-2xl mx-auto text-balance">
            Full Stack Developer building exceptional digital experiences. 
            Passionate about clean code, intuitive design, and scalable solutions.
          </p>

          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <a
              href="#projects"
              className="inline-flex items-center gap-2 px-6 py-3 bg-primary-600 hover:bg-primary-500 text-white rounded-lg font-medium transition-colors"
            >
              View My Work
              <ArrowDown className="w-4 h-4" />
            </a>
            <a
              href="/contact"
              className="inline-flex items-center gap-2 px-6 py-3 glass-effect hover:bg-white/10 text-white rounded-lg font-medium transition-colors"
            >
              Get In Touch
              <Mail className="w-4 h-4" />
            </a>
          </div>

          <div className="flex justify-center gap-6">
            <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-zinc-400 hover:text-white transition-colors">
              <Github className="w-6 h-6" />
            </a>
            <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-zinc-400 hover:text-white transition-colors">
              <Linkedin className="w-6 h-6" />
            </a>
            <a href="mailto:john@example.com" className="text-zinc-400 hover:text-white transition-colors">
              <Mail className="w-6 h-6" />
            </a>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <ArrowDown className="w-6 h-6 text-zinc-500" />
        </div>
      </section>

      {/* About Section */}
      <section className="py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl sm:text-4xl font-bold mb-6">
                About <span className="gradient-text">Me</span>
              </h2>
              <div className="space-y-4 text-zinc-400">
                <p>
                  I'm a passionate full-stack developer with 5+ years of experience building web applications. 
                  I specialize in creating performant, accessible, and visually stunning digital products.
                </p>
                <p>
                  When I'm not coding, you can find me contributing to open-source projects, writing technical 
                  articles, or exploring new technologies. I believe in continuous learning and sharing knowledge 
                  with the developer community.
                </p>
              </div>
              
              <div className="mt-8 flex flex-wrap gap-4">
                <div className="flex items-center gap-2 text-zinc-400">
                  <MapPin className="w-5 h-5 text-primary-500" />
                  <span>San Francisco, CA</span>
                </div>
                <div className="flex items-center gap-2 text-zinc-400">
                  <Briefcase className="w-5 h-5 text-primary-500" />
                  <span>5+ Years Experience</span>
                </div>
                <div className="flex items-center gap-2 text-zinc-400">
                  <GraduationCap className="w-5 h-5 text-primary-500" />
                  <span>CS Degree</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-6">Skills & Technologies</h3>
              <div className="flex flex-wrap gap-3">
                {skills.map((skill) => (
                  <SkillBadge key={skill.name} {...skill} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-zinc-900/50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold mb-12 text-center">
            Work <span className="gradient-text">Experience</span>
          </h2>
          
          <div className="space-y-8">
            {experience.map((exp, index) => (
              <div key={index} className="relative pl-8 border-l-2 border-zinc-800 hover:border-primary-500 transition-colors">
                <div className="absolute left-0 top-0 w-3 h-3 -translate-x-[7px] rounded-full bg-zinc-800 border-2 border-primary-500" />
                <div className="glass-effect rounded-xl p-6">
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                    <h3 className="text-xl font-semibold">{exp.role}</h3>
                    <span className="text-sm text-zinc-500">{exp.period}</span>
                  </div>
                  <p className="text-primary-400 mb-3">{exp.company}</p>
                  <p className="text-zinc-400">{exp.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Projects Section */}
      <section id="projects" className="py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end mb-12 gap-4">
            <div>
              <h2 className="text-3xl sm:text-4xl font-bold mb-4">
                Featured <span className="gradient-text">Projects</span>
              </h2>
              <p className="text-zinc-400 max-w-xl">
                Here are some of my recent projects. Each one presented unique challenges and learning opportunities.
              </p>
            </div>
            <a
              href="/projects"
              className="inline-flex items-center gap-2 text-primary-400 hover:text-primary-300 transition-colors"
            >
              View All Projects
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredProjects.map((project, index) => (
              <ProjectCard key={index} {...project} />
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA Section */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-zinc-900/50">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-6">
            Let's Work <span className="gradient-text">Together</span>
          </h2>
          <p className="text-zinc-400 mb-8 text-lg">
            Have a project in mind or just want to chat? Feel free to reach out. 
            I'm always open to new opportunities and interesting conversations.
          </p>
          <a
            href="/contact"
            className="inline-flex items-center gap-2 px-8 py-4 bg-primary-600 hover:bg-primary-500 text-white rounded-lg font-medium transition-colors text-lg"
          >
            <Mail className="w-5 h-5" />
            Get In Touch
          </a>
        </div>
      </section>
    </div>
  );
}
