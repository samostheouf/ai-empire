'use client';

import { useState } from 'react';
import { Filter } from 'lucide-react';
import ProjectCard from '@/components/ProjectCard';

const categories = ['All', 'Web App', 'Mobile', 'Open Source', 'Design'];

const projects = [
  {
    title: 'E-Commerce Platform',
    description: 'A full-stack e-commerce solution with real-time inventory management, secure payments via Stripe, and an intuitive admin dashboard for business analytics.',
    tags: ['Next.js', 'TypeScript', 'Stripe', 'PostgreSQL'],
    github: 'https://github.com',
    live: 'https://example.com',
    image: '/projects/ecommerce.jpg',
    category: 'Web App',
  },
  {
    title: 'AI Content Generator',
    description: 'Machine learning-powered content generation tool that creates blog posts, social media content, and marketing copy using OpenAI\'s GPT models.',
    tags: ['Python', 'FastAPI', 'OpenAI', 'React'],
    github: 'https://github.com',
    live: 'https://example.com',
    image: '/projects/ai-generator.jpg',
    category: 'Web App',
  },
  {
    title: 'Real-time Dashboard',
    description: 'Analytics dashboard with live data visualization, customizable widgets, and collaborative features for team insights and decision making.',
    tags: ['React', 'D3.js', 'WebSocket', 'Redis'],
    github: 'https://github.com',
    live: 'https://example.com',
    image: '/projects/dashboard.jpg',
    category: 'Web App',
  },
  {
    title: 'Task Management App',
    description: 'A Kanban-style task management application with drag-and-drop functionality, team collaboration, and automated workflow triggers.',
    tags: ['React', 'Node.js', 'MongoDB', 'Socket.io'],
    github: 'https://github.com',
    live: 'https://example.com',
    image: '/projects/taskapp.jpg',
    category: 'Web App',
  },
  {
    title: 'Fitness Tracker',
    description: 'Mobile-first fitness tracking application with workout logging, progress visualization, and social features for motivation.',
    tags: ['React Native', 'Firebase', 'Redux', 'Charts.js'],
    github: 'https://github.com',
    live: 'https://example.com',
    image: '/projects/fitness.jpg',
    category: 'Mobile',
  },
  {
    title: 'CLI Dev Toolkit',
    description: 'Open source collection of CLI tools for developers. Includes project scaffolding, code generation, and deployment utilities.',
    tags: ['Node.js', 'TypeScript', 'Commander.js'],
    github: 'https://github.com',
    image: '/projects/cli.jpg',
    category: 'Open Source',
  },
  {
    title: 'Design System',
    description: 'Comprehensive design system with reusable components, design tokens, and documentation for consistent UI across products.',
    tags: ['Figma', 'Storybook', 'Tailwind', 'React'],
    github: 'https://github.com',
    live: 'https://example.com',
    image: '/projects/designsystem.jpg',
    category: 'Design',
  },
  {
    title: 'Chat Application',
    description: 'Real-time chat application with end-to-end encryption, file sharing, voice messages, and group chat capabilities.',
    tags: ['React', 'Socket.io', 'Express', 'MongoDB'],
    github: 'https://github.com',
    live: 'https://example.com',
    image: '/projects/chat.jpg',
    category: 'Web App',
  },
  {
    title: 'Weather App',
    description: 'Beautiful weather application with location-based forecasts, interactive maps, and severe weather alerts.',
    tags: ['Vue.js', 'OpenWeather API', 'Geolocation'],
    github: 'https://github.com',
    live: 'https://example.com',
    image: '/projects/weather.jpg',
    category: 'Mobile',
  },
];

export default function ProjectsPage() {
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredProjects = selectedCategory === 'All'
    ? projects
    : projects.filter(p => p.category === selectedCategory);

  return (
    <div className="min-h-screen pt-24 pb-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            My <span className="gradient-text">Projects</span>
          </h1>
          <p className="text-zinc-400 max-w-2xl mx-auto text-lg">
            A collection of projects I've worked on. From full-stack applications to open-source contributions.
          </p>
        </div>

        {/* Filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          <div className="flex items-center gap-2 text-zinc-400 mr-2">
            <Filter className="w-4 h-4" />
            <span className="text-sm">Filter:</span>
          </div>
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                selectedCategory === category
                  ? 'bg-primary-600 text-white'
                  : 'glass-effect text-zinc-400 hover:text-white hover:bg-white/10'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project, index) => (
            <ProjectCard key={index} {...project} />
          ))}
        </div>

        {filteredProjects.length === 0 && (
          <div className="text-center py-16 text-zinc-500">
            No projects found in this category.
          </div>
        )}
      </div>
    </div>
  );
}
