import AnimatedSection from '@/components/AnimatedSection'
import ContactForm from '@/components/ContactForm'
import { Mail, MapPin, Clock } from 'lucide-react'

export default function ContactPage() {
  return (
    <section className="section-padding pt-32">
      <div className="max-w-6xl mx-auto">
        <AnimatedSection>
          <h1 className="heading-xl mb-6">
            Get In <span className="gradient-text">Touch</span>
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mb-16">
            Have a project in mind or just want to say hello? I&apos;d love to hear from you.
          </p>
        </AnimatedSection>

        <div className="grid lg:grid-cols-3 gap-16">
          <div className="lg:col-span-1">
            <AnimatedSection delay={100}>
              <div className="space-y-8">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-electric/10 flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-electric" />
                  </div>
                  <div>
                    <h3 className="font-display font-semibold mb-1">Email</h3>
                    <p className="text-gray-600 dark:text-gray-400">hello@neuraportfolio.com</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-magenta/10 flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-magenta" />
                  </div>
                  <div>
                    <h3 className="font-display font-semibold mb-1">Location</h3>
                    <p className="text-gray-600 dark:text-gray-400">Berlin, Germany</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-lime/10 flex items-center justify-center flex-shrink-0">
                    <Clock className="w-6 h-6 text-lime" />
                  </div>
                  <div>
                    <h3 className="font-display font-semibold mb-1">Response Time</h3>
                    <p className="text-gray-600 dark:text-gray-400">Within 24 hours</p>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>

          <div className="lg:col-span-2">
            <AnimatedSection delay={200}>
              <div className="glass-card p-8 md:p-12">
                <ContactForm />
              </div>
            </AnimatedSection>
          </div>
        </div>
      </div>
    </section>
  )
}
