import AnimatedSection from '@/components/AnimatedSection'
import { Briefcase, GraduationCap, MapPin } from 'lucide-react'

const experience = [
  {
    period: '2022 — Present',
    role: 'Lead Designer & Developer',
    company: 'Freelance',
    description: 'Running my own practice, helping startups and established brands craft digital experiences that stand out.',
  },
  {
    period: '2020 — 2022',
    role: 'Senior UI/UX Designer',
    company: 'TechCorp Global',
    description: 'Led the design of enterprise products used by millions. Built and maintained the internal design system.',
  },
  {
    period: '2018 — 2020',
    role: 'Frontend Developer',
    company: 'Creative Agency X',
    description: 'Developed high-performance websites and interactive experiences for major brand clients.',
  },
  {
    period: '2016 — 2018',
    role: 'Junior Designer',
    company: 'Studio Pixel',
    description: 'Started my career creating brand identities and marketing materials for local businesses.',
  },
]

const education = [
  {
    period: '2012 — 2016',
    degree: 'BFA in Interaction Design',
    school: 'Design Academy',
    description: 'Studied the intersection of design, technology, and human behavior.',
  },
]

export default function AboutPage() {
  return (
    <section className="section-padding pt-32">
      <div className="max-w-5xl mx-auto">
        <AnimatedSection>
          <h1 className="heading-xl mb-6">
            About <span className="gradient-text">Me</span>
          </h1>
        </AnimatedSection>

        <div className="grid lg:grid-cols-3 gap-16">
          <div className="lg:col-span-2">
            <AnimatedSection delay={100}>
              <div className="space-y-6 text-lg text-gray-600 dark:text-gray-400 leading-relaxed mb-16">
                <p>
                  I&apos;m a designer and developer with a passion for creating digital products that are 
                  not only functional but also beautiful and memorable. With over 8 years of experience 
                  in the industry, I&apos;ve had the privilege of working with startups, agencies, and 
                  established brands.
                </p>
                <p>
                  My approach combines strategic thinking with meticulous craft. I believe that great 
                  design is invisible — it simply works. But when you look closer, every detail has been 
                  considered, every interaction refined.
                </p>
                <p>
                  When I&apos;m not pushing pixels or writing code, you&apos;ll find me exploring 
                  architecture, experimenting with generative art, or hiking in the mountains.
                </p>
              </div>
            </AnimatedSection>

            {/* Experience */}
            <AnimatedSection delay={200}>
              <h2 className="heading-md mb-8 flex items-center gap-3">
                <Briefcase className="w-6 h-6 text-electric" />
                Experience
              </h2>
              <div className="space-y-8">
                {experience.map((exp, i) => (
                  <AnimatedSection key={i} delay={300 + i * 100}>
                    <div className="relative pl-8 border-l-2 border-gray-200 dark:border-gray-700 
                                    hover:border-electric transition-colors duration-300">
                      <div className="absolute left-0 top-0 w-3 h-3 rounded-full bg-electric -translate-x-[7px]" />
                      <p className="font-mono text-sm text-electric mb-1">{exp.period}</p>
                      <h3 className="font-display font-bold text-xl mb-1">{exp.role}</h3>
                      <p className="text-gray-500 dark:text-gray-400 mb-2">{exp.company}</p>
                      <p className="text-gray-600 dark:text-gray-400 leading-relaxed">{exp.description}</p>
                    </div>
                  </AnimatedSection>
                ))}
              </div>
            </AnimatedSection>

            {/* Education */}
            <AnimatedSection delay={400}>
              <h2 className="heading-md mt-16 mb-8 flex items-center gap-3">
                <GraduationCap className="w-6 h-6 text-magenta" />
                Education
              </h2>
              <div className="space-y-8">
                {education.map((edu, i) => (
                  <div key={i} className="relative pl-8 border-l-2 border-gray-200 dark:border-gray-700">
                    <div className="absolute left-0 top-0 w-3 h-3 rounded-full bg-magenta -translate-x-[7px]" />
                    <p className="font-mono text-sm text-magenta mb-1">{edu.period}</p>
                    <h3 className="font-display font-bold text-xl mb-1">{edu.degree}</h3>
                    <p className="text-gray-500 dark:text-gray-400 mb-2">{edu.school}</p>
                    <p className="text-gray-600 dark:text-gray-400 leading-relaxed">{edu.description}</p>
                  </div>
                ))}
              </div>
            </AnimatedSection>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <AnimatedSection delay={200}>
              <div className="glass-card p-8 sticky top-32">
                <div className="w-32 h-32 rounded-2xl bg-gradient-to-br from-electric to-magenta mb-6 flex items-center justify-center text-white font-display font-bold text-5xl">
                  N
                </div>
                <h3 className="font-display font-bold text-2xl mb-2">Your Name</h3>
                <p className="text-gray-500 dark:text-gray-400 flex items-center gap-2 mb-6">
                  <MapPin className="w-4 h-4" />
                  Berlin, Germany
                </p>
                <p className="text-gray-600 dark:text-gray-400 leading-relaxed mb-6">
                  Available for freelance projects, full-time opportunities, and creative collaborations.
                </p>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Experience</span>
                    <span className="font-display font-semibold">8+ years</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Projects</span>
                    <span className="font-display font-semibold">50+</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Happy Clients</span>
                    <span className="font-display font-semibold">30+</span>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </div>
    </section>
  )
}
