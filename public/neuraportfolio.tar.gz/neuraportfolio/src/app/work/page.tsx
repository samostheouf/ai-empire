'use client'

import { useState } from 'react'
import AnimatedSection from '@/components/AnimatedSection'
import ProjectCard from '@/components/ProjectCard'
import ProjectFilter from '@/components/ProjectFilter'
import { projects } from '@/lib/projects'

const categories = ['All', 'Web', 'Mobile', 'Brand', 'UI']

export default function WorkPage() {
  const [activeCategory, setActiveCategory] = useState('All')

  const filteredProjects = activeCategory === 'All'
    ? projects
    : projects.filter(p => p.category === activeCategory)

  return (
    <section className="section-padding pt-32">
      <div className="max-w-7xl mx-auto">
        <AnimatedSection>
          <h1 className="heading-xl mb-6">
            Selected <span className="gradient-text">Work</span>
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mb-12">
            A curated collection of projects spanning design, development, and brand identity.
          </p>
        </AnimatedSection>

        <AnimatedSection delay={100}>
          <div className="mb-12">
            <ProjectFilter
              categories={categories}
              active={activeCategory}
              onSelect={setActiveCategory}
            />
          </div>
        </AnimatedSection>

        <div className="masonry-grid">
          {filteredProjects.map((project, i) => (
            <AnimatedSection key={project.id} delay={i * 100}>
              <div className="masonry-item">
                <ProjectCard project={project} />
              </div>
            </AnimatedSection>
          ))}
        </div>

        {filteredProjects.length === 0 && (
          <AnimatedSection>
            <div className="text-center py-20">
              <p className="text-xl text-gray-500 dark:text-gray-400">
                No projects found in this category.
              </p>
            </div>
          </AnimatedSection>
        )}
      </div>
    </section>
  )
}
