import { notFound } from 'next/navigation'
import Image from 'next/image'
import Link from 'next/link'
import { projects, getProjectBySlug, getAdjacentProjects } from '@/lib/projects'
import AnimatedSection from '@/components/AnimatedSection'
import { ArrowLeft, ArrowRight, ExternalLink, Calendar, Building2 } from 'lucide-react'

export function generateStaticParams() {
  return projects.map((project) => ({
    slug: project.slug,
  }))
}

export async function generateMetadata({ params }: { params: { slug: string } }) {
  const project = getProjectBySlug(params.slug)
  if (!project) return { title: 'Project Not Found' }
  return {
    title: `${project.title} — NeuraPortfolio`,
    description: project.description,
  }
}

export default function ProjectPage({ params }: { params: { slug: string } }) {
  const project = getProjectBySlug(params.slug)

  if (!project) {
    notFound()
  }

  const { prev, next } = getAdjacentProjects(params.slug)

  return (
    <section className="section-padding pt-32">
      <div className="max-w-5xl mx-auto">
        <AnimatedSection>
          <Link href="/work" className="inline-flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-electric transition-colors mb-8 group">
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            Back to all projects
          </Link>
        </AnimatedSection>

        <AnimatedSection delay={100}>
          <span className="inline-block px-4 py-2 bg-electric/10 text-electric font-mono text-sm rounded-xl mb-6">
            {project.category}
          </span>
          <h1 className="heading-xl mb-6">{project.title}</h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 leading-relaxed max-w-3xl mb-8">
            {project.description}
          </p>
        </AnimatedSection>

        <AnimatedSection delay={200}>
          <div className="flex flex-wrap gap-6 mb-12 text-sm text-gray-500 dark:text-gray-400">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              {project.year}
            </div>
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4" />
              {project.client}
            </div>
            <a
              href={project.link}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-electric hover:underline"
            >
              <ExternalLink className="w-4 h-4" />
              Live Project
            </a>
          </div>
        </AnimatedSection>

        <AnimatedSection delay={300}>
          <div className="relative aspect-video rounded-3xl overflow-hidden mb-16">
            <Image
              src={project.image}
              alt={project.title}
              fill
              className="object-cover"
              priority
              sizes="(max-width: 1024px) 100vw, 768px"
            />
          </div>
        </AnimatedSection>

        <AnimatedSection delay={400}>
          <div className="grid md:grid-cols-2 gap-12 mb-16">
            <div>
              <h2 className="heading-md mb-6">About the Project</h2>
              <p className="text-gray-600 dark:text-gray-400 leading-relaxed text-lg">
                {project.longDescription}
              </p>
            </div>
            <div>
              <h2 className="heading-md mb-6">Tech Stack</h2>
              <div className="flex flex-wrap gap-3">
                {project.technologies.map((tech) => (
                  <span
                    key={tech}
                    className="px-4 py-2 bg-gray-100 dark:bg-gray-800 rounded-xl font-mono text-sm
                               text-gray-700 dark:text-gray-300 hover:bg-electric hover:text-white
                               transition-all duration-300 cursor-default"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </AnimatedSection>

        {/* Navigation */}
        <div className="border-t border-gray-200 dark:border-gray-800 pt-12 grid md:grid-cols-2 gap-6">
          {prev ? (
            <Link
              href={`/work/${prev.slug}`}
              className="glass-card p-8 hover-lift group text-left"
            >
              <span className="text-sm text-gray-500 dark:text-gray-400 flex items-center gap-2 mb-2">
                <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
                Previous Project
              </span>
              <h3 className="font-display font-bold text-xl group-hover:text-electric transition-colors">
                {prev.title}
              </h3>
            </Link>
          ) : (
            <div />
          )}
          {next ? (
            <Link
              href={`/work/${next.slug}`}
              className="glass-card p-8 hover-lift group text-right"
            >
              <span className="text-sm text-gray-500 dark:text-gray-400 flex items-center gap-2 justify-end mb-2">
                Next Project
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </span>
              <h3 className="font-display font-bold text-xl group-hover:text-electric transition-colors">
                {next.title}
              </h3>
            </Link>
          ) : (
            <div />
          )}
        </div>
      </div>
    </section>
  )
}
