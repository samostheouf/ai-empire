import AnimatedSection from '@/components/AnimatedSection'
import ProjectCard from '@/components/ProjectCard'
import SkillBar from '@/components/SkillBar'
import TestimonialCard from '@/components/TestimonialCard'
import { projects } from '@/lib/projects'
import { skills } from '@/lib/skills'
import { testimonials } from '@/lib/testimonials'
import { ArrowRight, Sparkles, Zap, Palette, Code2 } from 'lucide-react'
import Link from 'next/link'

export default function Home() {
  const featuredProjects = projects.filter(p => p.featured).slice(0, 3)

  return (
    <>
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden noise-bg">
        {/* Animated background gradients */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-electric/20 rounded-full blur-[128px] animate-float" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-magenta/20 rounded-full blur-[128px] animate-float" style={{ animationDelay: '2s' }} />
          <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-lime/10 rounded-full blur-[128px] animate-float" style={{ animationDelay: '4s' }} />
        </div>

        <div className="section-padding w-full max-w-7xl mx-auto">
          <AnimatedSection>
            <div className="max-w-4xl">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-electric/10 text-electric font-mono text-sm mb-8">
                <Sparkles className="w-4 h-4" />
                Available for new projects
              </div>

              <h1 className="heading-xl mb-8">
                I craft{' '}
                <span className="gradient-text">digital</span>{' '}
                <br />
                experiences that{' '}
                <span className="gradient-text">inspire</span>
              </h1>

              <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-400 max-w-2xl mb-12 text-balance font-light leading-relaxed">
                Creative designer and developer building beautiful, functional products
                that push boundaries and deliver results.
              </p>

              <div className="flex flex-wrap gap-4">
                <Link href="/work" className="btn-primary">
                  View My Work
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Link>
                <Link href="/about" className="btn-secondary">
                  About Me
                </Link>
              </div>
            </div>
          </AnimatedSection>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-gray-400 dark:border-gray-600 rounded-full flex justify-center">
            <div className="w-1.5 h-3 bg-gray-400 dark:bg-gray-600 rounded-full mt-2 animate-pulse" />
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="section-padding bg-gray-50 dark:bg-slate-900">
        <div className="max-w-7xl mx-auto">
          <AnimatedSection>
            <h2 className="heading-lg mb-4">What I Do</h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mb-16">
              Specialized in creating impactful digital solutions across multiple disciplines.
            </p>
          </AnimatedSection>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Palette, title: 'Brand Identity', desc: 'Visual systems that tell your story and connect with your audience.' },
              { icon: Code2, title: 'Web Development', desc: 'Fast, accessible, and beautifully crafted websites and apps.' },
              { icon: Zap, title: 'UI/UX Design', desc: 'Intuitive interfaces that delight users and drive engagement.' },
              { icon: Sparkles, title: 'Creative Direction', desc: 'Strategic vision that elevates brands above the competition.' },
            ].map((service, i) => (
              <AnimatedSection key={service.title} delay={i * 100}>
                <div className="glass-card p-8 h-full hover-lift group cursor-default">
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-electric to-magenta flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                    <service.icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="font-display font-bold text-xl mb-3">{service.title}</h3>
                  <p className="text-gray-600 dark:text-gray-400 leading-relaxed">{service.desc}</p>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Work */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <AnimatedSection>
            <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
              <div>
                <h2 className="heading-lg mb-4">Featured Work</h2>
                <p className="text-xl text-gray-600 dark:text-gray-400">
                  Selected projects that showcase my approach and expertise.
                </p>
              </div>
              <Link
                href="/work"
                className="btn-ghost group"
              >
                View all projects
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </AnimatedSection>

          <div className="masonry-grid">
            {featuredProjects.map((project, i) => (
              <AnimatedSection key={project.id} delay={i * 150}>
                <div className="masonry-item">
                  <ProjectCard project={project} />
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section className="section-padding bg-gray-50 dark:bg-slate-900">
        <div className="max-w-7xl mx-auto">
          <AnimatedSection>
            <h2 className="heading-lg mb-4">Skills & Expertise</h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mb-16">
              Years of experience honing my craft across design and development.
            </p>
          </AnimatedSection>

          <div className="grid md:grid-cols-3 gap-12">
            {skills.map((category, i) => (
              <AnimatedSection key={category.name} delay={i * 200}>
                <div>
                  <h3 className="font-display font-bold text-2xl mb-8 flex items-center gap-3">
                    <span className="w-3 h-3 rounded-full bg-gradient-to-r from-electric to-magenta" />
                    {category.name}
                  </h3>
                  <div className="space-y-6">
                    {category.items.map((skill) => (
                      <SkillBar key={skill.name} name={skill.name} percentage={skill.percentage} />
                    ))}
                  </div>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <AnimatedSection>
            <h2 className="heading-lg mb-4">Kind Words</h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mb-16">
              What collaborators and clients say about working together.
            </p>
          </AnimatedSection>

          <div className="grid md:grid-cols-2 gap-6">
            {testimonials.map((testimonial, i) => (
              <AnimatedSection key={testimonial.id} delay={i * 100}>
                <TestimonialCard testimonial={testimonial} />
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto">
          <AnimatedSection>
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-electric via-blue-700 to-magenta p-12 md:p-20 text-center text-white noise-bg">
              <div className="absolute inset-0 -z-10">
                <div className="absolute top-0 right-0 w-72 h-72 bg-white/10 rounded-full blur-[100px]" />
                <div className="absolute bottom-0 left-0 w-72 h-72 bg-magenta/30 rounded-full blur-[100px]" />
              </div>

              <h2 className="heading-lg mb-6 text-white">Let&apos;s Create Something Amazing</h2>
              <p className="text-xl text-white/80 max-w-2xl mx-auto mb-10">
                Have a project in mind? I&apos;d love to hear about it. Let&apos;s talk about how we can bring your vision to life.
              </p>
              <Link
                href="/contact"
                className="inline-flex items-center justify-center px-8 py-4 bg-white text-electric font-display font-semibold rounded-xl
                           hover:bg-gray-100 transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5"
              >
                Get In Touch
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </div>
          </AnimatedSection>
        </div>
      </section>
    </>
  )
}
