export interface Testimonial {
  id: string
  quote: string
  author: string
  role: string
  company: string
  avatar: string
}

export const testimonials: Testimonial[] = [
  {
    id: '1',
    quote: 'An exceptional creative partner who transformed our vision into a product that exceeded every expectation. The attention to detail and strategic thinking is unmatched.',
    author: 'Sarah Chen',
    role: 'CEO',
    company: 'Aurora Analytics',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&q=80',
  },
  {
    id: '2',
    quote: 'Working together was a game-changer for our brand. The new identity perfectly captures who we are and has resonated deeply with our audience.',
    author: 'Marcus Rivera',
    role: 'Creative Director',
    company: 'Vertex Studios',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&q=80',
  },
  {
    id: '3',
    quote: 'The design system delivered has saved our team countless hours and ensured consistency across all our products. A true force multiplier for our organization.',
    author: 'Emily Watson',
    role: 'Head of Product',
    company: 'TechCorp Global',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&q=80',
  },
  {
    id: '4',
    quote: 'From concept to launch, the level of craft and professionalism was outstanding. Our app has received overwhelmingly positive feedback from users.',
    author: 'David Park',
    role: 'Founder',
    company: 'Pulse Health Inc.',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&q=80',
  },
]
