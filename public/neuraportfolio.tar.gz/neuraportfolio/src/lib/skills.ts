export interface Skill {
  name: string
  percentage: number
}

export interface SkillCategory {
  name: string
  items: Skill[]
}

export const skills: SkillCategory[] = [
  {
    name: 'Design',
    items: [
      { name: 'UI/UX Design', percentage: 95 },
      { name: 'Brand Identity', percentage: 90 },
      { name: 'Motion Design', percentage: 85 },
      { name: 'Typography', percentage: 88 },
      { name: 'Prototyping', percentage: 92 },
    ],
  },
  {
    name: 'Development',
    items: [
      { name: 'React / Next.js', percentage: 93 },
      { name: 'TypeScript', percentage: 90 },
      { name: 'Node.js', percentage: 85 },
      { name: 'CSS / Tailwind', percentage: 95 },
      { name: 'Three.js / WebGL', percentage: 78 },
    ],
  },
  {
    name: 'Tools',
    items: [
      { name: 'Figma', percentage: 96 },
      { name: 'VS Code', percentage: 94 },
      { name: 'Git', percentage: 90 },
      { name: 'Vercel', percentage: 88 },
      { name: 'PostgreSQL', percentage: 82 },
    ],
  },
]
