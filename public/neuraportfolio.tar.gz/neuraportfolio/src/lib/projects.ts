export interface Project {
  id: string
  slug: string
  title: string
  description: string
  longDescription: string
  category: 'Web' | 'Mobile' | 'Brand' | 'UI'
  image: string
  technologies: string[]
  link: string
  featured: boolean
  year: string
  client: string
}

export const projects: Project[] = [
  {
    id: '1',
    slug: 'aurora-dashboard',
    title: 'Aurora Dashboard',
    description: 'A real-time analytics dashboard with stunning data visualizations and dark mode interface.',
    longDescription: 'Aurora Dashboard is a comprehensive analytics platform designed for SaaS companies. It features real-time data streaming, customizable widgets, and a dark-first design system. Built with performance in mind, the dashboard handles millions of data points while maintaining smooth 60fps animations. The project involved close collaboration with the data science team to ensure visualizations were both beautiful and scientifically accurate.',
    category: 'Web',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80',
    technologies: ['React', 'TypeScript', 'D3.js', 'Tailwind CSS', 'WebSocket'],
    link: 'https://example.com/aurora',
    featured: true,
    year: '2024',
    client: 'Aurora Analytics',
  },
  {
    id: '2',
    slug: 'pulse-fitness',
    title: 'Pulse Fitness',
    description: 'Mobile fitness app with AI-powered workout recommendations and social features.',
    longDescription: 'Pulse Fitness reimagines the workout experience with machine learning-powered recommendations that adapt to each user\'s fitness level, goals, and preferences. The app features real-time form analysis using phone cameras, social challenges, and a gamification system that keeps users motivated. With over 50,000 downloads in its first month, Pulse has become a top-rated fitness app.',
    category: 'Mobile',
    image: 'https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?w=800&q=80',
    technologies: ['React Native', 'Node.js', 'TensorFlow', 'Firebase', 'Stripe'],
    link: 'https://example.com/pulse',
    featured: true,
    year: '2024',
    client: 'Pulse Health Inc.',
  },
  {
    id: '3',
    slug: 'vertex-studios',
    title: 'Vertex Studios',
    description: 'Complete brand identity and website for a creative production studio.',
    longDescription: 'Vertex Studios needed a brand identity that captured their bold, experimental approach to film and music production. The project encompassed logo design, a comprehensive brand guideline system, stationery, merchandise, and a fully responsive website. The visual language draws from brutalist design principles while maintaining a premium feel that appeals to major label clients.',
    category: 'Brand',
    image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800&q=80',
    technologies: ['Figma', 'Illustrator', 'Next.js', 'Three.js', 'GSAP'],
    link: 'https://example.com/vertex',
    featured: true,
    year: '2023',
    client: 'Vertex Studios',
  },
  {
    id: '4',
    slug: 'nebula-design-system',
    title: 'Nebula Design System',
    description: 'Enterprise design system powering products across 12 teams and 40+ components.',
    longDescription: 'Nebula is a scalable design system built to serve a rapidly growing organization. It includes a component library, design tokens, accessibility guidelines, and comprehensive documentation. The system reduced design-to-development handoff time by 60% and improved consistency across all product surfaces. Built with Storybook and published as private npm packages.',
    category: 'UI',
    image: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb?w=800&q=80',
    technologies: ['React', 'Storybook', 'TypeScript', 'Figma', 'CSS Variables'],
    link: 'https://example.com/nebula',
    featured: false,
    year: '2024',
    client: 'TechCorp Global',
  },
  {
    id: '5',
    slug: 'wanderlust-travel',
    title: 'Wanderlust Travel',
    description: 'Immersive travel booking platform with 3D destination previews and AR features.',
    longDescription: 'Wanderlust transforms the travel booking experience with interactive 3D previews of destinations, AR hotel room previews, and AI-curated itineraries. The platform uses WebGL for stunning destination visualizations and integrates with major hotel chains and airlines. Users can virtually explore destinations before booking, leading to a 40% increase in conversion rates.',
    category: 'Web',
    image: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800&q=80',
    technologies: ['Next.js', 'Three.js', 'Mapbox', 'Prisma', 'PostgreSQL'],
    link: 'https://example.com/wanderlust',
    featured: false,
    year: '2023',
    client: 'Wanderlust Co.',
  },
  {
    id: '6',
    slug: 'echo-music',
    title: 'Echo Music',
    description: 'Social music discovery app with collaborative playlists and live listening rooms.',
    longDescription: 'Echo Music brings people together through music with features like collaborative real-time playlists, virtual listening rooms, and AI-powered mood-based discovery. The app\'s distinctive visual identity uses fluid gradients and organic shapes that respond to audio frequencies, creating a living, breathing interface that feels as dynamic as the music it plays.',
    category: 'Mobile',
    image: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=800&q=80',
    technologies: ['Flutter', 'Dart', 'Firebase', 'Spotify API', 'WebRTC'],
    link: 'https://example.com/echo',
    featured: false,
    year: '2024',
    client: 'Echo Labs',
  },
  {
    id: '7',
    slug: 'forge-agency',
    title: 'Forge Agency',
    description: 'Bold rebrand and marketing site for a digital agency, featuring interactive 3D elements.',
    longDescription: 'Forge Agency\'s rebrand required a website that would immediately communicate their technical prowess and creative boldness. The site features WebGL-powered 3D elements, scroll-triggered animations, and a custom cursor. Every page tells a story through motion, with performance optimized to maintain smooth interactions even on mid-range devices.',
    category: 'Brand',
    image: 'https://images.unsplash.com/photo-1559028012-481c04fa702d?w=800&q=80',
    technologies: ['Next.js', 'Three.js', 'GSAP', 'Figma', 'Vercel'],
    link: 'https://example.com/forge',
    featured: false,
    year: '2023',
    client: 'Forge Digital Agency',
  },
]

export function getProjectBySlug(slug: string): Project | undefined {
  return projects.find(p => p.slug === slug)
}

export function getProjectsByCategory(category: string): Project[] {
  if (category === 'All') return projects
  return projects.filter(p => p.category === category)
}

export function getAdjacentProjects(slug: string) {
  const index = projects.findIndex(p => p.slug === slug)
  const prev = index > 0 ? projects[index - 1] : null
  const next = index < projects.length - 1 ? projects[index + 1] : null
  return { prev, next }
}
