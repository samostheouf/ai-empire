import Link from 'next/link'
import { Github, Twitter, Linkedin, Instagram, Heart } from 'lucide-react'

const socialLinks = [
  { href: 'https://github.com', icon: Github, label: 'GitHub' },
  { href: 'https://twitter.com', icon: Twitter, label: 'Twitter' },
  { href: 'https://linkedin.com', icon: Linkedin, label: 'LinkedIn' },
  { href: 'https://instagram.com', icon: Instagram, label: 'Instagram' },
]

export default function Footer() {
  return (
    <footer className="border-t border-gray-200 dark:border-gray-800">
      <div className="max-w-7xl mx-auto px-6 md:px-12 lg:px-24 py-16">
        <div className="grid md:grid-cols-3 gap-12 md:gap-8 mb-12">
          <div>
            <Link href="/" className="font-display font-bold text-2xl tracking-tight">
              <span className="text-electric">N</span>eura<span className="text-magenta">.</span>
            </Link>
            <p className="text-gray-600 dark:text-gray-400 mt-4 leading-relaxed">
              Crafting digital experiences that push boundaries and deliver results.
            </p>
          </div>

          <div>
            <h4 className="font-display font-semibold text-lg mb-4">Navigation</h4>
            <div className="space-y-3">
              <Link href="/" className="block text-gray-600 dark:text-gray-400 hover:text-electric transition-colors duration-300">
                Home
              </Link>
              <Link href="/work" className="block text-gray-600 dark:text-gray-400 hover:text-electric transition-colors duration-300">
                Work
              </Link>
              <Link href="/about" className="block text-gray-600 dark:text-gray-400 hover:text-electric transition-colors duration-300">
                About
              </Link>
              <Link href="/contact" className="block text-gray-600 dark:text-gray-400 hover:text-electric transition-colors duration-300">
                Contact
              </Link>
            </div>
          </div>

          <div>
            <h4 className="font-display font-semibold text-lg mb-4">Connect</h4>
            <div className="flex gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-12 h-12 rounded-xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center
                             text-gray-600 dark:text-gray-400 hover:bg-electric hover:text-white
                             transition-all duration-300 hover:-translate-y-1"
                  aria-label={social.label}
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
            <p className="text-gray-600 dark:text-gray-400 mt-4">
              hello@neuraportfolio.com
            </p>
          </div>
        </div>

        <div className="border-t border-gray-200 dark:border-gray-800 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-gray-500 dark:text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} NeuraPortfolio. All rights reserved.
          </p>
          <p className="text-gray-500 dark:text-gray-500 text-sm flex items-center gap-1">
            Made with <Heart className="w-4 h-4 text-magenta fill-magenta" /> and lots of coffee
          </p>
        </div>
      </div>
    </footer>
  )
}
