import Image from 'next/image'
import Link from 'next/link'
import { Project } from '@/lib/projects'
import { ArrowUpRight } from 'lucide-react'

export default function ProjectCard({ project }: { project: Project }) {
  return (
    <Link href={`/work/${project.slug}`} className="group block">
      <div className="relative overflow-hidden rounded-2xl bg-gray-100 dark:bg-gray-800 hover-lift">
        <div className="aspect-[4/3] relative overflow-hidden">
          <Image
            src={project.image}
            alt={project.title}
            fill
            className="object-cover transition-transform duration-700 group-hover:scale-110"
            sizes="(max-width: 768px) 100vw, (max-width: 1024px) 50vw, 33vw"
          />
          {/* Hover overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent 
                          opacity-0 group-hover:opacity-100 transition-all duration-500 
                          flex items-end p-6">
            <div className="w-full">
              <div className="flex items-center justify-between">
                <div>
                  <span className="inline-block px-3 py-1 bg-electric/90 text-white text-xs font-mono rounded-lg mb-3">
                    {project.category}
                  </span>
                  <h3 className="text-white font-display font-bold text-xl">{project.title}</h3>
                </div>
                <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center 
                                group-hover:bg-electric group-hover:text-white transition-all duration-300 
                                group-hover:scale-110">
                  <ArrowUpRight className="w-5 h-5" />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="p-5">
          <div className="flex flex-wrap gap-2 mb-3">
            {project.technologies.slice(0, 3).map((tech) => (
              <span
                key={tech}
                className="text-xs font-mono px-2.5 py-1 bg-gray-100 dark:bg-gray-700 rounded-lg text-gray-600 dark:text-gray-400"
              >
                {tech}
              </span>
            ))}
          </div>
          <p className="text-gray-600 dark:text-gray-400 text-sm line-clamp-2 leading-relaxed">
            {project.description}
          </p>
        </div>
      </div>
    </Link>
  )
}
