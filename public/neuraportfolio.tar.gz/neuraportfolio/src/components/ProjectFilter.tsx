'use client'

interface ProjectFilterProps {
  categories: string[]
  active: string
  onSelect: (category: string) => void
}

export default function ProjectFilter({ categories, active, onSelect }: ProjectFilterProps) {
  return (
    <div className="flex flex-wrap gap-3">
      {categories.map((category) => (
        <button
          key={category}
          onClick={() => onSelect(category)}
          className={`px-6 py-2.5 rounded-xl font-display font-medium text-sm transition-all duration-300 ${
            active === category
              ? 'bg-electric text-white shadow-lg shadow-electric/25'
              : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
          }`}
        >
          {category}
        </button>
      ))}
    </div>
  )
}
