import { Testimonial } from '@/lib/testimonials'
import { Quote } from 'lucide-react'
import Image from 'next/image'

export default function TestimonialCard({ testimonial }: { testimonial: Testimonial }) {
  return (
    <div className="glass-card p-8 h-full hover-lift group">
      <Quote className="w-10 h-10 text-electric/30 mb-6 group-hover:text-electric/60 transition-colors duration-300" />
      <p className="text-gray-700 dark:text-gray-300 leading-relaxed mb-8 text-lg italic">
        &ldquo;{testimonial.quote}&rdquo;
      </p>
      <div className="flex items-center gap-4">
        <div className="relative w-12 h-12 rounded-full overflow-hidden">
          <Image
            src={testimonial.avatar}
            alt={testimonial.author}
            fill
            className="object-cover"
            sizes="48px"
          />
        </div>
        <div>
          <p className="font-display font-semibold text-gray-900 dark:text-gray-100">
            {testimonial.author}
          </p>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            {testimonial.role}, {testimonial.company}
          </p>
        </div>
      </div>
    </div>
  )
}
