# NeuraPortfolio — Creative Portfolio Template

A bold, modern portfolio template built with Next.js 14, Tailwind CSS, and TypeScript.

## Features

- **Modern Next.js 14 App Router** — Server components, dynamic routes, optimized performance
- **Tailwind CSS Only** — No external UI libraries, fully customizable
- **Dark Mode** — Toggle between light and dark themes
- **Animated Sections** — Scroll-triggered fade-in animations via IntersectionObserver
- **Project Showcase** — Filterable project grid with categories (Web, Mobile, Brand, UI)
- **Project Detail Pages** — Dynamic slug-based routes with prev/next navigation
- **Contact Form** — Styled form with loading states
- **Responsive Design** — Mobile-first approach, looks great on all devices
- **Skills Visualization** — Animated skill bars with percentages
- **Testimonials** — Customer quote cards
- **Bold Design** — Vibrant accent colors, gradients, hover effects, large typography

## Quick Start

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

Open [http://localhost:3000](http://localhost:3000) to view the site.

## Customization

### Colors
Edit `tailwind.config.ts` to change the accent colors:
- `electric` — Primary blue accent
- `magenta` — Pink/magenta accent
- `lime` — Green/lime accent
- `neon` — Teal/neon accent

### Content
All content is data-driven via files in `src/lib/`:
- `projects.ts` — Your portfolio projects
- `skills.ts` — Your skills and percentages
- `testimonials.ts` — Client testimonials

### Typography
The template uses Space Grotesk for headings, Inter for body text, and JetBrains Mono for code. Update the font imports in `src/app/layout.tsx`.

### Images
Replace image URLs in `src/lib/projects.ts` with your own. For production, use Next.js Image component with local images or a CDN.

## Tech Stack

- Next.js 14.2
- React 18.3
- TypeScript 5.6
- Tailwind CSS 3.4
- Lucide React (icons)

## License

Commercial license. You may use this template for client projects and personal portfolios. Do not redistribute the template itself.
