export interface Category {
  id: string;
  name: string;
  description: string;
  count: number;
}

export const categories: Category[] = [
  {
    id: "tech",
    name: "Tech",
    description:
      "Deep dives into programming, frameworks, and technical architecture",
    count: 2,
  },
  {
    id: "design",
    name: "Design",
    description:
      "Visual design, UX patterns, and the art of creating beautiful interfaces",
    count: 2,
  },
  {
    id: "business",
    name: "Business",
    description:
      "Strategy, growth, and the business side of building products",
    count: 1,
  },
  {
    id: "ai",
    name: "AI",
    description:
      "Artificial intelligence, machine learning, and the future of automation",
    count: 1,
  },
  {
    id: "productivity",
    name: "Productivity",
    description:
      "Systems, tools, and techniques for getting more done with less stress",
    count: 1,
  },
];

export function getCategoryByName(name: string): Category | undefined {
  return categories.find(
    (cat) => cat.name.toLowerCase() === name.toLowerCase()
  );
}