import Link from "next/link";
import Image from "next/image";

interface Post {
  slug: string;
  title: string;
  excerpt: string;
  author: string;
  date: string;
  category: string;
  readTime: number;
  image: string;
  featured: boolean;
}

export default function PostCard({ post }: { post: Post }) {
  return (
    <Link href={`/articles/${post.slug}`} className="group block">
      <article className="bg-white dark:bg-dark-900 rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 h-full flex flex-col">
        <div className="relative h-48 overflow-hidden">
          <img
            src={post.image}
            alt={post.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <span className="absolute top-4 left-4 bg-white/90 dark:bg-dark-900/90 backdrop-blur-sm text-dark-800 dark:text-dark-200 text-xs font-medium px-3 py-1 rounded-full">
            {post.category}
          </span>
        </div>
        <div className="p-6 flex-1 flex flex-col">
          <h3 className="text-xl font-bold mb-2 text-dark-900 dark:text-dark-100 group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors line-clamp-2">
            {post.title}
          </h3>
          <p className="text-dark-600 dark:text-dark-400 mb-4 flex-1 line-clamp-2">
            {post.excerpt}
          </p>
          <div className="flex items-center text-sm text-dark-500 dark:text-dark-500">
            <span className="font-medium text-dark-700 dark:text-dark-300">
              {post.author}
            </span>
            <span className="mx-2">·</span>
            <span>{post.date}</span>
            <span className="mx-2">·</span>
            <span>{post.readTime} min</span>
          </div>
        </div>
      </article>
    </Link>
  );
}