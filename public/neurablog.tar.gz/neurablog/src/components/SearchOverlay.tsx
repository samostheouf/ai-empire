"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { Search, X } from "lucide-react";
import { posts } from "@/lib/posts";

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SearchOverlay({ isOpen, onClose }: SearchOverlayProps) {
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const filteredPosts = posts.filter(
    (post) =>
      post.title.toLowerCase().includes(query.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(query.toLowerCase()) ||
      post.category.toLowerCase().includes(query.toLowerCase()) ||
      post.author.toLowerCase().includes(query.toLowerCase())
  );

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }

    return () => {
      document.body.style.overflow = "unset";
    };
  }, [isOpen]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };

    if (isOpen) {
      window.addEventListener("keydown", handleEscape);
    }

    return () => window.removeEventListener("keydown", handleEscape);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-white dark:bg-dark-950 overflow-auto">
      <div className="container-editorial py-8">
        {/* Search Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex-1 max-w-2xl">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-dark-400" />
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search articles..."
                className="w-full pl-12 pr-4 py-4 text-xl bg-transparent border-b-2 border-brand-200 dark:border-dark-700 focus:outline-none focus:border-brand-500 dark:focus:border-brand-400 text-dark-900 dark:text-dark-100 placeholder-dark-400"
              />
            </div>
          </div>
          <button
            onClick={onClose}
            className="ml-4 p-2 text-dark-500 hover:text-dark-700 dark:text-dark-400 dark:hover:text-dark-200 transition-colors"
            aria-label="Close search"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Search Results */}
        <div className="max-w-2xl">
          {query && (
            <p className="text-dark-500 dark:text-dark-400 mb-6">
              {filteredPosts.length} result{filteredPosts.length !== 1 ? "s" : ""}{" "}
              found
            </p>
          )}

          {filteredPosts.length > 0 ? (
            <div className="space-y-6">
              {filteredPosts.map((post) => (
                <Link
                  key={post.slug}
                  href={`/articles/${post.slug}`}
                  onClick={onClose}
                  className="block p-6 rounded-xl hover:bg-brand-50 dark:hover:bg-dark-900 transition-colors"
                >
                  <div className="flex items-start gap-4">
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-20 h-20 object-cover rounded-lg flex-shrink-0"
                    />
                    <div>
                      <span className="text-sm text-brand-600 dark:text-brand-400 font-medium">
                        {post.category}
                      </span>
                      <h3 className="text-xl font-bold text-dark-900 dark:text-dark-100 mt-1 mb-2">
                        {post.title}
                      </h3>
                      <p className="text-dark-600 dark:text-dark-400 line-clamp-2">
                        {post.excerpt}
                      </p>
                      <div className="flex items-center text-sm text-dark-500 dark:text-dark-500 mt-3">
                        <span>{post.author}</span>
                        <span className="mx-2">·</span>
                        <span>{post.date}</span>
                        <span className="mx-2">·</span>
                        <span>{post.readTime} min read</span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : query ? (
            <div className="text-center py-12">
              <p className="text-dark-500 dark:text-dark-400 text-lg">
                No articles found matching &quot;{query}&quot;
              </p>
              <p className="text-dark-400 dark:text-dark-500 mt-2">
                Try different keywords or browse all articles
              </p>
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-dark-500 dark:text-dark-400 text-lg">
                Start typing to search articles
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}