"use client";

interface CategoryFilterProps {
  categories: string[];
  selected: string;
  onSelect: (category: string) => void;
}

export default function CategoryFilter({
  categories,
  selected,
  onSelect,
}: CategoryFilterProps) {
  return (
    <div className="flex overflow-x-auto pb-2 scrollbar-hide">
      <div className="flex space-x-2 min-w-max">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => onSelect(category)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${
              selected === category
                ? "bg-dark-900 text-white dark:bg-dark-100 dark:text-dark-900"
                : "bg-brand-100 text-dark-700 hover:bg-brand-200 dark:bg-dark-800 dark:text-dark-300 dark:hover:bg-dark-700"
            }`}
          >
            {category}
          </button>
        ))}
      </div>
    </div>
  );
}