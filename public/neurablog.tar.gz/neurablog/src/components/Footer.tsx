import Link from "next/link";
import { Rss, Twitter, Github, Linkedin } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-white dark:bg-dark-950 border-t border-brand-100 dark:border-dark-800">
      <div className="container-wide py-12">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <Link
              href="/"
              className="text-2xl font-serif font-bold text-dark-900 dark:text-dark-100"
            >
              NeuraBlog
            </Link>
            <p className="mt-4 text-dark-600 dark:text-dark-400 max-w-md">
              Exploring technology, design, and the future of digital experiences.
              Thoughtful articles for curious minds.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold text-dark-900 dark:text-dark-100 mb-4">
              Quick Links
            </h3>
            <ul className="space-y-2">
              <li>
                <Link
                  href="/"
                  className="text-dark-600 dark:text-dark-400 hover:text-dark-900 dark:hover:text-dark-100 transition-colors"
                >
                  Home
                </Link>
              </li>
              <li>
                <Link
                  href="/articles"
                  className="text-dark-600 dark:text-dark-400 hover:text-dark-900 dark:hover:text-dark-100 transition-colors"
                >
                  Articles
                </Link>
              </li>
              <li>
                <Link
                  href="/about"
                  className="text-dark-600 dark:text-dark-400 hover:text-dark-900 dark:hover:text-dark-100 transition-colors"
                >
                  About
                </Link>
              </li>
              <li>
                <Link
                  href="/contact"
                  className="text-dark-600 dark:text-dark-400 hover:text-dark-900 dark:hover:text-dark-100 transition-colors"
                >
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h3 className="font-semibold text-dark-900 dark:text-dark-100 mb-4">
              Connect
            </h3>
            <div className="flex space-x-4">
              <a
                href="#"
                className="text-dark-600 dark:text-dark-400 hover:text-dark-900 dark:hover:text-dark-100 transition-colors"
                aria-label="RSS Feed"
              >
                <Rss className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="text-dark-600 dark:text-dark-400 hover:text-dark-900 dark:hover:text-dark-100 transition-colors"
                aria-label="Twitter"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="text-dark-600 dark:text-dark-400 hover:text-dark-900 dark:hover:text-dark-100 transition-colors"
                aria-label="GitHub"
              >
                <Github className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="text-dark-600 dark:text-dark-400 hover:text-dark-900 dark:hover:text-dark-100 transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-brand-100 dark:border-dark-800 text-center text-dark-600 dark:text-dark-400">
          <p>&copy; {new Date().getFullYear()} NeuraBlog. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}