"use client";

import { use } from "react";
import Link from "next/link";
import { ArrowLeft, Clock, User } from "lucide-react";
import ShareButtons from "@/components/ShareButtons";
import PostCard from "@/components/PostCard";
import { getPostBySlug, getRelatedPosts } from "@/lib/posts";

export default function ArticlePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = use(params);
  const post = getPostBySlug(slug);
  const relatedPosts = getRelatedPosts(slug, 3);

  if (!post) {
    return (
      <div className="container-editorial py-16 text-center">
        <h1 className="text-4xl font-bold mb-4">Article not found</h1>
        <p className="text-dark-600 dark:text-dark-400 mb-8">
          The article you&apos;re looking for doesn&apos;t exist.
        </p>
        <Link href="/articles" className="btn-primary inline-block">
          Browse all articles
        </Link>
      </div>
    );
  }

  return (
    <article className="container-editorial py-16">
      {/* Back Link */}
      <Link
        href="/articles"
        className="inline-flex items-center text-dark-600 dark:text-dark-400 hover:text-dark-900 dark:hover:text-dark-100 mb-8 transition-colors"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to articles
      </Link>

      {/* Article Header */}
      <header className="mb-12">
        <span className="inline-block bg-brand-100 dark:bg-brand-900 text-brand-800 dark:text-brand-200 text-sm font-medium px-3 py-1 rounded-full mb-4">
          {post.category}
        </span>
        <h1 className="text-4xl md:text-5xl font-bold mb-6 text-dark-900 dark:text-dark-100 leading-tight">
          {post.title}
        </h1>
        <p className="text-xl text-dark-600 dark:text-dark-400 mb-6">
          {post.excerpt}
        </p>

        {/* Meta Info */}
        <div className="flex flex-wrap items-center gap-6 text-dark-500 dark:text-dark-500">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4" />
            <span className="font-medium text-dark-700 dark:text-dark-300">
              {post.author}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4" />
            <span>{post.readTime} min read</span>
          </div>
          <span>{post.date}</span>
        </div>
      </header>

      {/* Featured Image */}
      <div className="mb-12 rounded-2xl overflow-hidden">
        <img
          src={post.image}
          alt={post.title}
          className="w-full h-auto object-cover max-h-[500px]"
        />
      </div>

      {/* Article Content */}
      <div className="prose-editorial max-w-3xl mx-auto">
        {post.content.split("\n\n").map((paragraph, index) => (
          <p key={index}>{paragraph}</p>
        ))}
      </div>

      {/* Share Buttons */}
      <div className="max-w-3xl mx-auto mt-12 pt-8 border-t border-brand-200 dark:border-dark-800">
        <div className="flex items-center justify-between">
          <span className="font-medium text-dark-700 dark:text-dark-300">
            Share this article
          </span>
          <ShareButtons title={post.title} />
        </div>
      </div>

      {/* Related Posts */}
      {relatedPosts.length > 0 && (
        <section className="mt-20">
          <h2 className="text-3xl font-bold mb-8 text-dark-900 dark:text-dark-100">
            Related Articles
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {relatedPosts.map((relatedPost) => (
              <PostCard key={relatedPost.slug} post={relatedPost} />
            ))}
          </div>
        </section>
      )}
    </article>
  );
}