"use client";

import { useState } from "react";
import PostCard from "@/components/PostCard";
import CategoryFilter from "@/components/CategoryFilter";
import { posts } from "@/lib/posts";
import { categories } from "@/lib/categories";

export default function ArticlesPage() {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredPosts = posts.filter((post) => {
    const matchesCategory =
      selectedCategory === "All" || post.category === selectedCategory;
    const matchesSearch =
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.author.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="container-editorial py-16">
      {/* Page Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-4 text-dark-900 dark:text-dark-100">
          Articles
        </h1>
        <p className="text-xl text-dark-600 dark:text-dark-400 max-w-2xl mx-auto">
          Thoughtful articles on technology, design, and the future of digital
          experiences.
        </p>
      </div>

      {/* Search Bar */}
      <div className="max-w-xl mx-auto mb-8">
        <input
          type="text"
          placeholder="Search articles..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="input-editorial text-center"
        />
      </div>

      {/* Category Filter */}
      <CategoryFilter
        categories={["All", ...categories.map((c) => c.name)]}
        selected={selectedCategory}
        onSelect={setSelectedCategory}
      />

      {/* Articles Grid */}
      {filteredPosts.length > 0 ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mt-8">
          {filteredPosts.map((post) => (
            <PostCard key={post.slug} post={post} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <p className="text-dark-500 dark:text-dark-400 text-lg">
            No articles found matching your criteria.
          </p>
          <button
            onClick={() => {
              setSelectedCategory("All");
              setSearchQuery("");
            }}
            className="mt-4 text-brand-600 dark:text-brand-400 hover:text-brand-800 dark:hover:text-brand-300 font-medium"
          >
            Clear filters
          </button>
        </div>
      )}
    </div>
  );
}