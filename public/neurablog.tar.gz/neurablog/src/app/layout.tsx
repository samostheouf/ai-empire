import type { Metadata } from "next";
import { Inter, Georgia } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import NewsletterModal from "@/components/NewsletterModal";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
});

const georgia = Georgia({
  subsets: ["latin"],
  variable: "--font-georgia",
});

export const metadata: Metadata = {
  title: "NeuraBlog Pro — Professional Blog Template",
  description:
    "A modern, clean, and professional blog template built with Next.js 14 and Tailwind CSS. Designed for writers, bloggers, and content creators.",
  keywords: [
    "blog",
    "template",
    "nextjs",
    "tailwind",
    "professional",
    "editorial",
  ],
  authors: [{ name: "NeuraBlog Pro" }],
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://neurablog-pro.vercel.app",
    siteName: "NeuraBlog Pro",
    title: "NeuraBlog Pro — Professional Blog Template",
    description:
      "A modern, clean, and professional blog template built with Next.js 14 and Tailwind CSS.",
    images: [
      {
        url: "https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=1200&h=630&fit=crop",
        width: 1200,
        height: 630,
        alt: "NeuraBlog Pro",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "NeuraBlog Pro — Professional Blog Template",
    description:
      "A modern, clean, and professional blog template built with Next.js 14 and Tailwind CSS.",
    images: [
      "https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=1200&h=630&fit=crop",
    ],
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${inter.variable} ${georgia.variable}`}>
      <body className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
        <NewsletterModal />
      </body>
    </html>
  );
}