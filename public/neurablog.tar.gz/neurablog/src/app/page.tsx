import PostCard from "@/components/PostCard";
import { posts } from "@/lib/posts";

export default function Home() {
  const featuredPost = posts.find((post) => post.featured);
  const latestPosts = posts.filter((post) => !post.featured).slice(0, 6);

  return (
    <div className="container-editorial py-16">
      {/* Hero Section */}
      <section className="mb-20">
        <div className="text-center mb-12">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-dark-900 dark:text-dark-100">
            Insights & Ideas
          </h1>
          <p className="text-xl text-dark-600 dark:text-dark-400 max-w-2xl mx-auto">
            Exploring technology, design, and the future of digital experiences.
          </p>
        </div>

        {featuredPost && (
          <div className="bg-white dark:bg-dark-900 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
            <div className="md:flex">
              <div className="md:w-1/2">
                <img
                  src={featuredPost.image}
                  alt={featuredPost.title}
                  className="w-full h-64 md:h-full object-cover"
                />
              </div>
              <div className="md:w-1/2 p-8 md:p-12 flex flex-col justify-center">
                <span className="inline-block bg-brand-100 dark:bg-brand-900 text-brand-800 dark:text-brand-200 text-sm font-medium px-3 py-1 rounded-full mb-4 w-fit">
                  {featuredPost.category}
                </span>
                <h2 className="text-3xl md:text-4xl font-bold mb-4 text-dark-900 dark:text-dark-100">
                  {featuredPost.title}
                </h2>
                <p className="text-dark-600 dark:text-dark-400 mb-6 text-lg">
                  {featuredPost.excerpt}
                </p>
                <div className="flex items-center text-sm text-dark-500 dark:text-dark-500">
                  <span className="font-medium text-dark-700 dark:text-dark-300">
                    {featuredPost.author}
                  </span>
                  <span className="mx-2">·</span>
                  <span>{featuredPost.date}</span>
                  <span className="mx-2">·</span>
                  <span>{featuredPost.readTime} min read</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* Latest Posts */}
      <section>
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold text-dark-900 dark:text-dark-100">
            Latest Articles
          </h2>
          <a
            href="/articles"
            className="text-brand-600 dark:text-brand-400 hover:text-brand-800 dark:hover:text-brand-300 font-medium"
          >
            View all →
          </a>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {latestPosts.map((post) => (
            <PostCard key={post.slug} post={post} />
          ))}
        </div>
      </section>

      {/* Newsletter CTA */}
      <section className="mt-20 bg-brand-100 dark:bg-dark-900 rounded-2xl p-8 md:p-12 text-center">
        <h2 className="text-3xl font-bold mb-4 text-dark-900 dark:text-dark-100">
          Stay Updated
        </h2>
        <p className="text-dark-600 dark:text-dark-400 mb-6 max-w-xl mx-auto">
          Get the latest articles and insights delivered straight to your inbox.
          No spam, unsubscribe anytime.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
          <input
            type="email"
            placeholder="Enter your email"
            className="input-editorial flex-1"
          />
          <button className="btn-primary whitespace-nowrap">Subscribe</button>
        </div>
      </section>
    </div>
  );
}