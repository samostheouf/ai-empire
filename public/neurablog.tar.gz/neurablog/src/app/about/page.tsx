import { Users, Target, Heart } from "lucide-react";

export default function AboutPage() {
  const team = [
    {
      name: "Sarah Chen",
      role: "Editor-in-Chief",
      bio: "Former tech journalist turned content strategist. Sarah brings 10 years of experience in digital publishing.",
    },
    {
      name: "Marcus Rivera",
      role: "Lead Developer",
      bio: "Full-stack developer passionate about performance and accessibility. Previously at Google and Vercel.",
    },
    {
      name: "Elena Volkov",
      role: "Design Director",
      bio: "Award-winning designer with a focus on emotional design and inclusive interfaces.",
    },
    {
      name: "James Mitchell",
      role: "Business Editor",
      bio: "Serial entrepreneur and business strategist. Writes about sustainable growth and leadership.",
    },
  ];

  return (
    <div className="container-editorial py-16">
      {/* Hero Section */}
      <section className="text-center mb-20">
        <h1 className="text-4xl md:text-5xl font-bold mb-6 text-dark-900 dark:text-dark-100">
          About NeuraBlog
        </h1>
        <p className="text-xl text-dark-600 dark:text-dark-400 max-w-3xl mx-auto leading-relaxed">
          We&apos;re a team of writers, designers, and developers who believe in
          the power of thoughtful content. Our mission is to explore the
          intersection of technology, design, and human experience.
        </p>
      </section>

      {/* Mission Section */}
      <section className="mb-20">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white dark:bg-dark-900 p-8 rounded-2xl shadow-sm">
            <div className="w-12 h-12 bg-brand-100 dark:bg-brand-900 rounded-xl flex items-center justify-center mb-6">
              <Target className="w-6 h-6 text-brand-600 dark:text-brand-400" />
            </div>
            <h3 className="text-xl font-bold mb-3 text-dark-900 dark:text-dark-100">
              Our Mission
            </h3>
            <p className="text-dark-600 dark:text-dark-400">
              To create content that informs, inspires, and sparks meaningful
              conversations about the future of technology and design.
            </p>
          </div>
          <div className="bg-white dark:bg-dark-900 p-8 rounded-2xl shadow-sm">
            <div className="w-12 h-12 bg-brand-100 dark:bg-brand-900 rounded-xl flex items-center justify-center mb-6">
              <Users className="w-6 h-6 text-brand-600 dark:text-brand-400" />
            </div>
            <h3 className="text-xl font-bold mb-3 text-dark-900 dark:text-dark-100">
              Our Community
            </h3>
            <p className="text-dark-600 dark:text-dark-400">
              Over 50,000 subscribers trust us for weekly insights on technology,
              design, and building better digital products.
            </p>
          </div>
          <div className="bg-white dark:bg-dark-900 p-8 rounded-2xl shadow-sm">
            <div className="w-12 h-12 bg-brand-100 dark:bg-brand-900 rounded-xl flex items-center justify-center mb-6">
              <Heart className="w-6 h-6 text-brand-600 dark:text-brand-400" />
            </div>
            <h3 className="text-xl font-bold mb-3 text-dark-900 dark:text-dark-100">
              Our Values
            </h3>
            <p className="text-dark-600 dark:text-dark-400">
              Quality over quantity. Depth over clickbait. Always accessible,
              always honest, always learning.
            </p>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="mb-20">
        <h2 className="text-3xl font-bold mb-8 text-dark-900 dark:text-dark-100">
          Our Team
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {team.map((member) => (
            <div
              key={member.name}
              className="bg-white dark:bg-dark-900 p-6 rounded-2xl shadow-sm"
            >
              <div className="w-20 h-20 bg-brand-200 dark:bg-brand-800 rounded-full mb-4 flex items-center justify-center">
                <span className="text-2xl font-bold text-brand-700 dark:text-brand-300">
                  {member.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </span>
              </div>
              <h3 className="text-lg font-bold text-dark-900 dark:text-dark-100">
                {member.name}
              </h3>
              <p className="text-brand-600 dark:text-brand-400 text-sm font-medium mb-2">
                {member.role}
              </p>
              <p className="text-dark-600 dark:text-dark-400 text-sm">
                {member.bio}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Story Section */}
      <section className="bg-white dark:bg-dark-900 rounded-2xl p-8 md:p-12">
        <h2 className="text-3xl font-bold mb-6 text-dark-900 dark:text-dark-100">
          Our Story
        </h2>
        <div className="prose-editorial max-w-3xl">
          <p>
            NeuraBlog was founded in 2022 with a simple idea: technology content
            should be as well-crafted as the products it covers. Too much tech
            journalism is either too shallow to be useful or too technical to be
            accessible. We wanted to create something different.
          </p>
          <p>
            Our team brings together expertise from journalism, software
            engineering, and design to create content that bridges the gap
            between technical depth and readability. We believe that understanding
            technology shouldn&apos;t require a computer science degree, and
            building great products shouldn&apos;t require wading through
            poorly-written tutorials.
          </p>
          <p>
            Today, NeuraBlog reaches over 50,000 readers weekly through our
            newsletter and website. We&apos;ve published over 500 articles on
            topics ranging from web development and UI design to startup strategy
            and artificial intelligence. Our content has been shared by industry
            leaders, used in university courses, and cited in numerous
            publications.
          </p>
          <p>
            As we grow, our commitment remains the same: publish content that
            respects your time, expands your knowledge, and helps you build
            better digital products.
          </p>
        </div>
      </section>
    </div>
  );
}