# NeuraBlog Pro — Professional Blog Template

A modern, clean, and professional blog template built with Next.js 14 and Tailwind CSS. Designed for writers, bloggers, and content creators who want a beautiful, fast, and SEO-friendly blog.

## Features

- **Next.js 14 App Router** — Modern React framework with server components
- **Tailwind CSS** — Utility-first CSS framework for rapid styling
- **MDX Support** — Write blog posts with Markdown and JSX components
- **SEO Optimized** — Built-in meta tags, structured data, and Open Graph images
- **Newsletter Integration** — Built-in newsletter signup modal
- **Search Functionality** — Full-screen search overlay with live filtering
- **Dark Mode** — Toggle between light and dark themes
- **Responsive Design** — Looks great on all devices
- **Editorial Design** — Clean, Medium/Substack-inspired aesthetic
- **Performance Optimized** — Fast loading times and optimized images

## Installation

1. Clone the repository or download the template

```bash
git clone https://github.com/your-username/neurablog-pro.git
cd neurablog-pro
```

2. Install dependencies

```bash
npm install
# or
yarn install
# or
pnpm install
```

3. Start the development server

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Customization

### Colors

Edit `tailwind.config.ts` to customize the color palette. The template uses warm, sepia tones for a professional editorial look.

### Content

- Add your blog posts in `src/lib/posts.ts`
- Update categories in `src/lib/categories.ts`
- Modify the about page in `src/app/about/page.tsx`
- Update the header and footer in `src/components/Header.tsx` and `src/components/Footer.tsx`

### Dark Mode

Dark mode is built-in and can be toggled using the sun/moon icon in the header. The theme preference is stored in localStorage.

## Project Structure

```
neurablog-pro/
├── public/              # Static assets
├── src/
│   ├── app/             # Next.js App Router pages
│   │   ├── layout.tsx   # Root layout
│   │   ├── page.tsx     # Homepage
│   │   ├── globals.css  # Global styles
│   │   ├── articles/    # Articles pages
│   │   └── about/       # About page
│   ├── components/      # React components
│   └── lib/             # Utilities and data
├── tailwind.config.ts   # Tailwind configuration
├── next.config.js       # Next.js configuration
├── tsconfig.json        # TypeScript configuration
└── package.json         # Dependencies
```

## Technologies Used

- Next.js 14
- React 18
- TypeScript
- Tailwind CSS 3.4
- Lucide React (icons)

## License

This template is for personal and commercial use. You can use it for client projects and modify it as needed.

## Support

If you have any questions or need help customizing the template, feel free to reach out.

---

Built with care for content creators who value design and performance.