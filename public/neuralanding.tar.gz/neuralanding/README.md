# NeuraLanding Pro — High-Converting Landing Page Template

A premium, conversion-optimized landing page built with Next.js 14 and Tailwind CSS. Designed for SaaS products, startups, and digital services.

## Features

- **High-Conversion Design** — Optimized layout, CTAs, and social proof placement
- **A/B Testing Ready** — Component structure supports easy variant testing
- **Dark Mode** — Full dark/light mode toggle with system preference detection
- **Smooth Animations** — Scroll-triggered animations and micro-interactions
- **SEO Optimized** — Meta tags, structured data, and semantic HTML
- **Fast Loading** — Optimized assets and Next.js 14 performance features
- **Responsive** — Mobile-first design that looks great on all devices
- **Glass Morphism** — Modern glass-effect pricing cards
- **Sticky Header** — Compact header on scroll with smooth transitions
- **Email Capture** — Multiple strategic CTA forms for lead generation

## Sections

1. **Header** — Sticky navigation with logo, links, and CTA
2. **Hero** — Headline, subheadline, email capture form, trust badges
3. **Social Proof** — Logo bar, user stats, uptime, reviews
4. **Features** — 6-feature grid with icons and descriptions
5. **Pricing** — 3-tier pricing with feature comparison
6. **Testimonials** — Customer quotes with ratings
7. **FAQ** — Accordion-style frequently asked questions
8. **Bottom CTA** — Final conversion section with gradient
9. **Footer** — Links, social icons, copyright

## Getting Started

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm run start
```

## Customization

### Colors
Edit `tailwind.config.ts` to change the color palette. The template uses:
- `primary` — Indigo-based primary color
- `accent` — Purple-based accent color
- `surface` — Neutral surface colors

### Content
All content is in `src/lib/*.ts` data files:
- `features-data.ts` — Feature grid items
- `pricing-data.ts` — Pricing tiers and features
- `faq-data.ts` — FAQ questions and answers

### Components
Each section is a standalone component in `src/components/`. Mix, match, or remove sections as needed.

## Tech Stack

- **Next.js 14** — App Router, React Server Components
- **React 18** — Latest stable release
- **Tailwind CSS 3** — Utility-first styling
- **TypeScript** — Full type safety
- **Lucide React** — Modern icon library

## License

Commercial license. You may use this template for your own projects but cannot resell the template itself.

---

Built for high conversion rates and fast iteration. Perfect for SaaS launches, product pages, and startup marketing sites.
