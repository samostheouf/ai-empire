import { Check } from "lucide-react";
import { type PricingTier } from "@/lib/pricing-data";

export default function PricingCard({ tier }: { tier: PricingTier }) {
  return (
    <div
      className={`relative rounded-2xl p-8 transition-all duration-300 hover:-translate-y-2 ${
        tier.highlighted
          ? "glass-card dark:glass-card-dark shadow-glow-lg ring-2 ring-primary-500 scale-[1.02]"
          : "glass-card dark:glass-card-dark"
      }`}
    >
      {tier.highlighted && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1.5 bg-gradient-to-r from-primary-500 to-accent-500 text-white text-sm font-semibold rounded-full shadow-glow">
          Most Popular
        </div>
      )}

      <div className="mb-6">
        <h3 className="text-xl font-semibold text-surface-900 dark:text-white mb-2">
          {tier.name}
        </h3>
        <p className="text-sm text-surface-500 dark:text-surface-400">
          {tier.description}
        </p>
      </div>

      <div className="mb-8">
        <div className="flex items-baseline gap-1">
          <span className="text-5xl font-bold text-surface-900 dark:text-white">
            €{tier.price}
          </span>
          <span className="text-surface-500 dark:text-surface-400 font-medium">
            {tier.period}
          </span>
        </div>
      </div>

      <ul className="space-y-3 mb-8">
        {tier.features.map((feature) => (
          <li key={feature} className="flex items-start gap-3">
            <div className="w-5 h-5 rounded-full bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center flex-shrink-0 mt-0.5">
              <Check className="w-3 h-3 text-primary-600 dark:text-primary-400" />
            </div>
            <span className="text-sm text-surface-600 dark:text-surface-400">
              {feature}
            </span>
          </li>
        ))}
      </ul>

      <button
        className={`w-full py-3.5 rounded-xl font-semibold transition-all duration-300 ${
          tier.highlighted
            ? "btn-primary"
            : "btn-secondary"
        }`}
      >
        {tier.cta}
      </button>
    </div>
  );
}
