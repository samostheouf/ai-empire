import { ArrowRight } from "lucide-react";

export default function CTASection() {
  return (
    <section className="section-padding bg-cta-gradient relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('/grid.svg')] [mask-image:linear-gradient(to_bottom,white,transparent)] opacity-10" />
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-white/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-white/10 rounded-full blur-3xl" />

      <div className="relative z-10 container-custom text-center max-w-3xl mx-auto">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
          Ready to boost your
          <br />
          conversion rates?
        </h2>
        <p className="text-lg text-white/80 mb-10">
          Join 10,000+ teams already using NeuraLanding Pro to build
          high-converting landing pages. Start your free trial today.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <div className="flex w-full sm:w-auto">
            <input
              type="email"
              placeholder="Enter your work email"
              className="flex-1 sm:w-72 px-5 py-3.5 rounded-l-xl border-2 border-r-0 border-white/20 bg-white/10 text-white placeholder-white/50 focus:outline-none focus:border-white/40 transition-all"
            />
            <button className="px-6 py-3.5 rounded-r-xl bg-white text-primary-600 font-semibold hover:bg-surface-100 transition-all shadow-lg hover:shadow-xl flex items-center gap-2 whitespace-nowrap">
              Start Free Trial
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        <p className="text-sm text-white/60 mt-6">
          No credit card required. 14-day free trial. Cancel anytime.
        </p>
      </div>
    </section>
  );
}
