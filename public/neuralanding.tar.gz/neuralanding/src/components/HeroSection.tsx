"use client";

import { ArrowRight, Play, Star, Shield, Clock } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-hero-gradient">
      <div className="absolute inset-0 bg-[url('/grid.svg')] [mask-image:linear-gradient(to_bottom,white,transparent)] opacity-20" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-500/20 rounded-full blur-3xl animate-float" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent-500/20 rounded-full blur-3xl animate-float animation-delay-300" />

      <div className="relative z-10 container-custom px-4 sm:px-6 lg:px-8 pt-32 pb-20">
        <div className="text-center max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-8 animate-in">
            <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
            <span className="text-sm font-medium text-white/90">
              Rated #1 Landing Page Builder on Product Hunt
            </span>
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6 animate-in animation-delay-100">
            <span className="text-gradient-hero">
              Launch Your Product
            </span>
            <br />
            <span className="text-white">
              With a High-Converting Page
            </span>
          </h1>

          <p className="text-lg sm:text-xl text-primary-200/80 max-w-2xl mx-auto mb-10 animate-in animation-delay-200">
            Build beautiful, conversion-optimized landing pages in minutes.
            No coding required. Trusted by 10,000+ businesses worldwide.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12 animate-in animation-delay-300">
            <div className="flex w-full sm:w-auto">
              <input
                type="email"
                placeholder="Enter your work email"
                className="flex-1 sm:w-72 px-5 py-3.5 rounded-l-xl border-2 border-r-0 border-white/20 bg-white/10 text-white placeholder-white/50 focus:outline-none focus:border-white/40 transition-all"
              />
              <button className="px-6 py-3.5 rounded-r-xl bg-white text-primary-600 font-semibold hover:bg-surface-100 transition-all shadow-lg hover:shadow-xl flex items-center gap-2 whitespace-nowrap">
                Get Started
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
            <button className="btn-ghost text-white/80 hover:text-white hover:bg-white/10 flex items-center gap-2">
              <Play className="w-4 h-4" />
              Watch Demo
            </button>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-8 text-white/60 animate-in animation-delay-400">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-green-400" />
              <span className="text-sm">No credit card required</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-400" />
              <span className="text-sm">14-day free trial</span>
            </div>
            <div className="flex items-center gap-2">
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <span className="text-sm">4.9/5 average rating</span>
            </div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white dark:from-surface-950 to-transparent" />
    </section>
  );
}
