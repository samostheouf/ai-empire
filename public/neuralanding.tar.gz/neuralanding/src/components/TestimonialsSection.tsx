import { Star } from "lucide-react";

interface Testimonial {
  quote: string;
  name: string;
  role: string;
  rating: number;
}

const testimonials: Testimonial[] = [
  {
    quote:
      "NeuraLanding transformed our conversion rate from 2.1% to 8.7% in just two weeks. The A/B testing alone paid for itself on day one.",
    name: "Sarah Chen",
    role: "Head of Growth, TechFlow",
    rating: 5,
  },
  {
    quote:
      "We launched our product page in under an hour. The templates are gorgeous and the customization options are exactly what we needed.",
    name: "Marcus Rodriguez",
    role: "Founder, CloudSync",
    rating: 5,
  },
  {
    quote:
      "The analytics dashboard gives us insights we never had before. We can now see exactly where users drop off and optimize accordingly.",
    name: "Emily Watson",
    role: "Product Manager, DataDrive",
    rating: 5,
  },
  {
    quote:
      "Best investment for our marketing team this quarter. The ROI was clear within the first week of using the platform.",
    name: "James Liu",
    role: "CMO, ScaleUp",
    rating: 5,
  },
  {
    quote:
      "Finally, a landing page builder that actually converts. Clean code, fast loading, and our bounce rate dropped by 40%.",
    name: "Anna Petrov",
    role: "Director of Marketing, NextLevel",
    rating: 5,
  },
  {
    quote:
      "The team collaboration features saved us so much back-and-forth. Everything is in one place with real-time feedback.",
    name: "David Okafor",
    role: "VP Engineering, BrightPath",
    rating: 5,
  },
];

export default function TestimonialsSection() {
  return (
    <section
      id="testimonials"
      className="section-padding bg-white dark:bg-surface-950"
    >
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-sm font-semibold text-primary-600 dark:text-primary-400 uppercase tracking-wider mb-4">
            Testimonials
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-surface-900 dark:text-white mb-6">
            Loved by{" "}
            <span className="text-gradient">10,000+ teams</span>
          </h2>
          <p className="text-lg text-surface-500 dark:text-surface-400">
            See what our customers have to say about their experience.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div
              key={testimonial.name}
              className="glass-card dark:glass-card-dark rounded-2xl p-8 hover:shadow-glass-lg transition-all duration-300"
            >
              <div className="flex gap-1 mb-4">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star
                    key={i}
                    className="w-5 h-5 text-yellow-400 fill-yellow-400"
                  />
                ))}
              </div>
              <p className="text-surface-600 dark:text-surface-300 leading-relaxed mb-6">
                &ldquo;{testimonial.quote}&rdquo;
              </p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary-400 to-accent-400 flex items-center justify-center text-white font-semibold text-sm">
                  {testimonial.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </div>
                <div>
                  <p className="font-semibold text-surface-900 dark:text-white text-sm">
                    {testimonial.name}
                  </p>
                  <p className="text-xs text-surface-500 dark:text-surface-400">
                    {testimonial.role}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
