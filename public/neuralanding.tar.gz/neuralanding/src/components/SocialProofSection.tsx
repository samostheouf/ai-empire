export default function SocialProofSection() {
  const logos = ["Stripe", "Shopify", "Notion", "Vercel", "Linear", "Figma"];

  const stats = [
    { value: "10K+", label: "Active Users" },
    { value: "99.9%", label: "Uptime SLA" },
    { value: "500+", label: "5-Star Reviews" },
    { value: "50M+", label: "Pages Served" },
  ];

  return (
    <section className="py-16 bg-white dark:bg-surface-950 border-b border-surface-100 dark:border-surface-800">
      <div className="container-custom px-4 sm:px-6 lg:px-8">
        <p className="text-center text-sm font-medium text-surface-400 dark:text-surface-500 mb-10 uppercase tracking-wider">
          Trusted by industry leaders
        </p>

        <div className="flex flex-wrap items-center justify-center gap-x-12 gap-y-6 mb-16">
          {logos.map((logo) => (
            <div
              key={logo}
              className="text-xl font-bold text-surface-300 dark:text-surface-600 hover:text-surface-400 dark:hover:text-surface-500 transition-colors cursor-default"
            >
              {logo}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-gradient mb-2">
                {stat.value}
              </div>
              <div className="text-sm text-surface-500 dark:text-surface-400 font-medium">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
