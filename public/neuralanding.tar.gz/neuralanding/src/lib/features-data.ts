import {
  Zap,
  Shield,
  BarChart3,
  Users,
  Globe,
  Lock,
  type LucideIcon,
} from "lucide-react";

export interface Feature {
  icon: LucideIcon;
  title: string;
  description: string;
}

export const features: Feature[] = [
  {
    icon: Zap,
    title: "Lightning Fast",
    description:
      "Optimized for speed with Next.js 14 and edge runtime. Your landing page loads in under 1 second, keeping visitors engaged.",
  },
  {
    icon: Shield,
    title: "Enterprise Security",
    description:
      "SOC 2 compliant with end-to-end encryption. Your data and your customers data are protected at every layer.",
  },
  {
    icon: BarChart3,
    title: "Analytics Built In",
    description:
      "Real-time dashboards with conversion tracking, user behavior analysis, and A/B testing insights out of the box.",
  },
  {
    icon: Users,
    title: "Team Collaboration",
    description:
      "Invite your team, assign roles, and collaborate in real-time. Built-in comments and approval workflows streamline your process.",
  },
  {
    icon: Globe,
    title: "Global CDN",
    description:
      "Deploy to 300+ edge locations worldwide. Your content is served from the nearest server for blazing-fast global performance.",
  },
  {
    icon: Lock,
    title: "Privacy First",
    description:
      "GDPR and CCPA compliant by design. No tracking cookies, no data selling. Your users privacy is non-negotiable.",
  },
];
