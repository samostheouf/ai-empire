export interface PricingTier {
  name: string;
  price: number;
  period: string;
  description: string;
  features: string[];
  highlighted: boolean;
  cta: string;
}

export const pricingTiers: PricingTier[] = [
  {
    name: "Starter",
    price: 29,
    period: "/mo",
    description: "Perfect for small teams and early-stage startups.",
    features: [
      "Up to 5 team members",
      "10,000 monthly visitors",
      "Basic analytics dashboard",
      "Email support",
      "Custom domain",
      "SSL certificate",
    ],
    highlighted: false,
    cta: "Start Free Trial",
  },
  {
    name: "Pro",
    price: 79,
    period: "/mo",
    description: "For growing businesses that need more power.",
    features: [
      "Up to 25 team members",
      "100,000 monthly visitors",
      "Advanced analytics & A/B testing",
      "Priority support (24h response)",
      "Custom domains (unlimited)",
      "API access",
      "Custom integrations",
      "Dedicated account manager",
    ],
    highlighted: true,
    cta: "Start Free Trial",
  },
  {
    name: "Enterprise",
    price: 199,
    period: "/mo",
    description: "For large organizations with custom requirements.",
    features: [
      "Unlimited team members",
      "Unlimited visitors",
      "Full analytics suite + export",
      "Dedicated support engineer",
      "Custom domains (unlimited)",
      "Full API access",
      "Custom integrations",
      "SSO & SAML",
      "SLA guarantee (99.99%)",
      "On-premise deployment option",
    ],
    highlighted: false,
    cta: "Contact Sales",
  },
];
