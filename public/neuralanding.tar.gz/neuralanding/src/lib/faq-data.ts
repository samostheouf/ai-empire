export interface FAQItem {
  question: string;
  answer: string;
}

export const faqItems: FAQItem[] = [
  {
    question: "How does the 14-day free trial work?",
    answer:
      "Start your trial instantly with no credit card required. You get full access to all Pro features for 14 days. If you love it, choose a plan at the end of your trial. If not, no charges, no strings attached.",
  },
  {
    question: "Can I change my plan later?",
    answer:
      "Absolutely. Upgrade or downgrade at any time from your account settings. When you upgrade, you pay the prorated difference immediately. When you downgrade, the change takes effect at the start of your next billing cycle.",
  },
  {
    question: "What payment methods do you accept?",
    answer:
      "We accept all major credit cards (Visa, Mastercard, American Express), PayPal, and wire transfers for annual Enterprise plans. All payments are securely processed through Stripe.",
  },
  {
    question: "Is there a limit on how many pages I can create?",
    answer:
      "Starter plans include up to 25 landing pages. Pro plans include unlimited pages. Enterprise plans also include unlimited pages with custom page templates and advanced page analytics.",
  },
  {
    question: "Do you offer refunds?",
    answer:
      "Yes, we offer a 30-day money-back guarantee on all plans. If youre not satisfied for any reason, contact us within 30 days of your purchase for a full refund, no questions asked.",
  },
  {
    question: "How does the A/B testing work?",
    answer:
      "Create multiple variants of any section, headline, or CTA. Our built-in engine splits your traffic evenly and tracks conversion metrics in real-time. After reaching statistical significance, the winning variant is automatically promoted.",
  },
];
