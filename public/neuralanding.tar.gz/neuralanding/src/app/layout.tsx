import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NeuraLanding Pro — High-Converting Landing Page Template",
  description:
    "A premium, conversion-optimized landing page template built with Next.js 14 and Tailwind CSS. Perfect for SaaS, startups, and digital products.",
  keywords: [
    "landing page",
    "SaaS template",
    "Next.js",
    "Tailwind CSS",
    "conversion optimization",
    "startup template",
  ],
  authors: [{ name: "NeuraLanding" }],
  openGraph: {
    title: "NeuraLanding Pro — High-Converting Landing Page",
    description:
      "Launch your product with a high-converting landing page. Built with Next.js 14 and Tailwind CSS.",
    type: "website",
    locale: "en_US",
  },
  twitter: {
    card: "summary_large_image",
    title: "NeuraLanding Pro — High-Converting Landing Page",
    description:
      "Launch your product with a high-converting landing page.",
  },
  robots: "index, follow",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="antialiased">{children}</body>
    </html>
  );
}
