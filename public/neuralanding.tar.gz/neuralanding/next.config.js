/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  optimizePackageImports: ["lucide-react"],
  images: {
    formats: ["image/avif", "image/webp"],
  },
};

module.exports = nextConfig;
