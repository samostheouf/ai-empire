# AdminPro - Professional Admin Dashboard Template

A modern, responsive admin dashboard template built with Next.js 14 and Tailwind CSS. Perfect for SaaS applications, web apps, and admin panels.

![Admin Dashboard Template](https://via.placeholder.com/1200x600/0ea5e9/ffffff?text=AdminPro+Dashboard)

## Features

- **Modern Design** - Clean, professional UI with dark sidebar
- **Fully Responsive** - Works perfectly on all device sizes
- **Dark Mode Ready** - Built-in dark mode support
- **Multiple Charts** - Line, Bar, Pie, and Area charts using Recharts
- **Data Tables** - Sorting, filtering, and pagination
- **Form Elements** - Inputs, selects, toggles, and more
- **Notifications** - Real-time notification badges and dropdown
- **User Profile** - Avatar dropdown with user menu
- **Collapsible Sidebar** - Expand/collapse on desktop, slide-in on mobile

## Tech Stack

- **Framework**: Next.js 14
- **Styling**: Tailwind CSS
- **Charts**: Recharts
- **Icons**: Lucide React
- **Language**: TypeScript

## Getting Started

### Prerequisites

- Node.js 18.17 or later
- npm, yarn, or pnpm

### Installation

1. Clone the repository or download the template:
```bash
git clone https://github.com/your-repo/admin-dashboard.git
cd admin-dashboard
```

2. Install dependencies:
```bash
npm install
# or
yarn install
# or
pnpm install
```

3. Start the development server:
```bash
npm run dev
# or
yarn dev
# or
pnpm dev
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Project Structure

```
admin-dashboard/
├── public/              # Static assets
├── src/
│   ├── app/
│   │   ├── globals.css      # Global styles
│   │   ├── layout.tsx       # Root layout
│   │   ├── page.tsx         # Dashboard page
│   │   ├── users/
│   │   │   └── page.tsx     # Users management
│   │   └── settings/
│   │       └── page.tsx     # Settings page
│   └── components/
│       ├── Sidebar.tsx      # Navigation sidebar
│       ├── Header.tsx       # Top header
│       ├── StatsCard.tsx    # Statistics card
│       ├── DataTable.tsx    # Data table component
│       └── Chart.tsx        # Chart wrapper
├── tailwind.config.js   # Tailwind configuration
├── tsconfig.json        # TypeScript configuration
├── package.json         # Dependencies
└── README.md            # Documentation
```

## Customization

### Colors

Edit `tailwind.config.js` to customize the color palette:

```javascript
module.exports = {
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#f0f9ff',
          100: '#e0f2fe',
          // ... add your custom colors
        },
      },
    },
  },
};
```

### Adding New Pages

1. Create a new folder in `src/app/`
2. Add a `page.tsx` file with your content
3. Update the navigation in `src/components/Sidebar.tsx`

### Charts

The `Chart` component supports multiple chart types:

```tsx
<Chart
  type="line" // line, bar, pie, area
  data={chartData}
  title="Chart Title"
  xKey="name"
  yKey="value"
  colors={["#0ea5e9", "#10b981"]}
  height={300}
/>
```

### Data Tables

Use the `DataTable` component for customizable tables:

```tsx
const columns = [
  { key: "name", title: "Name", sortable: true },
  { key: "status", title: "Status", render: (item) => <Badge status={item.status} /> },
];

<DataTable columns={columns} data={tableData} searchPlaceholder="Search..." />
```

## Built-in Pages

### Dashboard (`/`)
- Statistics cards with trends
- Revenue overview chart
- Traffic sources pie chart
- Weekly sales bar chart
- Recent orders table

### Users (`/users`)
- User management table
- Search and filter functionality
- User roles and status
- Action buttons (view, edit, delete)

### Settings (`/settings`)
- Profile settings with avatar upload
- Notification preferences
- Security settings (2FA, password change)
- Appearance customization (theme, colors)

## Components

### Sidebar
- Collapsible navigation
- Mobile-responsive slide-in
- Active state highlighting
- Settings and logout buttons

### Header
- Global search
- Notifications dropdown with badges
- User profile dropdown
- Mobile search toggle

### StatsCard
- Icon with customizable colors
- Trend indicators (up/down)
- Percentage change display

### DataTable
- Column sorting
- Global search
- Row selection with checkboxes
- Pagination controls
- Export functionality

### Chart
- Line, Bar, Pie, and Area charts
- Customizable colors and data
- Responsive container
- Interactive tooltips

## Performance

- **Optimized Images**: Uses Next.js Image component
- **Code Splitting**: Automatic code splitting with Next.js
- **Lazy Loading**: Components load on demand
- **SEO Friendly**: Server-side rendering support

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Support

For support, email support@example.com or create an issue in the repository.

## License

This template is licensed for personal and commercial use. You can use it in unlimited projects.

---

**Made with care for developers who need a professional admin dashboard.**