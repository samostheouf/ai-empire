"use client";

import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import StatsCard from "@/components/StatsCard";
import Chart from "@/components/Chart";
import { Users, DollarSign, ShoppingCart, TrendingUp, ArrowUpRight, ArrowDownRight } from "lucide-react";

const revenueData = [
  { name: "Jan", revenue: 4000, expenses: 2400 },
  { name: "Feb", revenue: 3000, expenses: 1398 },
  { name: "Mar", revenue: 9800, expenses: 2000 },
  { name: "Apr", revenue: 3908, expenses: 2780 },
  { name: "May", revenue: 4800, expenses: 1890 },
  { name: "Jun", revenue: 3800, expenses: 2390 },
  { name: "Jul", revenue: 4300, expenses: 2490 },
];

const salesData = [
  { name: "Mon", sales: 120 },
  { name: "Tue", sales: 190 },
  { name: "Wed", sales: 150 },
  { name: "Thu", sales: 220 },
  { name: "Fri", sales: 180 },
  { name: "Sat", sales: 240 },
  { name: "Sun", sales: 170 },
];

const trafficData = [
  { name: "Direct", value: 4000 },
  { name: "Social", value: 3000 },
  { name: "Referral", value: 2000 },
  { name: "Organic", value: 2780 },
];

const recentOrders = [
  { id: "ORD-001", customer: "John Smith", product: "Pro Plan", amount: "$99.00", status: "Completed", date: "2024-01-15" },
  { id: "ORD-002", customer: "Sarah Johnson", product: "Enterprise Plan", amount: "$299.00", status: "Pending", date: "2024-01-14" },
  { id: "ORD-003", customer: "Michael Brown", product: "Starter Plan", amount: "$29.00", status: "Completed", date: "2024-01-13" },
  { id: "ORD-004", customer: "Emily Davis", product: "Pro Plan", amount: "$99.00", status: "Processing", date: "2024-01-12" },
  { id: "ORD-005", customer: "David Wilson", product: "Enterprise Plan", amount: "$299.00", status: "Completed", date: "2024-01-11" },
];

export default function Dashboard() {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "Completed":
        return "bg-emerald-100 text-emerald-700";
      case "Pending":
        return "bg-amber-100 text-amber-700";
      case "Processing":
        return "bg-blue-100 text-blue-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar />
      <div className="lg:ml-64">
        <Header />
        <main className="p-4 lg:p-8">
          {/* Page header */}
          <div className="mb-8">
            <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-500 mt-1">Welcome back! Here&apos;s what&apos;s happening with your business.</p>
          </div>

          {/* Stats cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-8">
            <StatsCard
              title="Total Revenue"
              value="$45,231.89"
              change={20.1}
              changeType="increase"
              icon={DollarSign}
              color="primary"
            />
            <StatsCard
              title="Subscriptions"
              value="+2,350"
              change={10.5}
              changeType="increase"
              icon={Users}
              color="success"
            />
            <StatsCard
              title="Sales"
              value="+12,234"
              change={4.5}
              changeType="increase"
              icon={ShoppingCart}
              color="warning"
            />
            <StatsCard
              title="Active Users"
              value="+573"
              change={2.1}
              changeType="decrease"
              icon={TrendingUp}
              color="danger"
            />
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-6 mb-8">
            <div className="lg:col-span-2">
              <Chart
                type="line"
                data={revenueData}
                title="Revenue Overview"
                xKey="name"
                yKey={["revenue", "expenses"]}
              />
            </div>
            <div>
              <Chart
                type="pie"
                data={trafficData}
                title="Traffic Sources"
                xKey="name"
                yKey="value"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6 mb-8">
            <Chart
              type="bar"
              data={salesData}
              title="Weekly Sales"
              xKey="name"
              yKey="sales"
            />
            <Chart
              type="area"
              data={revenueData}
              title="Expenses Overview"
              xKey="name"
              yKey="expenses"
            />
          </div>

          {/* Recent orders table */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="p-4 border-b border-gray-100">
              <h3 className="text-lg font-semibold text-gray-900">Recent Orders</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Order ID</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Customer</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Product</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Amount</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {recentOrders.map((order) => (
                    <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-4 py-3 text-sm font-medium text-gray-900">{order.id}</td>
                      <td className="px-4 py-3 text-sm text-gray-700">{order.customer}</td>
                      <td className="px-4 py-3 text-sm text-gray-700">{order.product}</td>
                      <td className="px-4 py-3 text-sm text-gray-700">{order.amount}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                          {order.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-500">{order.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}