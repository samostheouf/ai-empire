"use client";

import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import DataTable from "@/components/DataTable";
import { UserPlus, MoreVertical, Edit, Trash2, Eye } from "lucide-react";

const users = [
  {
    id: 1,
    name: "John Smith",
    email: "john.smith@example.com",
    role: "Admin",
    status: "Active",
    lastActive: "2024-01-15",
    avatar: "JS",
  },
  {
    id: 2,
    name: "Sarah Johnson",
    email: "sarah.j@example.com",
    role: "Editor",
    status: "Active",
    lastActive: "2024-01-14",
    avatar: "SJ",
  },
  {
    id: 3,
    name: "Michael Brown",
    email: "michael.b@example.com",
    role: "User",
    status: "Inactive",
    lastActive: "2024-01-10",
    avatar: "MB",
  },
  {
    id: 4,
    name: "Emily Davis",
    email: "emily.d@example.com",
    role: "Editor",
    status: "Active",
    lastActive: "2024-01-13",
    avatar: "ED",
  },
  {
    id: 5,
    name: "David Wilson",
    email: "david.w@example.com",
    role: "User",
    status: "Active",
    lastActive: "2024-01-12",
    avatar: "DW",
  },
  {
    id: 6,
    name: "Jessica Lee",
    email: "jessica.l@example.com",
    role: "Admin",
    status: "Active",
    lastActive: "2024-01-11",
    avatar: "JL",
  },
  {
    id: 7,
    name: "James Taylor",
    email: "james.t@example.com",
    role: "User",
    status: "Inactive",
    lastActive: "2024-01-09",
    avatar: "JT",
  },
  {
    id: 8,
    name: "Amanda White",
    email: "amanda.w@example.com",
    role: "Editor",
    status: "Active",
    lastActive: "2024-01-08",
    avatar: "AW",
  },
];

const columns = [
  {
    key: "name",
    title: "User",
    sortable: true,
    render: (user: typeof users[0]) => (
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-primary-500 flex items-center justify-center text-white font-medium text-sm">
          {user.avatar}
        </div>
        <div>
          <p className="font-medium text-gray-900">{user.name}</p>
          <p className="text-sm text-gray-500">{user.email}</p>
        </div>
      </div>
    ),
  },
  {
    key: "role",
    title: "Role",
    sortable: true,
    render: (user: typeof users[0]) => (
      <span className={`inline-flex px-2.5 py-0.5 rounded-full text-xs font-medium ${
        user.role === "Admin"
          ? "bg-purple-100 text-purple-700"
          : user.role === "Editor"
          ? "bg-blue-100 text-blue-700"
          : "bg-gray-100 text-gray-700"
      }`}>
        {user.role}
      </span>
    ),
  },
  {
    key: "status",
    title: "Status",
    sortable: true,
    render: (user: typeof users[0]) => (
      <span className={`inline-flex px-2.5 py-0.5 rounded-full text-xs font-medium ${
        user.status === "Active"
          ? "bg-emerald-100 text-emerald-700"
          : "bg-red-100 text-red-700"
      }`}>
        {user.status}
      </span>
    ),
  },
  {
    key: "lastActive",
    title: "Last Active",
    sortable: true,
  },
];

export default function UsersPage() {
  const handleActions = (user: typeof users[0]) => (
    <div className="flex items-center gap-2">
      <button className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
        <Eye size={16} />
      </button>
      <button className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
        <Edit size={16} />
      </button>
      <button className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
        <Trash2 size={16} />
      </button>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar />
      <div className="lg:ml-64">
        <Header />
        <main className="p-4 lg:p-8">
          {/* Page header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Users</h1>
              <p className="text-gray-500 mt-1">Manage your team members and their account permissions.</p>
            </div>
            <button className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors font-medium">
              <UserPlus size={18} />
              Add User
            </button>
          </div>

          {/* Users table */}
          <DataTable
            columns={columns}
            data={users}
            searchPlaceholder="Search users..."
            actions={handleActions}
          />
        </main>
      </div>
    </div>
  );
}