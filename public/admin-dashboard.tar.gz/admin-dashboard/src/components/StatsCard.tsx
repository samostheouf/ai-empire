"use client";

import { LucideIcon, TrendingUp, TrendingDown } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: string;
  change: number;
  changeType: "increase" | "decrease";
  icon: LucideIcon;
  color?: string;
}

export default function StatsCard({
  title,
  value,
  change,
  changeType,
  icon: Icon,
  color = "primary",
}: StatsCardProps) {
  const colorClasses: Record<string, { bg: string; icon: string }> = {
    primary: { bg: "bg-primary-50", icon: "text-primary-600" },
    success: { bg: "bg-emerald-50", icon: "text-emerald-600" },
    warning: { bg: "bg-amber-50", icon: "text-amber-600" },
    danger: { bg: "bg-red-50", icon: "text-red-600" },
  };

  const { bg, icon: iconColor } = colorClasses[color] || colorClasses.primary;

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-500">{title}</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{value}</p>
        </div>
        <div className={`p-3 rounded-lg ${bg}`}>
          <Icon size={24} className={iconColor} />
        </div>
      </div>
      <div className="mt-4 flex items-center gap-2">
        {changeType === "increase" ? (
          <div className="flex items-center text-emerald-600">
            <TrendingUp size={16} />
            <span className="text-sm font-medium ml-1">+{change}%</span>
          </div>
        ) : (
          <div className="flex items-center text-red-600">
            <TrendingDown size={16} />
            <span className="text-sm font-medium ml-1">-{change}%</span>
          </div>
        )}
        <span className="text-sm text-gray-500">from last month</span>
      </div>
    </div>
  );
}