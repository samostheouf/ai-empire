import Link from "next/link";
import { Bot, Zap, Shield, BarChart3, Users, Rocket } from "lucide-react";

const FEATURES = [
  { icon: Bot, title: "Multi-Agent Orchestration", desc: "Create, configure and run specialized AI agents per tenant." },
  { icon: Zap, title: "Streaming Chat", desc: "Real-time SSE streaming chat with any agent." },
  { icon: BarChart3, title: "Usage Analytics", desc: "Track requests, tokens, cost and latency per agent." },
  { icon: Shield, title: "Role-Based Access", desc: "Owner, admin, member and viewer roles out of the box." },
  { icon: Users, title: "Multi-Tenant", desc: "Tenant isolation ready structure for SaaS." },
  { icon: Rocket, title: "Deploy in Minutes", desc: "Next.js 14 App Router, Tailwind, Vercel-ready." }
];

export default function LandingPage() {
  return (
    <div className="space-y-20">
      <section className="text-center pt-12">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-100 dark:bg-brand-900/40 text-brand-700 dark:text-brand-200 text-xs font-medium">
          <Bot className="w-3.5 h-3.5" /> NeuraAPI Template · 149€
        </div>
        <h1 className="mt-6 text-4xl sm:text-6xl font-bold tracking-tight">
          Build your <span className="text-brand-600">AI Agents Business</span>
        </h1>
        <p className="mt-6 text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
          A production-ready Next.js 14 template for multi-tenant AI agent platforms: chat, analytics, billing and role-based access.
        </p>
        <div className="mt-8 flex items-center justify-center gap-4">
          <Link href="/dashboard" className="px-6 py-3 rounded-xl bg-brand-600 text-white font-medium hover:bg-brand-700 transition">
            Open Dashboard
          </Link>
          <Link href="/login" className="px-6 py-3 rounded-xl border border-slate-300 dark:border-slate-700 font-medium hover:bg-slate-100 dark:hover:bg-slate-800 transition">
            Sign in
          </Link>
        </div>
      </section>

      <section className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {FEATURES.map((f) => {
          const Icon = f.icon;
          return (
            <div key={f.title} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6">
              <div className="p-2.5 rounded-xl bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-300 w-fit">
                <Icon className="w-5 h-5" />
              </div>
              <h3 className="mt-4 font-semibold text-slate-900 dark:text-white">{f.title}</h3>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">{f.desc}</p>
            </div>
          );
        })}
      </section>

      <section className="rounded-2xl bg-gradient-to-r from-brand-600 to-brand-900 p-8 text-white text-center">
        <h2 className="text-2xl font-bold">Ready to launch?</h2>
        <p className="mt-2 opacity-90">Clone, configure env, deploy to Vercel.</p>
        <Link href="/dashboard" className="mt-6 inline-block px-6 py-3 rounded-xl bg-white text-brand-700 font-medium hover:bg-slate-100 transition">
          Get started
        </Link>
      </section>
    </div>
  );
}
