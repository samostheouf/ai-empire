"use client";

import { useEffect, useState } from "react";
import DashboardCard from "@/components/DashboardCard";
import Chart from "@/components/Chart";
import { Activity, Bot, DollarSign, Zap } from "lucide-react";
import { getOverview, USAGE_SERIES, AGENT_USAGE } from "@/lib/analytics";

export default function DashboardPage() {
  const [overview, setOverview] = useState(getOverview());
  useEffect(() => {
    setOverview(getOverview());
  }, []);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-slate-500 dark:text-slate-400">Overview of your AI agents business.</p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <DashboardCard title="Total Requests" value={overview.totalRequests.toLocaleString()} icon={Activity} trend="+12.4%" trendUp />
        <DashboardCard title="Active Agents" value={overview.activeAgents} icon={Bot} trend="+2" trendUp />
        <DashboardCard title="Total Cost" value={`$${overview.totalCost}`} icon={DollarSign} trend="-3.1%" trendUp={false} />
        <DashboardCard title="Success Rate" value={`${overview.successRate}%`} icon={Zap} trend="+0.2%" trendUp />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
          <h3 className="font-semibold mb-4">Requests over time</h3>
          <Chart type="line" data={USAGE_SERIES} xKey="date" yKey="requests" />
        </div>
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
          <h3 className="font-semibold mb-4">Cost over time</h3>
          <Chart type="bar" data={USAGE_SERIES} xKey="date" yKey="cost" />
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
        <h3 className="font-semibold mb-4">Top agents by usage</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-500">
                <th className="py-2">Agent</th>
                <th className="py-2">Requests</th>
                <th className="py-2">Tokens</th>
                <th className="py-2">Cost</th>
              </tr>
            </thead>
            <tbody>
              {AGENT_USAGE.map((a) => (
                <tr key={a.agentId} className="border-t border-slate-100 dark:border-slate-800">
                  <td className="py-2 font-medium">{a.name}</td>
                  <td className="py-2">{a.requests.toLocaleString()}</td>
                  <td className="py-2">{a.tokens.toLocaleString()}</td>
                  <td className="py-2">${a.cost.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
