"use client";

import { useEffect, useState, useRef } from "react";
import ChatMessage from "@/components/ChatMessage";
import { streamChat, ChatMessage as CM } from "@/lib/chat-client";
import { listAgents } from "@/lib/agents";
import { Send } from "lucide-react";

export default function ChatPage() {
  const agents = listAgents();
  const [agentId, setAgentId] = useState(agents[0]?.id ?? "a1");
  const [messages, setMessages] = useState<CM[]>([
    { id: "m0", role: "assistant", content: "Hi! I'm your agent. How can I help?", agentId, createdAt: Date.now() }
  ]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const send = async () => {
    if (!input.trim() || streaming) return;
    const userMsg: CM = { id: `u${Date.now()}`, role: "user", content: input, createdAt: Date.now() };
    const next = [...messages, userMsg];
    setMessages(next);
    setInput("");
    setStreaming(true);
    const assistantMsg: CM = { id: `a${Date.now()}`, role: "assistant", content: "", agentId, createdAt: Date.now() };
    setMessages([...next, assistantMsg]);
    try {
      await streamChat(next, agentId, (chunk) => {
        if (chunk.done) return;
        setMessages((prev) => {
          const copy = [...prev];
          const last = copy[copy.length - 1];
          if (last && last.role === "assistant") {
            copy[copy.length - 1] = { ...last, content: last.content + chunk.delta };
          }
          return copy;
        });
      });
    } catch (e) {
      setMessages((prev) => {
        const copy = [...prev];
        const last = copy[copy.length - 1];
        if (last && last.role === "assistant") {
          copy[copy.length - 1] = { ...last, content: "Error: could not reach agent." };
        }
        return copy;
      });
    } finally {
      setStreaming(false);
    }
  };

  const agentName = agents.find((a) => a.id === agentId)?.name;

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-bold">Chat</h1>
          <p className="text-slate-500 dark:text-slate-400">Talk to your agents.</p>
        </div>
        <select
          value={agentId}
          onChange={(e) => setAgentId(e.target.value)}
          className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-transparent"
        >
          {agents.map((a) => (
            <option key={a.id} value={a.id}>{a.name}</option>
          ))}
        </select>
      </div>

      <div className="flex-1 overflow-y-auto space-y-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
        {messages.map((m, i) => (
          <ChatMessage
            key={m.id}
            role={m.role}
            content={m.content}
            agentName={m.role === "assistant" ? agentName : undefined}
            streaming={streaming && i === messages.length - 1 && m.role === "assistant"}
          />
        ))}
        <div ref={bottomRef} />
      </div>

      <div className="mt-4 flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          placeholder="Type a message..."
          className="flex-1 px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
        />
        <button
          onClick={send}
          disabled={streaming}
          className="px-4 py-3 rounded-xl bg-brand-600 text-white hover:bg-brand-700 disabled:opacity-60"
        >
          <Send className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
