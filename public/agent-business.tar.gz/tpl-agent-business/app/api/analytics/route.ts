import { NextResponse } from "next/server";
import { getOverview, USAGE_SERIES, AGENT_USAGE, getModelBreakdown } from "@/lib/analytics";

export async function GET() {
  return NextResponse.json({
    overview: getOverview(),
    series: USAGE_SERIES,
    agentUsage: AGENT_USAGE,
    modelBreakdown: getModelBreakdown()
  });
}
