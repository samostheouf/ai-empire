import { NextRequest, NextResponse } from "next/server";
import { listAgents, createAgent, updateAgent, deleteAgent, getAgent } from "@/lib/agents";

export async function GET(req: NextRequest) {
  const tenantId = req.nextUrl.searchParams.get("tenantId") ?? "t1";
  const agents = listAgents(tenantId);
  return NextResponse.json({ agents });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    if (!body.name) {
      return NextResponse.json({ error: "name required" }, { status: 400 });
    }
    const agent = createAgent(body);
    return NextResponse.json({ agent }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }
}

export async function PATCH(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  try {
    const body = await req.json();
    const agent = updateAgent(id, body);
    if (!agent) return NextResponse.json({ error: "not found" }, { status: 404 });
    return NextResponse.json({ agent });
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }
}

export async function DELETE(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const ok = deleteAgent(id);
  if (!ok) return NextResponse.json({ error: "not found" }, { status: 404 });
  return NextResponse.json({ ok: true });
}
