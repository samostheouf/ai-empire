import { NextRequest } from "next/server";
import { getAgent } from "@/lib/agents";

export const runtime = "nodejs";

function replyFor(agentId: string, prompt: string): string {
  const base = `I'm the ${getAgent(agentId)?.name ?? "agent"}. `;
  const suggestions: Record<string, string> = {
    a1: "I can help with your support request. Could you provide your order number?",
    a2: "Great! I'll qualify your needs. What's your company size and use case?",
    a3: "Querying analytics now... Here are the top metrics for the last 7 days.",
    a4: "Drafting copy... Here's a first draft tailored to your audience."
  };
  return base + (suggestions[agentId] ?? "How can I help?") + `\n\nYou asked: "${prompt.slice(0, 120)}"`;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const messages = body.messages ?? [];
    const agentId = body.agentId ?? "a1";
    const lastUser = [...messages].reverse().find((m: any) => m.role === "user")?.content ?? "";
    const reply = replyFor(agentId, lastUser);

    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      async start(controller) {
        const words = reply.split(/(\s+)/);
        for (const w of words) {
          if (req.signal.aborted) break;
          controller.enqueue(encoder.encode(`data: ${JSON.stringify({ delta: w })}\n\n`));
          await new Promise((r) => setTimeout(r, 40));
        }
        controller.enqueue(encoder.encode("data: [DONE]\n\n"));
        controller.close();
      }
    });

    return new Response(stream, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache, no-transform",
        Connection: "keep-alive"
      }
    });
  } catch {
    return new Response("Bad request", { status: 400 });
  }
}
