"use client";

import { useState } from "react";
import { Key, CreditCard, User, Shield } from "lucide-react";
import { loadSession } from "@/lib/auth";

const API_KEYS = [
  { id: "k1", name: "Production", prefix: "sk_live_abc...", created: "2026-09-01", lastUsed: "2026-10-26" },
  { id: "k2", name: "Development", prefix: "sk_test_xyz...", created: "2026-09-10", lastUsed: "2026-10-24" }
];

export default function SettingsPage() {
  const session = typeof window !== "undefined" ? loadSession() : null;
  const [keys, setKeys] = useState(API_KEYS);
  const [newKeyName, setNewKeyName] = useState("");

  const addKey = () => {
    if (!newKeyName.trim()) return;
    setKeys((prev) => [
      ...prev,
      { id: `k${Date.now()}`, name: newKeyName, prefix: `sk_live_${Math.random().toString(36).slice(2, 10)}...`, created: new Date().toISOString().slice(0, 10), lastUsed: "never" }
    ]);
    setNewKeyName("");
  };

  const revoke = (id: string) => {
    setKeys((prev) => prev.filter((k) => k.id !== id));
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-slate-500 dark:text-slate-400">Billing, API keys and account.</p>
      </div>

      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
        <div className="flex items-center gap-2 mb-4">
          <User className="w-5 h-5 text-brand-600" />
          <h3 className="font-semibold">Account</h3>
        </div>
        <div className="grid sm:grid-cols-2 gap-4 text-sm">
          <div>
            <div className="text-slate-500">Name</div>
            <div className="font-medium">{session?.user.name ?? "Guest"}</div>
          </div>
          <div>
            <div className="text-slate-500">Email</div>
            <div className="font-medium">{session?.user.email ?? "-"}</div>
          </div>
          <div>
            <div className="text-slate-500">Role</div>
            <div className="font-medium capitalize">{session?.user.role ?? "-"}</div>
          </div>
          <div>
            <div className="text-slate-500">Tenant</div>
            <div className="font-medium">{session?.user.tenantId ?? "-"}</div>
          </div>
        </div>
      </section>

      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
        <div className="flex items-center gap-2 mb-4">
          <Key className="w-5 h-5 text-brand-600" />
          <h3 className="font-semibold">API Keys</h3>
        </div>
        <div className="flex gap-2 mb-4">
          <input
            value={newKeyName}
            onChange={(e) => setNewKeyName(e.target.value)}
            placeholder="New key name"
            className="flex-1 px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-transparent"
          />
          <button onClick={addKey} className="px-4 py-2 rounded-xl bg-brand-600 text-white font-medium hover:bg-brand-700">
            Create
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-500">
                <th className="py-2">Name</th>
                <th className="py-2">Key</th>
                <th className="py-2">Created</th>
                <th className="py-2">Last used</th>
                <th className="py-2"></th>
              </tr>
            </thead>
            <tbody>
              {keys.map((k) => (
                <tr key={k.id} className="border-t border-slate-100 dark:border-slate-800">
                  <td className="py-2 font-medium">{k.name}</td>
                  <td className="py-2 font-mono text-xs">{k.prefix}</td>
                  <td className="py-2">{k.created}</td>
                  <td className="py-2">{k.lastUsed}</td>
                  <td className="py-2 text-right">
                    <button onClick={() => revoke(k.id)} className="text-rose-600 hover:underline">Revoke</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
        <div className="flex items-center gap-2 mb-4">
          <CreditCard className="w-5 h-5 text-brand-600" />
          <h3 className="font-semibold">Billing</h3>
        </div>
        <div className="flex items-center justify-between">
          <div>
            <div className="font-medium">Pro Plan</div>
            <div className="text-sm text-slate-500">149€ / month · renews 2026-11-30</div>
          </div>
          <button className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 font-medium">
            Manage
          </button>
        </div>
      </section>

      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
        <div className="flex items-center gap-2 mb-4">
          <Shield className="w-5 h-5 text-brand-600" />
          <h3 className="font-semibold">Role-based access</h3>
        </div>
        <p className="text-sm text-slate-600 dark:text-slate-300">
          Roles: owner, admin, member, viewer. Permissions enforced server-side via /api/* (mock).
        </p>
      </section>
    </div>
  );
}
