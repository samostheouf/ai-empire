"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Bot, Mail, Lock } from "lucide-react";
import { findUser, createSession, saveSession } from "@/lib/auth";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("owner@demo.com");
  const [password, setPassword] = useState("demo123");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Login failed");
      const user = data.user;
      const session = createSession(user);
      saveSession(session);
      router.push("/dashboard");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
      <div className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 shadow-sm">
        <div className="flex items-center gap-2 justify-center mb-6">
          <Bot className="w-7 h-7 text-brand-600" />
          <span className="text-xl font-bold">NeuraAPI</span>
        </div>
        <h1 className="text-2xl font-bold text-center">Sign in</h1>
        <p className="text-sm text-slate-500 text-center mt-1">Demo password: demo123</p>
        <form onSubmit={submit} className="mt-6 space-y-4">
          <div>
            <label className="text-sm font-medium">Email</label>
            <div className="mt-1 flex items-center gap-2 border border-slate-300 dark:border-slate-700 rounded-lg px-3">
              <Mail className="w-4 h-4 text-slate-400" />
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 py-2 bg-transparent outline-none"
                type="email"
              />
            </div>
          </div>
          <div>
            <label className="text-sm font-medium">Password</label>
            <div className="mt-1 flex items-center gap-2 border border-slate-300 dark:border-slate-700 rounded-lg px-3">
              <Lock className="w-4 h-4 text-slate-400" />
              <input
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="flex-1 py-2 bg-transparent outline-none"
                type="password"
              />
            </div>
          </div>
          {error && <p className="text-sm text-rose-600">{error}</p>}
          <button
            disabled={loading}
            className="w-full py-2.5 rounded-xl bg-brand-600 text-white font-medium hover:bg-brand-700 disabled:opacity-60 transition"
          >
            {loading ? "Signing in..." : "Sign in"}
          </button>
        </form>
        <div className="mt-4 text-xs text-slate-500 space-y-1">
          <div>owner@demo.com · admin@demo.com · member@demo.com</div>
        </div>
      </div>
    </div>
  );
}
