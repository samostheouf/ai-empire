"use client";

import { useEffect, useState } from "react";
import DashboardCard from "@/components/DashboardCard";
import Chart from "@/components/Chart";
import { Activity, Cpu, DollarSign, Clock } from "lucide-react";

export default function AnalyticsPage() {
  const [data, setData] = useState<any>(null);
  useEffect(() => {
    fetch("/api/analytics")
      .then((r) => r.json())
      .then(setData)
      .catch(() => setData(null));
  }, []);

  if (!data) return <div className="text-slate-500">Loading...</div>;

  const { overview, series, agentUsage, modelBreakdown } = data;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold">Analytics</h1>
        <p className="text-slate-500 dark:text-slate-400">Usage, cost and performance.</p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <DashboardCard title="Requests" value={overview.totalRequests.toLocaleString()} icon={Activity} />
        <DashboardCard title="Tokens" value={overview.totalTokens.toLocaleString()} icon={Cpu} />
        <DashboardCard title="Cost" value={`$${overview.totalCost}`} icon={DollarSign} />
        <DashboardCard title="Avg Latency" value={`${overview.avgLatencyMs}ms`} icon={Clock} />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
          <h3 className="font-semibold mb-4">Requests</h3>
          <Chart type="line" data={series} xKey="date" yKey="requests" />
        </div>
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
          <h3 className="font-semibold mb-4">Tokens</h3>
          <Chart type="bar" data={series} xKey="date" yKey="tokens" />
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
          <h3 className="font-semibold mb-4">Model breakdown</h3>
          <Chart type="pie" data={modelBreakdown} xKey="name" yKey="value" />
        </div>
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
          <h3 className="font-semibold mb-4">By agent</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-slate-500">
                  <th className="py-2">Agent</th>
                  <th className="py-2">Requests</th>
                  <th className="py-2">Tokens</th>
                  <th className="py-2">Cost</th>
                </tr>
              </thead>
              <tbody>
                {agentUsage.map((a: any) => (
                  <tr key={a.agentId} className="border-t border-slate-100 dark:border-slate-800">
                    <td className="py-2 font-medium">{a.name}</td>
                    <td className="py-2">{a.requests.toLocaleString()}</td>
                    <td className="py-2">{a.tokens.toLocaleString()}</td>
                    <td className="py-2">${a.cost.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
