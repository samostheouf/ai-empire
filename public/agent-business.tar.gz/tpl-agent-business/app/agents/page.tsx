"use client";

import { useEffect, useState } from "react";
import AgentCard from "@/components/AgentCard";
import Modal from "@/components/Modal";
import { Plus } from "lucide-react";
import { Agent, AgentModel } from "@/lib/agents";

export default function AgentsPage() {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Agent | null>(null);
  const [form, setForm] = useState({ name: "", description: "", model: "gpt-4o" as AgentModel, systemPrompt: "" });

  const load = async () => {
    const res = await fetch("/api/agents");
    const data = await res.json();
    setAgents(data.agents ?? []);
  };

  useEffect(() => {
    load();
  }, []);

  const openCreate = () => {
    setEditing(null);
    setForm({ name: "", description: "", model: "gpt-4o", systemPrompt: "" });
    setOpen(true);
  };

  const openEdit = (a: Agent) => {
    setEditing(a);
    setForm({ name: a.name, description: a.description, model: a.model, systemPrompt: a.systemPrompt });
    setOpen(true);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editing) {
      await fetch(`/api/agents?id=${editing.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
    } else {
      await fetch("/api/agents", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
    }
    setOpen(false);
    load();
  };

  const remove = async (id: string) => {
    if (!confirm("Delete agent?")) return;
    await fetch(`/api/agents?id=${id}`, { method: "DELETE" });
    load();
  };

  const toggle = async (id: string) => {
    const a = agents.find((x) => x.id === id);
    if (!a) return;
    const next = a.status === "active" ? "idle" : "active";
    await fetch(`/api/agents?id=${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: next })
    });
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Agents</h1>
          <p className="text-slate-500 dark:text-slate-400">Manage your AI agents.</p>
        </div>
        <button onClick={openCreate} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-brand-600 text-white font-medium hover:bg-brand-700 transition">
          <Plus className="w-4 h-4" /> New Agent
        </button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {agents.map((a) => (
          <AgentCard key={a.id} agent={a} onEdit={openEdit} onDelete={remove} onToggle={toggle} />
        ))}
      </div>

      <Modal open={open} title={editing ? "Edit Agent" : "New Agent"} onClose={() => setOpen(false)}>
        <form onSubmit={submit} className="space-y-4">
          <div>
            <label className="text-sm font-medium">Name</label>
            <input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              required
              className="mt-1 w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-transparent"
            />
          </div>
          <div>
            <label className="text-sm font-medium">Description</label>
            <input
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="mt-1 w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-transparent"
            />
          </div>
          <div>
            <label className="text-sm font-medium">Model</label>
            <select
              value={form.model}
              onChange={(e) => setForm({ ...form, model: e.target.value as AgentModel })}
              className="mt-1 w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-transparent"
            >
              <option value="gpt-4o">gpt-4o</option>
              <option value="claude-3.5-sonnet">claude-3.5-sonnet</option>
              <option value="llama-3.1-70b">llama-3.1-70b</option>
              <option value="mistral-large">mistral-large</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-medium">System Prompt</label>
            <textarea
              value={form.systemPrompt}
              onChange={(e) => setForm({ ...form, systemPrompt: e.target.value })}
              rows={3}
              className="mt-1 w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-transparent"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={() => setOpen(false)} className="px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700">
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 rounded-xl bg-brand-600 text-white font-medium hover:bg-brand-700">
              Save
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
