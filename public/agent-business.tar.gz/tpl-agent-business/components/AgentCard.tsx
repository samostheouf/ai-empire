"use client";

import { Bot, Play, Pause, Trash2, Edit3, MoreVertical } from "lucide-react";
import { Agent, AgentStatus } from "@/lib/agents";

const statusColor: Record<AgentStatus, string> = {
  active: "bg-emerald-500",
  idle: "bg-slate-400",
  error: "bg-rose-500",
  disabled: "bg-amber-500"
};

type Props = {
  agent: Agent;
  onEdit?: (a: Agent) => void;
  onDelete?: (id: string) => void;
  onToggle?: (id: string) => void;
};

export default function AgentCard({ agent, onEdit, onDelete, onToggle }: Props) {
  return (
    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm hover:shadow-md transition">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-300">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-900 dark:text-white">{agent.name}</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">{agent.model}</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <span className={`w-2 h-2 rounded-full ${statusColor[agent.status]}`} />
          <span className="text-xs capitalize text-slate-500 dark:text-slate-400">{agent.status}</span>
        </div>
      </div>
      <p className="mt-3 text-sm text-slate-600 dark:text-slate-300 line-clamp-2">{agent.description}</p>
      <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
        <div className="rounded-lg bg-slate-50 dark:bg-slate-800 p-2">
          <div className="text-slate-400">Runs</div>
          <div className="font-semibold text-slate-900 dark:text-white">{agent.runs.toLocaleString()}</div>
        </div>
        <div className="rounded-lg bg-slate-50 dark:bg-slate-800 p-2">
          <div className="text-slate-400">Cost</div>
          <div className="font-semibold text-slate-900 dark:text-white">${agent.costUsd.toFixed(2)}</div>
        </div>
      </div>
      <div className="mt-4 flex items-center justify-end gap-2">
        <button
          onClick={() => onToggle?.(agent.id)}
          className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
          aria-label="Toggle"
        >
          {agent.status === "active" ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
        </button>
        <button
          onClick={() => onEdit?.(agent)}
          className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
          aria-label="Edit"
        >
          <Edit3 className="w-4 h-4" />
        </button>
        <button
          onClick={() => onDelete?.(agent.id)}
          className="p-2 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-900/30 text-rose-600"
          aria-label="Delete"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
