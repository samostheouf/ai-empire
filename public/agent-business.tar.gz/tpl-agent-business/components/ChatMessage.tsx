"use client";

import { Bot, User as UserIcon } from "lucide-react";

type Props = {
  role: "user" | "assistant" | "system";
  content: string;
  agentName?: string;
  streaming?: boolean;
};

export default function ChatMessage({ role, content, agentName, streaming }: Props) {
  const isUser = role === "user";
  return (
    <div className={`flex gap-3 ${isUser ? "justify-end" : "justify-start"}`}>
      {!isUser && (
        <div className="shrink-0 w-8 h-8 rounded-full bg-brand-600 flex items-center justify-center text-white">
          <Bot className="w-4 h-4" />
        </div>
      )}
      <div
        className={`max-w-[75%] rounded-2xl px-4 py-3 text-sm whitespace-pre-wrap ${
          isUser
            ? "bg-brand-600 text-white"
            : "bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white"
        }`}
      >
        {!isUser && agentName && (
          <div className="text-xs font-semibold text-brand-600 dark:text-brand-300 mb-1">{agentName}</div>
        )}
        {content}
        {streaming && <span className="inline-block w-1.5 h-4 ml-1 bg-current animate-pulse" />}
      </div>
      {isUser && (
        <div className="shrink-0 w-8 h-8 rounded-full bg-slate-300 dark:bg-slate-700 flex items-center justify-center text-slate-700 dark:text-slate-200">
          <UserIcon className="w-4 h-4" />
        </div>
      )}
    </div>
  );
}
