export type AgentStatus = "active" | "idle" | "error" | "disabled";
export type AgentModel = "gpt-4o" | "claude-3.5-sonnet" | "llama-3.1-70b" | "mistral-large";

export type Agent = {
  id: string;
  tenantId: string;
  name: string;
  description: string;
  model: AgentModel;
  status: AgentStatus;
  systemPrompt: string;
  temperature: number;
  maxTokens: number;
  tools: string[];
  createdAt: string;
  updatedAt: string;
  runs: number;
  costUsd: number;
};

export const AGENTS: Agent[] = [
  {
    id: "a1",
    tenantId: "t1",
    name: "Support Agent",
    description: "Handles customer support tickets and FAQs.",
    model: "gpt-4o",
    status: "active",
    systemPrompt: "You are a helpful customer support agent.",
    temperature: 0.3,
    maxTokens: 1024,
    tools: ["search_docs", "create_ticket"],
    createdAt: "2026-09-01T10:00:00Z",
    updatedAt: "2026-10-20T12:00:00Z",
    runs: 1240,
    costUsd: 42.18
  },
  {
    id: "a2",
    tenantId: "t1",
    name: "Sales Qualifier",
    description: "Qualifies inbound leads and books demos.",
    model: "claude-3.5-sonnet",
    status: "active",
    systemPrompt: "You are a sales qualification assistant.",
    temperature: 0.5,
    maxTokens: 2048,
    tools: ["crm_lookup", "calendar_book"],
    createdAt: "2026-09-05T10:00:00Z",
    updatedAt: "2026-10-22T09:00:00Z",
    runs: 860,
    costUsd: 31.4
  },
  {
    id: "a3",
    tenantId: "t1",
    name: "Data Analyst",
    description: "Answers questions over analytics data.",
    model: "llama-3.1-70b",
    status: "idle",
    systemPrompt: "You are a data analyst.",
    temperature: 0.2,
    maxTokens: 4096,
    tools: ["sql_query", "chart_render"],
    createdAt: "2026-09-10T10:00:00Z",
    updatedAt: "2026-10-18T15:00:00Z",
    runs: 320,
    costUsd: 8.9
  },
  {
    id: "a4",
    tenantId: "t1",
    name: "Content Writer",
    description: "Generates marketing copy and blog posts.",
    model: "mistral-large",
    status: "error",
    systemPrompt: "You are a content writer.",
    temperature: 0.7,
    maxTokens: 2048,
    tools: ["web_search"],
    createdAt: "2026-09-12T10:00:00Z",
    updatedAt: "2026-10-25T08:00:00Z",
    runs: 150,
    costUsd: 5.2
  }
];

export function listAgents(tenantId = "t1"): Agent[] {
  return AGENTS.filter((a) => a.tenantId === tenantId);
}

export function getAgent(id: string): Agent | undefined {
  return AGENTS.find((a) => a.id === id);
}

export function createAgent(input: Partial<Agent> & { name: string }): Agent {
  const a: Agent = {
    id: `a${Date.now()}`,
    tenantId: input.tenantId ?? "t1",
    name: input.name,
    description: input.description ?? "",
    model: input.model ?? "gpt-4o",
    status: "idle",
    systemPrompt: input.systemPrompt ?? "",
    temperature: input.temperature ?? 0.5,
    maxTokens: input.maxTokens ?? 1024,
    tools: input.tools ?? [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    runs: 0,
    costUsd: 0
  };
  AGENTS.push(a);
  return a;
}

export function updateAgent(id: string, patch: Partial<Agent>): Agent | null {
  const a = AGENTS.find((x) => x.id === id);
  if (!a) return null;
  Object.assign(a, patch, { updatedAt: new Date().toISOString() });
  return a;
}

export function deleteAgent(id: string): boolean {
  const idx = AGENTS.findIndex((x) => x.id === id);
  if (idx === -1) return false;
  AGENTS.splice(idx, 1);
  return true;
}
