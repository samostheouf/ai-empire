export type UsagePoint = { date: string; requests: number; tokens: number; cost: number };
export type AgentUsage = { agentId: string; name: string; requests: number; tokens: number; cost: number };
export type Overview = {
  totalRequests: number;
  totalTokens: number;
  totalCost: number;
  activeAgents: number;
  successRate: number;
  avgLatencyMs: number;
};

const days = 14;
export const USAGE_SERIES: UsagePoint[] = Array.from({ length: days }, (_, i) => {
  const d = new Date();
  d.setDate(d.getDate() - (days - 1 - i));
  const base = 120 + Math.round(Math.sin(i / 2) * 40);
  const requests = base + Math.round(Math.random() * 30);
  const tokens = requests * (400 + Math.round(Math.random() * 200));
  const cost = Number((tokens / 100000 * 0.6).toFixed(2));
  return { date: d.toISOString().slice(0, 10), requests, tokens, cost };
});

export const AGENT_USAGE: AgentUsage[] = [
  { agentId: "a1", name: "Support Agent", requests: 1240, tokens: 512000, cost: 42.18 },
  { agentId: "a2", name: "Sales Qualifier", requests: 860, tokens: 380000, cost: 31.4 },
  { agentId: "a3", name: "Data Analyst", requests: 320, tokens: 140000, cost: 8.9 },
  { agentId: "a4", name: "Content Writer", requests: 150, tokens: 62000, cost: 5.2 }
];

export function getOverview(): Overview {
  const totalRequests = USAGE_SERIES.reduce((s, p) => s + p.requests, 0);
  const totalTokens = USAGE_SERIES.reduce((s, p) => s + p.tokens, 0);
  const totalCost = Number(USAGE_SERIES.reduce((s, p) => s + p.cost, 0).toFixed(2));
  return {
    totalRequests,
    totalTokens,
    totalCost,
    activeAgents: 2,
    successRate: 98.4,
    avgLatencyMs: 642
  };
}

export function getModelBreakdown() {
  return [
    { name: "gpt-4o", value: 45 },
    { name: "claude-3.5-sonnet", value: 30 },
    { name: "llama-3.1-70b", value: 15 },
    { name: "mistral-large", value: 10 }
  ];
}
