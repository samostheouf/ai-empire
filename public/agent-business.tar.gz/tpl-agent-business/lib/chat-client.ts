export type ChatRole = "user" | "assistant" | "system";
export type ChatMessage = { id: string; role: ChatRole; content: string; agentId?: string; createdAt: number };

export type StreamChunk = { delta: string; done?: boolean };

export async function streamChat(
  messages: ChatMessage[],
  agentId: string,
  onChunk: (chunk: StreamChunk) => void,
  signal?: AbortSignal
): Promise<void> {
  const res = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ messages, agentId }),
    signal
  });
  if (!res.ok || !res.body) throw new Error("Chat request failed");
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith("data:")) continue;
      const payload = trimmed.slice(5).trim();
      if (payload === "[DONE]") {
        onChunk({ delta: "", done: true });
        return;
      }
      try {
        const json = JSON.parse(payload);
        onChunk({ delta: json.delta ?? "" });
      } catch {
        // ignore
      }
    }
  }
  onChunk({ delta: "", done: true });
}

export function agentReply(agentId: string, prompt: string): string {
  const replies: Record<string, string[]> = {
    a1: [
      "I can help with that! Could you share your order number?",
      "Let me look that up for you right away.",
      "I've created a support ticket. Is there anything else?"
    ],
    a2: [
      "Great, I'd love to qualify your needs. What's your company size?",
      "Thanks! I'll book a demo slot for you.",
      "I've logged your interest in our CRM."
    ],
    a3: [
      "Querying the database now...",
      "Here are the top metrics for last week.",
      "I rendered a chart of the trend."
    ],
    a4: [
      "Drafting copy now...",
      "Here's a first draft of the blog post.",
      "I can refine the tone if you'd like."
    ]
  };
  const list = replies[agentId] ?? ["I'm here to help."];
  return list[Math.floor(Math.random() * list.length)];
}
