export type Tenant = { id: string; name: string };
export type Role = "owner" | "admin" | "member" | "viewer";

export type User = {
  id: string;
  email: string;
  name: string;
  role: Role;
  tenantId: string;
};

export type Session = {
  user: User;
  token: string;
  expiresAt: number;
};

const SESSION_KEY = "neura_session";

export function createSession(user: User): Session {
  return {
    user,
    token: `tok_${Math.random().toString(36).slice(2)}_${Date.now()}`,
    expiresAt: Date.now() + 1000 * 60 * 60 * 24 * 7,
  };
}

export function saveSession(session: Session) {
  if (typeof window === "undefined") return;
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
}

export function loadSession(): Session | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const s = JSON.parse(raw) as Session;
    if (s.expiresAt < Date.now()) {
      localStorage.removeItem(SESSION_KEY);
      return null;
    }
    return s;
  } catch {
    return null;
  }
}

export function clearSession() {
  if (typeof window === "undefined") return;
  localStorage.removeItem(SESSION_KEY);
}

export const DEMO_USERS: User[] = [
  { id: "u1", email: "owner@demo.com", name: "Alex Owner", role: "owner", tenantId: "t1" },
  { id: "u2", email: "admin@demo.com", name: "Sam Admin", role: "admin", tenantId: "t1" },
  { id: "u3", email: "member@demo.com", name: "Mia Member", role: "member", tenantId: "t1" }
];

export function findUser(email: string, password: string): User | null {
  // mock: password is always "demo123"
  if (password !== "demo123") return null;
  return DEMO_USERS.find((u) => u.email.toLowerCase() === email.toLowerCase()) ?? null;
}

export function hasPermission(role: Role, action: string): boolean {
  const perms: Record<Role, string[]> = {
    owner: ["*"],
    admin: ["read", "write", "manage_agents", "view_analytics", "manage_billing"],
    member: ["read", "write", "view_analytics"],
    viewer: ["read"]
  };
  const list = perms[role];
  return list.includes("*") || list.includes(action);
}
