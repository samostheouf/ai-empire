# NeuraAPI AI Agents Business Template

Multi-tenant AI agent platform template (Next.js 14 App Router, TypeScript, Tailwind).

## Setup

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Demo login

- owner@demo.com / demo123
- admin@demo.com / demo123
- member@demo.com / demo123

## Pages

- `/` landing
- `/dashboard` admin overview
- `/agents` multi-agent management
- `/chat` multi-agent chat (streaming)
- `/analytics` usage charts
- `/settings` billing + API keys
- `/login`

## API routes

- `POST /api/auth` login
- `GET/POST/PATCH/DELETE /api/agents`
- `POST /api/chat` streaming SSE
- `GET /api/analytics`

## Structure

- `components/` Header, Sidebar, DashboardCard, AgentCard, ChatMessage, Chart, Modal
- `lib/` chat-client.ts, agents.ts, analytics.ts, auth.ts

## Deploy

Vercel-ready. Set env vars as needed. Replace mock data in `lib/` with real backends.

## License

Commercial template by NeuraAPI (149€).
