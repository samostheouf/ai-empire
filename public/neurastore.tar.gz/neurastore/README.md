# NeuraStore — Premium E-commerce Template

A modern, production-ready e-commerce template built with Next.js 14 and Tailwind CSS. Features a stunning dark-themed design with gradient accents, glass-morphism effects, and smooth animations.

## Features

- **Next.js 14 App Router** — Modern routing with server components
- **Tailwind CSS** — Utility-first styling with custom design system
- **Dark Mode** — Built-in dark/light theme toggle
- **Responsive Design** — Mobile-first, works on all devices
- **Cart Functionality** — Full cart with context-based state management
- **Product Pages** — Individual product pages with image galleries
- **Checkout Flow** — Complete checkout form with order summary
- **Filter & Sort** — Product filtering by category and sorting by price
- **Premium UI** — Gradient accents, glass-morphism, hover animations

## Getting Started

### Prerequisites

- Node.js 18+ installed
- npm or yarn package manager

### Installation

```bash
# Navigate to the template directory
cd neurastore

# Install dependencies
npm install

# Start the development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) to view the store.

### Build for Production

```bash
npm run build
npm start
```

## Project Structure

```
neurastore/
├── src/
│   ├── app/
│   │   ├── layout.tsx          # Root layout
│   │   ├── page.tsx            # Homepage
│   │   ├── globals.css         # Global styles
│   │   ├── products/
│   │   │   ├── page.tsx        # All products
│   │   │   └── [slug]/
│   │   │       └── page.tsx    # Single product
│   │   ├── checkout/
│   │   │   └── page.tsx        # Checkout flow
│   │   └── cart/
│   │       └── page.tsx        # Cart page
│   ├── components/
│   │   ├── Header.tsx          # Navigation
│   │   ├── Footer.tsx          # Footer
│   │   ├── ProductCard.tsx     # Product cards
│   │   ├── CartDrawer.tsx      # Slide-out cart
│   │   ├── DarkModeToggle.tsx  # Theme toggle
│   │   └── FilterBar.tsx       # Product filters
│   └── lib/
│       ├── cart-context.tsx    # Cart state management
│       └── products.ts         # Product data
├── tailwind.config.ts          # Tailwind configuration
├── tsconfig.json               # TypeScript config
├── postcss.config.js           # PostCSS config
├── next.config.js              # Next.js config
└── package.json                # Dependencies
```

## Customization

### Colors

Edit `tailwind.config.ts` to customize the brand colors. The template uses a blue-to-purple gradient theme by default.

### Products

Update `src/lib/products.ts` to add or modify product data. Each product includes:
- `id` — Unique identifier
- `slug` — URL-friendly name
- `name` — Display name
- `description` — Product description
- `price` — Price in EUR
- `images` — Array of image URLs
- `category` — Product category
- `rating` — Star rating (1-5)
- `reviews` — Number of reviews
- `inStock` — Availability status

### Styling

The template uses a custom Tailwind configuration with:
- Custom color palette (`brand-*`, `neon-*`)
- Custom animations (`fade-in`, `slide-up`, `float`, etc.)
- Custom shadows (`glow`, `neon`)
- Gradient utilities (`gradient-brand`, `gradient-dark`)

## Tech Stack

- [Next.js 14](https://nextjs.org/)
- [React 18](https://react.dev/)
- [TypeScript](https://www.typescriptlang.org/)
- [Tailwind CSS 3](https://tailwindcss.com/)
- [Lucide React](https://lucide.dev/) for icons

## License

This template is for personal and commercial use. You may modify it to suit your needs.
