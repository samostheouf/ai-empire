export interface Product {
  id: string;
  slug: string;
  name: string;
  description: string;
  longDescription: string;
  price: number;
  originalPrice?: number;
  images: string[];
  category: string;
  rating: number;
  reviews: number;
  inStock: boolean;
  features: string[];
  specs: { label: string; value: string }[];
}

export const categories = [
  "All",
  "Electronics",
  "Audio",
  "Wearables",
  "Accessories",
  "Smart Home",
] as const;

export type Category = (typeof categories)[number];

export const products: Product[] = [
  {
    id: "1",
    slug: "quantum-pro-headphones",
    name: "Quantum Pro Headphones",
    description:
      "Premium noise-cancelling wireless headphones with spatial audio and 40-hour battery life.",
    longDescription:
      "Experience audio like never before with the Quantum Pro Headphones. Featuring advanced active noise cancellation, spatial audio support, and a comfortable over-ear design, these headphones deliver studio-quality sound wherever you go. The 40-hour battery life means you can listen all day and night without interruption.",
    price: 299.99,
    originalPrice: 349.99,
    images: [
      "https://placehold.co/800x800/1a1b2e/6366f1?text=Headphones+1",
      "https://placehold.co/800x800/1a1b2e/8b5cf6?text=Headphones+2",
      "https://placehold.co/800x800/1a1b2e/ec4899?text=Headphones+3",
    ],
    category: "Audio",
    rating: 4.8,
    reviews: 2341,
    inStock: true,
    features: [
      "Active Noise Cancellation",
      "Spatial Audio",
      "40-Hour Battery",
      "Bluetooth 5.3",
      "USB-C Charging",
      "Foldable Design",
    ],
    specs: [
      { label: "Driver Size", value: "40mm" },
      { label: "Frequency Response", value: "4Hz - 40kHz" },
      { label: "Battery Life", value: "40 hours" },
      { label: "Weight", value: "250g" },
      { label: "Connectivity", value: "Bluetooth 5.3" },
      { label: "Charging", value: "USB-C" },
    ],
  },
  {
    id: "2",
    slug: "nebula-smartwatch",
    name: "Nebula Smartwatch",
    description:
      "Advanced smartwatch with health monitoring, GPS, and seamless smartphone integration.",
    longDescription:
      "The Nebula Smartwatch is your ultimate health and fitness companion. Track your heart rate, blood oxygen, sleep patterns, and over 100 workout types. With built-in GPS and 5-day battery life, it's ready for any adventure. Seamless integration with both iOS and Android keeps you connected.",
    price: 249.99,
    images: [
      "https://placehold.co/800x800/1a1b2e/6366f1?text=Watch+1",
      "https://placehold.co/800x800/1a1b2e/8b5cf6?text=Watch+2",
      "https://placehold.co/800x800/1a1b2e/ec4899?text=Watch+3",
    ],
    category: "Wearables",
    rating: 4.6,
    reviews: 1892,
    inStock: true,
    features: [
      "Heart Rate Monitor",
      "Blood Oxygen Sensor",
      "Built-in GPS",
      "5-Day Battery",
      "Water Resistant 50m",
      "Always-On Display",
    ],
    specs: [
      { label: "Display", value: '1.9" AMOLED' },
      { label: "Resolution", value: "502 x 410" },
      { label: "Battery Life", value: "5 days" },
      { label: "Water Resistance", value: "5 ATM" },
      { label: "Sensors", value: "HR, SpO2, Gyro" },
      { label: "Weight", value: "45g" },
    ],
  },
  {
    id: "3",
    slug: "echo-portable-speaker",
    name: "Echo Portable Speaker",
    description:
      "360-degree sound with deep bass, waterproof design, and 24-hour playtime.",
    longDescription:
      "Fill any room or outdoor space with rich, immersive sound. The Echo Portable Speaker delivers 360-degree audio with powerful bass that belies its compact size. IP67 waterproof rating means it's ready for pool parties, beach days, and everything in between.",
    price: 129.99,
    originalPrice: 159.99,
    images: [
      "https://placehold.co/800x800/1a1b2e/6366f1?text=Speaker+1",
      "https://placehold.co/800x800/1a1b2e/8b5cf6?text=Speaker+2",
      "https://placehold.co/800x800/1a1b2e/ec4899?text=Speaker+3",
    ],
    category: "Audio",
    rating: 4.7,
    reviews: 3156,
    inStock: true,
    features: [
      "360° Sound",
      "Deep Bass Radiator",
      "IP67 Waterproof",
      "24-Hour Battery",
      "Multi-Device Pairing",
      "Built-in Microphone",
    ],
    specs: [
      { label: "Power Output", value: "30W" },
      { label: "Battery Life", value: "24 hours" },
      { label: "Water Rating", value: "IP67" },
      { label: "Weight", value: "680g" },
      { label: "Bluetooth", value: "5.0" },
      { label: "Dimensions", value: "18 x 18 x 12cm" },
    ],
  },
  {
    id: "4",
    slug: "apex-true-wireless-earbuds",
    name: "Apex True Wireless Earbuds",
    description:
      "Crystal-clear audio with adaptive noise cancellation and premium comfort fit.",
    longDescription:
      "The Apex True Wireless Earbuds combine premium sound quality with all-day comfort. Adaptive noise cancellation automatically adjusts to your environment, while the ergonomic design ensures a secure fit during any activity. With wireless charging and quick charge support, they're always ready when you are.",
    price: 179.99,
    images: [
      "https://placehold.co/800x800/1a1b2e/6366f1?text=Earbuds+1",
      "https://placehold.co/800x800/1a1b2e/8b5cf6?text=Earbuds+2",
      "https://placehold.co/800x800/1a1b2e/ec4899?text=Earbuds+3",
    ],
    category: "Audio",
    rating: 4.5,
    reviews: 4521,
    inStock: true,
    features: [
      "Adaptive ANC",
      "Transparency Mode",
      "Wireless Charging",
      "8-Hour Battery + 24H Case",
      "IPX4 Sweat Resistant",
      "Touch Controls",
    ],
    specs: [
      { label: "Driver Size", value: "11mm" },
      { label: "Battery Life", value: "8h + 24h" },
      { label: "Water Resistance", value: "IPX4" },
      { label: "Weight", value: "5.4g per earbud" },
      { label: "Bluetooth", value: "5.3" },
      { label: "Charging", value: "USB-C / Qi" },
    ],
  },
  {
    id: "5",
    slug: "flux-mechanical-keyboard",
    name: "Flux Mechanical Keyboard",
    description:
      "Premium mechanical keyboard with hot-swappable switches and per-key RGB lighting.",
    longDescription:
      "The Flux Mechanical Keyboard is built for enthusiasts and professionals alike. Hot-swappable switches let you customize your typing experience without soldering. Per-key RGB lighting with dynamic effects makes your desk setup stand out. The aircraft-grade aluminum frame ensures durability for years of heavy use.",
    price: 169.99,
    originalPrice: 199.99,
    images: [
      "https://placehold.co/800x800/1a1b2e/6366f1?text=Keyboard+1",
      "https://placehold.co/800x800/1a1b2e/8b5cf6?text=Keyboard+2",
      "https://placehold.co/800x800/1a1b2e/ec4899?text=Keyboard+3",
    ],
    category: "Accessories",
    rating: 4.9,
    reviews: 892,
    inStock: true,
    features: [
      "Hot-Swappable Switches",
      "Per-Key RGB",
      "Aluminum Frame",
      "PBT Keycaps",
      "USB-C / Bluetooth",
      "Macro Support",
    ],
    specs: [
      { label: "Layout", value: "75% (84 keys)" },
      { label: "Switch Type", value: "Hot-swap 3/5-pin" },
      { label: "Keycaps", value: "Double-shot PBT" },
      { label: "Connection", value: "USB-C / BT 5.1" },
      { label: "Battery", value: "4000mAh" },
      { label: "Weight", value: "900g" },
    ],
  },
  {
    id: "6",
    slug: "vortex-4k-webcam",
    name: "Vortex 4K Webcam",
    description:
      "Professional 4K webcam with AI-powered framing, low-light correction, and noise cancellation.",
    longDescription:
      "Look your best in every call with the Vortex 4K Webcam. AI-powered auto-framing keeps you centered as you move, while advanced low-light correction ensures a clear image in any lighting condition. The built-in dual-mic array with noise cancellation makes your voice sound crisp and professional.",
    price: 149.99,
    images: [
      "https://placehold.co/800x800/1a1b2e/6366f1?text=Webcam+1",
      "https://placehold.co/800x800/1a1b2e/8b5cf6?text=Webcam+2",
      "https://placehold.co/800x800/1a1b2e/ec4899?text=Webcam+3",
    ],
    category: "Electronics",
    rating: 4.4,
    reviews: 1245,
    inStock: true,
    features: [
      "4K Ultra HD",
      "AI Auto-Framing",
      "Low-Light Correction",
      "Dual Noise-Cancelling Mics",
      "Privacy Shutter",
      "USB-C Plug & Play",
    ],
    specs: [
      { label: "Resolution", value: "4K @ 30fps" },
      { label: "FOV", value: "90°" },
      { label: "Microphones", value: "Dual array" },
      { label: "Connection", value: "USB-C" },
      { label: "Mount", value: "Clip + Tripod" },
      { label: "Weight", value: "170g" },
    ],
  },
  {
    id: "7",
    slug: "pulse-fitness-tracker",
    name: "Pulse Fitness Tracker",
    description:
      "Slim fitness band with 24/7 health tracking, sleep analysis, and 10-day battery life.",
    longDescription:
      "The Pulse Fitness Tracker wraps advanced health technology in a sleek, comfortable design. Monitor your heart rate continuously, track blood oxygen levels, analyze your sleep quality, and log over 20 workout types automatically. With 10-day battery life and a vibrant AMOLED display, it's the perfect everyday health companion.",
    price: 79.99,
    images: [
      "https://placehold.co/800x800/1a1b2e/6366f1?text=Tracker+1",
      "https://placehold.co/800x800/1a1b2e/8b5cf6?text=Tracker+2",
      "https://placehold.co/800x800/1a1b2e/ec4899?text=Tracker+3",
    ],
    category: "Wearables",
    rating: 4.3,
    reviews: 2890,
    inStock: true,
    features: [
      "24/7 Heart Rate",
      "Sleep Analysis",
      "Blood Oxygen Monitor",
      "10-Day Battery",
      "50m Water Resistant",
      "AMOLED Display",
    ],
    specs: [
      { label: "Display", value: '1.1" AMOLED' },
      { label: "Battery Life", value: "10 days" },
      { label: "Water Resistance", value: "5 ATM" },
      { label: "Weight", value: "24g" },
      { label: "Sensors", value: "HR, SpO2" },
      { label: "Strap", value: "Silicone" },
    ],
  },
  {
    id: "8",
    slug: "arc-smart-plug",
    name: "Arc Smart Plug",
    description:
      "WiFi smart plug with energy monitoring, voice control, and scheduling features.",
    longDescription:
      "Transform any appliance into a smart device with the Arc Smart Plug. Monitor real-time energy consumption to reduce your electricity bill. Set schedules and timers to automate your home. Compatible with Alexa, Google Home, and Apple HomeKit for seamless voice control.",
    price: 29.99,
    originalPrice: 39.99,
    images: [
      "https://placehold.co/800x800/1a1b2e/6366f1?text=Plug+1",
      "https://placehold.co/800x800/1a1b2e/8b5cf6?text=Plug+2",
      "https://placehold.co/800x800/1a1b2e/ec4899?text=Plug+3",
    ],
    category: "Smart Home",
    rating: 4.6,
    reviews: 5678,
    inStock: true,
    features: [
      "Energy Monitoring",
      "Voice Control",
      "Scheduling & Timers",
      "Away Mode",
      "No Hub Required",
      "Compact Design",
    ],
    specs: [
      { label: "Connectivity", value: "WiFi 2.4GHz" },
      { label: "Max Load", value: "15A / 1800W" },
      { label: "Compatibility", value: "Alexa, Google, HK" },
      { label: "App", value: "iOS / Android" },
      { label: "Dimensions", value: "5.2 x 5.2 x 3.1cm" },
      { label: "Certification", value: "CE, FCC" },
    ],
  },
  {
    id: "9",
    slug: "prism-usb-c-hub",
    name: "Prism USB-C Hub",
    description:
      "7-in-1 USB-C hub with 4K HDMI, 100W PD, SD card reader, and Gigabit Ethernet.",
    longDescription:
      "The Prism USB-C Hub is the ultimate connectivity solution for your laptop. Expand a single USB-C port into seven versatile connections: 4K HDMI, USB-A 3.0, SD/microSD card readers, Gigabit Ethernet, and 100W Power Delivery pass-through. The slim, aluminum design matches your laptop perfectly.",
    price: 59.99,
    images: [
      "https://placehold.co/800x800/1a1b2e/6366f1?text=Hub+1",
      "https://placehold.co/800x800/1a1b2e/8b5cf6?text=Hub+2",
      "https://placehold.co/800x800/1a1b2e/ec4899?text=Hub+3",
    ],
    category: "Accessories",
    rating: 4.7,
    reviews: 3421,
    inStock: true,
    features: [
      "4K HDMI Output",
      "100W Power Delivery",
      "Gigabit Ethernet",
      "USB-A 3.0 x3",
      "SD + microSD Reader",
      "Aluminum Shell",
    ],
    specs: [
      { label: "Ports", value: "7-in-1" },
      { label: "HDMI", value: "4K @ 30Hz" },
      { label: "USB-A", value: "3.0 (5Gbps) x3" },
      { label: "Ethernet", value: "Gigabit" },
      { label: "PD", value: "100W pass-through" },
      { label: "Weight", value: "85g" },
    ],
  },
  {
    id: "10",
    slug: "zen-wireless-charger",
    name: "Zen Wireless Charger",
    description:
      "15W fast wireless charger with MagSafe compatibility, LED indicator, and anti-slip pad.",
    longDescription:
      "The Zen Wireless Charger delivers fast, efficient charging for all Qi-compatible devices. With 15W output and MagSafe alignment for iPhones, your devices charge quickly and reliably. The anti-slip silicone pad keeps your phone secure, while the subtle LED indicator shows charging status at a glance.",
    price: 39.99,
    originalPrice: 49.99,
    images: [
      "https://placehold.co/800x800/1a1b2e/6366f1?text=Charger+1",
      "https://placehold.co/800x800/1a1b2e/8b5cf6?text=Charger+2",
      "https://placehold.co/800x800/1a1b2e/ec4899?text=Charger+3",
    ],
    category: "Accessories",
    rating: 4.5,
    reviews: 1987,
    inStock: true,
    features: [
      "15W Fast Charging",
      "MagSafe Compatible",
      "Qi Certified",
      "Anti-Slip Design",
      "LED Status Indicator",
      "Overheat Protection",
    ],
    specs: [
      { label: "Output", value: "5W / 7.5W / 10W / 15W" },
      { label: "Input", value: "USB-C 20W" },
      { label: "Compatibility", value: "Qi / MagSafe" },
      { label: "Dimensions", value: "10cm diameter" },
      { label: "Weight", value: "120g" },
      { label: "Cable", value: "USB-C (included)" },
    ],
  },
];

export function getProductBySlug(slug: string): Product | undefined {
  return products.find((p) => p.slug === slug);
}

export function getProductsByCategory(category: string): Product[] {
  if (category === "All") return products;
  return products.filter((p) => p.category === category);
}

export function getRelatedProducts(product: Product, limit = 4): Product[] {
  return products
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, limit);
}

export function formatPrice(price: number): string {
  return new Intl.NumberFormat("en-EU", {
    style: "currency",
    currency: "EUR",
  }).format(price);
}
