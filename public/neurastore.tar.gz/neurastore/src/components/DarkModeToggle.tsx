"use client";

import { useEffect, useState } from "react";
import { Sun, Moon } from "lucide-react";

export default function DarkModeToggle() {
  const [darkMode, setDarkMode] = useState(true);

  useEffect(() => {
    const isDark = localStorage.getItem("darkMode") !== "false";
    setDarkMode(isDark);
    document.documentElement.classList.toggle("dark", isDark);
  }, []);

  const toggle = () => {
    const newMode = !darkMode;
    setDarkMode(newMode);
    localStorage.setItem("darkMode", String(newMode));
    document.documentElement.classList.toggle("dark", newMode);
  };

  return (
    <button
      onClick={toggle}
      className="relative p-2.5 rounded-xl bg-gray-100 dark:bg-white/5
                 border border-gray-200 dark:border-white/10
                 hover:bg-gray-200 dark:hover:bg-white/10
                 transition-all duration-300 group"
      aria-label="Toggle dark mode"
    >
      <Sun
        className={`w-5 h-5 text-amber-500 transition-all duration-300
                    ${
                      darkMode
                        ? "opacity-0 rotate-90 scale-0"
                        : "opacity-100 rotate-0 scale-100"
                    }`}
      />
      <Moon
        className={`w-5 h-5 text-brand-400 absolute inset-0 m-auto
                    transition-all duration-300
                    ${
                      darkMode
                        ? "opacity-100 rotate-0 scale-100"
                        : "opacity-0 -rotate-90 scale-0"
                    }`}
      />
    </button>
  );
}
