"use client";

import { useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { X, Plus, Minus, ShoppingBag, ArrowRight } from "lucide-react";
import { useCart } from "@/lib/cart-context";
import { formatPrice } from "@/lib/products";

export default function CartDrawer() {
  const { items, isOpen, closeCart, removeItem, updateQuantity, totalItems, totalPrice } =
    useCart();

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50">
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-fade-in"
        onClick={closeCart}
      />

      <div className="absolute right-0 top-0 h-full w-full max-w-md
                      bg-white dark:bg-gray-950 border-l border-gray-200 dark:border-white/10
                      shadow-2xl animate-slide-in-right
                      flex flex-col">
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-200 dark:border-white/10">
          <div className="flex items-center gap-3">
            <ShoppingBag className="w-5 h-5 text-brand-500" />
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
              Your Cart
            </h2>
            {totalItems > 0 && (
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold
                               bg-brand-500/10 text-brand-500">
                {totalItems}
              </span>
            )}
          </div>
          <button
            onClick={closeCart}
            className="p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-white/5
                       transition-colors duration-200"
            aria-label="Close cart"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-4">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <div className="w-20 h-20 rounded-2xl bg-gray-100 dark:bg-white/5
                              flex items-center justify-center mb-4">
                <ShoppingBag className="w-10 h-10 text-gray-300 dark:text-gray-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                Cart is empty
              </h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
                Add some products to get started
              </p>
              <button
                onClick={closeCart}
                className="btn-primary text-sm"
              >
                Continue Shopping
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {items.map((item) => (
                <div
                  key={item.product.id}
                  className="flex gap-4 p-3 rounded-xl
                             bg-gray-50 dark:bg-white/[0.02]
                             border border-gray-100 dark:border-white/5
                             group"
                >
                  <div className="relative w-20 h-20 rounded-lg overflow-hidden
                                  bg-gray-200 dark:bg-white/5 shrink-0">
                    <Image
                      src={item.product.images[0]}
                      alt={item.product.name}
                      fill
                      className="object-cover"
                      sizes="80px"
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-semibold text-gray-900 dark:text-white
                                   line-clamp-1 mb-1">
                      {item.product.name}
                    </h4>
                    <p className="text-sm font-medium text-brand-500 mb-2">
                      {formatPrice(item.product.price)}
                    </p>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() =>
                            updateQuantity(item.product.id, item.quantity - 1)
                          }
                          className="w-7 h-7 rounded-lg bg-gray-200 dark:bg-white/10
                                     flex items-center justify-center
                                     hover:bg-gray-300 dark:hover:bg-white/20
                                     transition-colors duration-200"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-8 text-center text-sm font-medium
                                         text-gray-900 dark:text-white">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() =>
                            updateQuantity(item.product.id, item.quantity + 1)
                          }
                          className="w-7 h-7 rounded-lg bg-gray-200 dark:bg-white/10
                                     flex items-center justify-center
                                     hover:bg-gray-300 dark:hover:bg-white/20
                                     transition-colors duration-200"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <button
                        onClick={() => removeItem(item.product.id)}
                        className="text-xs text-gray-400 hover:text-red-500
                                   transition-colors duration-200"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {items.length > 0 && (
          <div className="px-6 py-5 border-t border-gray-200 dark:border-white/10">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm text-gray-500 dark:text-gray-400">Subtotal</span>
              <span className="text-lg font-bold text-gray-900 dark:text-white">
                {formatPrice(totalPrice)}
              </span>
            </div>
            <p className="text-xs text-gray-400 dark:text-gray-500 mb-4">
              Shipping and taxes calculated at checkout
            </p>
            <Link
              href="/checkout"
              onClick={closeCart}
              className="btn-primary flex items-center justify-center gap-2 w-full text-sm"
            >
              Checkout
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              href="/cart"
              onClick={closeCart}
              className="btn-secondary flex items-center justify-center w-full text-sm mt-2"
            >
              View Full Cart
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
