"use client";

import { useState } from "react";
import Link from "next/link";
import { ShoppingCart, Menu, X, Zap } from "lucide-react";
import { useCart } from "@/lib/cart-context";
import DarkModeToggle from "./DarkModeToggle";

const navLinks = [
  { href: "/", label: "Home" },
  { href: "/products", label: "Products" },
];

export default function Header() {
  const { totalItems, toggleCart } = useCart();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 glass-strong">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          <Link href="/" className="flex items-center gap-2.5 group">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-brand-500 via-neon-purple to-neon-pink
                            flex items-center justify-center shadow-glow
                            group-hover:shadow-neon transition-shadow duration-300">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold gradient-text hidden sm:block">
              NeuraStore
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="px-4 py-2 text-sm font-medium text-gray-600 dark:text-gray-300
                           rounded-lg hover:text-gray-900 dark:hover:text-white
                           hover:bg-gray-100 dark:hover:bg-white/5
                           transition-all duration-200"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <DarkModeToggle />

            <button
              onClick={toggleCart}
              className="relative p-2.5 rounded-xl bg-gray-100 dark:bg-white/5
                         border border-gray-200 dark:border-white/10
                         hover:bg-gray-200 dark:hover:bg-white/10
                         transition-all duration-300"
              aria-label="Shopping cart"
            >
              <ShoppingCart className="w-5 h-5 text-gray-700 dark:text-gray-300" />
              {totalItems > 0 && (
                <span className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full
                                 bg-gradient-to-r from-brand-500 to-neon-pink
                                 text-white text-[10px] font-bold
                                 flex items-center justify-center
                                 animate-pulse-glow">
                  {totalItems}
                </span>
              )}
            </button>

            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden p-2.5 rounded-xl bg-gray-100 dark:bg-white/5
                         border border-gray-200 dark:border-white/10
                         hover:bg-gray-200 dark:hover:bg-white/10
                         transition-all duration-300"
              aria-label="Toggle menu"
            >
              {mobileOpen ? (
                <X className="w-5 h-5 text-gray-700 dark:text-gray-300" />
              ) : (
                <Menu className="w-5 h-5 text-gray-700 dark:text-gray-300" />
              )}
            </button>
          </div>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden border-t border-gray-200 dark:border-white/10 animate-slide-up">
          <div className="px-4 py-4 space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="block px-4 py-3 text-sm font-medium text-gray-600 dark:text-gray-300
                           rounded-xl hover:text-gray-900 dark:hover:text-white
                           hover:bg-gray-100 dark:hover:bg-white/5
                           transition-all duration-200"
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
