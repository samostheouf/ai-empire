"use client";

import { SlidersHorizontal, ChevronDown } from "lucide-react";
import { categories, Category } from "@/lib/products";

interface FilterBarProps {
  selectedCategory: string;
  sortBy: string;
  onCategoryChange: (category: string) => void;
  onSortChange: (sort: string) => void;
}

export default function FilterBar({
  selectedCategory,
  sortBy,
  onCategoryChange,
  onSortChange,
}: FilterBarProps) {
  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4
                    p-4 rounded-2xl glass">
      <div className="flex items-center gap-2 flex-wrap">
        <SlidersHorizontal className="w-4 h-4 text-gray-400 shrink-0" />
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => onCategoryChange(category)}
            className={`px-3.5 py-1.5 rounded-lg text-sm font-medium
                        transition-all duration-200
                        ${
                          selectedCategory === category
                            ? "bg-brand-500 text-white shadow-glow"
                            : "bg-gray-100 dark:bg-white/5 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-white/10"
                        }`}
          >
            {category}
          </button>
        ))}
      </div>

      <div className="relative">
        <select
          value={sortBy}
          onChange={(e) => onSortChange(e.target.value)}
          className="appearance-none pl-3.5 pr-9 py-2 rounded-xl text-sm font-medium
                     bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10
                     text-gray-700 dark:text-gray-300
                     focus:outline-none focus:ring-2 focus:ring-brand-500/50
                     transition-all duration-200 cursor-pointer"
        >
          <option value="featured">Featured</option>
          <option value="price-asc">Price: Low to High</option>
          <option value="price-desc">Price: High to Low</option>
          <option value="rating">Top Rated</option>
          <option value="newest">Newest</option>
        </select>
        <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4
                                text-gray-400 pointer-events-none" />
      </div>
    </div>
  );
}
