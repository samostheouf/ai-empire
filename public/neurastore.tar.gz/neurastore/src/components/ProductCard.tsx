"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { ShoppingCart, Star, Eye } from "lucide-react";
import { Product, formatPrice } from "@/lib/products";
import { useCart } from "@/lib/cart-context";

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart();
  const [isAdding, setIsAdding] = useState(false);
  const [imageIndex, setImageIndex] = useState(0);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsAdding(true);
    addItem(product);
    setTimeout(() => setIsAdding(false), 600);
  };

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : null;

  return (
    <div className="group relative bg-white dark:bg-white/[0.02] rounded-2xl
                    border border-gray-200 dark:border-white/5
                    overflow-hidden card-hover">
      <Link href={`/products/${product.slug}`} className="block">
        <div className="relative aspect-square overflow-hidden bg-gray-100 dark:bg-white/5">
          <Image
            src={product.images[imageIndex]}
            alt={product.name}
            fill
            className="object-cover transition-transform duration-700 ease-out
                       group-hover:scale-110"
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
          />

          {discount && (
            <div className="absolute top-3 left-3 px-2.5 py-1 rounded-lg
                            bg-gradient-to-r from-neon-pink to-neon-purple
                            text-white text-xs font-bold">
              -{discount}%
            </div>
          )}

          <div className="absolute inset-x-0 bottom-0 p-3 flex justify-center
                          opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0
                          transition-all duration-300">
            <Link
              href={`/products/${product.slug}`}
              className="flex items-center gap-2 px-4 py-2 rounded-xl
                         bg-white/90 dark:bg-black/70 backdrop-blur-sm
                         text-gray-900 dark:text-white text-sm font-medium
                         hover:bg-white dark:hover:bg-black/90
                         transition-colors duration-200"
            >
              <Eye className="w-4 h-4" />
              Quick View
            </Link>
          </div>

          {product.images.length > 1 && (
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5
                            opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              {product.images.map((_, i) => (
                <button
                  key={i}
                  onClick={(e) => {
                    e.preventDefault();
                    setImageIndex(i);
                  }}
                  className={`w-2 h-2 rounded-full transition-all duration-200
                              ${
                                i === imageIndex
                                  ? "bg-brand-500 w-4"
                                  : "bg-white/50 hover:bg-white/80"
                              }`}
                  aria-label={`Image ${i + 1}`}
                />
              ))}
            </div>
          )}
        </div>
      </Link>

      <div className="p-5">
        <div className="flex items-center gap-1.5 mb-2">
          <div className="flex items-center gap-0.5">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`w-3.5 h-3.5 ${
                  i < Math.floor(product.rating)
                    ? "fill-amber-400 text-amber-400"
                    : "text-gray-300 dark:text-gray-600"
                }`}
              />
            ))}
          </div>
          <span className="text-xs text-gray-500 dark:text-gray-400">
            ({product.reviews.toLocaleString()})
          </span>
        </div>

        <Link href={`/products/${product.slug}`}>
          <h3 className="text-base font-semibold text-gray-900 dark:text-white
                         line-clamp-1 group-hover:text-brand-500 dark:group-hover:text-brand-400
                         transition-colors duration-200 mb-1">
            {product.name}
          </h3>
        </Link>
        <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-2 mb-4 leading-relaxed">
          {product.description}
        </p>

        <div className="flex items-center justify-between">
          <div className="flex items-baseline gap-2">
            <span className="text-lg font-bold text-gray-900 dark:text-white">
              {formatPrice(product.price)}
            </span>
            {product.originalPrice && (
              <span className="text-sm text-gray-400 line-through">
                {formatPrice(product.originalPrice)}
              </span>
            )}
          </div>

          <button
            onClick={handleAddToCart}
            disabled={isAdding}
            className={`p-2.5 rounded-xl transition-all duration-300
                        ${
                          isAdding
                            ? "bg-green-500 text-white scale-95"
                            : "bg-brand-500/10 text-brand-500 hover:bg-brand-500 hover:text-white hover:shadow-glow"
                        }`}
            aria-label="Add to cart"
          >
            <ShoppingCart className={`w-4 h-4 transition-transform duration-300
                                    ${isAdding ? "scale-110" : ""}`} />
          </button>
        </div>
      </div>
    </div>
  );
}
