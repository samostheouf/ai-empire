"use client";

import { useState, use } from "react";
import Image from "next/image";
import Link from "next/link";
import { ShoppingCart, Star, ChevronRight, Minus, Plus, Check, Truck, Shield, RotateCcw } from "lucide-react";
import { getProductBySlug, getRelatedProducts, formatPrice, products } from "@/lib/products";
import { useCart } from "@/lib/cart-context";
import ProductCard from "@/components/ProductCard";
import { notFound } from "next/navigation";

interface ProductPageProps {
  params: Promise<{ slug: string }>;
}

export default function ProductPage({ params }: ProductPageProps) {
  const { slug } = use(params);
  const product = getProductBySlug(slug);

  if (!product) {
    notFound();
  }

  const { addItem } = useCart();
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [isAdding, setIsAdding] = useState(false);

  const relatedProducts = getRelatedProducts(product, 4);

  const handleAddToCart = () => {
    setIsAdding(true);
    addItem(product, quantity);
    setTimeout(() => setIsAdding(false), 800);
  };

  return (
    <div className="page-container">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 mb-8">
        <Link href="/" className="hover:text-brand-500 transition-colors duration-200">
          Home
        </Link>
        <ChevronRight className="w-3 h-3" />
        <Link href="/products" className="hover:text-brand-500 transition-colors duration-200">
          Products
        </Link>
        <ChevronRight className="w-3 h-3" />
        <span className="text-gray-900 dark:text-white">{product.name}</span>
      </nav>

      {/* Product Details */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16 mb-20">
        {/* Image Gallery */}
        <div className="space-y-4">
          <div className="relative aspect-square rounded-2xl overflow-hidden
                          bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/5">
            <Image
              src={product.images[selectedImage]}
              alt={product.name}
              fill
              className="object-cover"
              sizes="(max-width: 1024px) 100vw, 50vw"
              priority
            />
            {product.originalPrice && (
              <div className="absolute top-4 left-4 px-3 py-1.5 rounded-lg
                              bg-gradient-to-r from-neon-pink to-neon-purple
                              text-white text-sm font-bold">
                Save {formatPrice(product.originalPrice - product.price)}
              </div>
            )}
          </div>

          <div className="flex gap-3">
            {product.images.map((image, i) => (
              <button
                key={i}
                onClick={() => setSelectedImage(i)}
                className={`relative w-20 h-20 rounded-xl overflow-hidden
                            border-2 transition-all duration-200
                            ${
                              i === selectedImage
                                ? "border-brand-500 shadow-glow"
                                : "border-gray-200 dark:border-white/10 hover:border-gray-300 dark:hover:border-white/20"
                            }`}
              >
                <Image
                  src={image}
                  alt={`${product.name} ${i + 1}`}
                  fill
                  className="object-cover"
                  sizes="80px"
                />
              </button>
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <span className="px-3 py-1 rounded-lg text-xs font-medium
                             bg-brand-500/10 text-brand-500">
              {product.category}
            </span>
            {product.inStock && (
              <span className="px-3 py-1 rounded-lg text-xs font-medium
                               bg-green-500/10 text-green-500 flex items-center gap-1">
                <Check className="w-3 h-3" />
                In Stock
              </span>
            )}
          </div>

          <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            {product.name}
          </h1>

          <div className="flex items-center gap-3 mb-6">
            <div className="flex items-center gap-1">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-4 h-4 ${
                    i < Math.floor(product.rating)
                      ? "fill-amber-400 text-amber-400"
                      : "text-gray-300 dark:text-gray-600"
                  }`}
                />
              ))}
            </div>
            <span className="text-sm text-gray-500 dark:text-gray-400">
              {product.rating} ({product.reviews.toLocaleString()} reviews)
            </span>
          </div>

          <div className="flex items-baseline gap-3 mb-6">
            <span className="text-4xl font-bold text-gray-900 dark:text-white">
              {formatPrice(product.price)}
            </span>
            {product.originalPrice && (
              <span className="text-xl text-gray-400 line-through">
                {formatPrice(product.originalPrice)}
              </span>
            )}
          </div>

          <p className="text-gray-600 dark:text-gray-400 leading-relaxed mb-8">
            {product.longDescription}
          </p>

          {/* Features */}
          <div className="grid grid-cols-2 gap-3 mb-8">
            {product.features.map((feature) => (
              <div
                key={feature}
                className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400"
              >
                <div className="w-1.5 h-1.5 rounded-full bg-brand-500 shrink-0" />
                {feature}
              </div>
            ))}
          </div>

          {/* Quantity & Add to Cart */}
          <div className="flex flex-col sm:flex-row items-stretch gap-4 mb-8">
            <div className="flex items-center gap-3 px-4 py-3 rounded-xl
                            bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/10">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="p-1 rounded-lg hover:bg-gray-200 dark:hover:bg-white/10
                           transition-colors duration-200"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="w-10 text-center font-semibold text-gray-900 dark:text-white">
                {quantity}
              </span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="p-1 rounded-lg hover:bg-gray-200 dark:hover:bg-white/10
                           transition-colors duration-200"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            <button
              onClick={handleAddToCart}
              className={`flex-1 flex items-center justify-center gap-2 btn-primary text-base
                          ${isAdding ? "!bg-green-500" : ""}`}
            >
              <ShoppingCart className="w-5 h-5" />
              {isAdding ? "Added!" : "Add to Cart"}
            </button>
          </div>

          {/* Trust Badges */}
          <div className="grid grid-cols-3 gap-4 p-4 rounded-xl
                          bg-gray-50 dark:bg-white/[0.02] border border-gray-100 dark:border-white/5">
            <div className="flex flex-col items-center text-center gap-2">
              <Truck className="w-5 h-5 text-brand-500" />
              <span className="text-xs text-gray-500 dark:text-gray-400">Free Shipping</span>
            </div>
            <div className="flex flex-col items-center text-center gap-2">
              <Shield className="w-5 h-5 text-brand-500" />
              <span className="text-xs text-gray-500 dark:text-gray-400">2-Year Warranty</span>
            </div>
            <div className="flex flex-col items-center text-center gap-2">
              <RotateCcw className="w-5 h-5 text-brand-500" />
              <span className="text-xs text-gray-500 dark:text-gray-400">30-Day Returns</span>
            </div>
          </div>
        </div>
      </div>

      {/* Specifications */}
      <div className="mb-20">
        <h2 className="section-title mb-8">Specifications</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {product.specs.map((spec) => (
            <div
              key={spec.label}
              className="flex items-center justify-between p-4 rounded-xl
                         bg-gray-50 dark:bg-white/[0.02] border border-gray-100 dark:border-white/5"
            >
              <span className="text-sm text-gray-500 dark:text-gray-400">{spec.label}</span>
              <span className="text-sm font-semibold text-gray-900 dark:text-white">
                {spec.value}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Reviews */}
      <div className="mb-20">
        <h2 className="section-title mb-8">Customer Reviews</h2>
        <div className="space-y-4">
          {[
            {
              name: "Alex M.",
              rating: 5,
              date: "2 weeks ago",
              review: "Absolutely incredible product. The build quality is outstanding and it performs even better than expected. Highly recommended!",
            },
            {
              name: "Sarah K.",
              rating: 5,
              date: "1 month ago",
              review: "This exceeded all my expectations. The design is sleek and modern, and it works flawlessly. Worth every penny.",
            },
            {
              name: "James L.",
              rating: 4,
              date: "1 month ago",
              review: "Great product overall. Minor shipping delay but the product itself is top-notch. Would buy again.",
            },
          ].map((review, i) => (
            <div
              key={i}
              className="p-5 rounded-xl bg-gray-50 dark:bg-white/[0.02]
                         border border-gray-100 dark:border-white/5"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-brand-500 to-neon-purple
                                  flex items-center justify-center text-white text-sm font-bold">
                    {review.name[0]}
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-gray-900 dark:text-white">
                      {review.name}
                    </h4>
                    <div className="flex items-center gap-1">
                      {[...Array(5)].map((_, j) => (
                        <Star
                          key={j}
                          className={`w-3 h-3 ${
                            j < review.rating
                              ? "fill-amber-400 text-amber-400"
                              : "text-gray-300 dark:text-gray-600"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </div>
                <span className="text-xs text-gray-400">{review.date}</span>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                {review.review}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div>
          <h2 className="section-title mb-8">Related Products</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
