"use client";

import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, ShoppingBag, Minus, Plus, Trash2, ArrowRight } from "lucide-react";
import { useCart } from "@/lib/cart-context";
import { formatPrice } from "@/lib/products";

export default function CartPage() {
  const { items, removeItem, updateQuantity, totalItems, totalPrice } = useCart();

  const shippingCost = totalPrice > 50 ? 0 : 9.99;
  const tax = totalPrice * 0.19;
  const grandTotal = totalPrice + shippingCost + tax;

  if (items.length === 0) {
    return (
      <div className="page-container">
        <div className="text-center py-20 animate-fade-in">
          <div className="w-24 h-24 rounded-2xl bg-gray-100 dark:bg-white/5
                          flex items-center justify-center mx-auto mb-6">
            <ShoppingBag className="w-12 h-12 text-gray-300 dark:text-gray-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Your cart is empty
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mb-8 max-w-md mx-auto">
            Looks like you haven&apos;t added any products yet. Start exploring our collection.
          </p>
          <Link href="/products" className="btn-primary inline-flex items-center gap-2">
            <ArrowLeft className="w-4 h-4" />
            Browse Products
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="mb-8">
        <h1 className="section-title">Shopping Cart</h1>
        <p className="section-subtitle">
          {totalItems} item{totalItems !== 1 ? "s" : ""} in your cart
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-4">
          {items.map((item) => (
            <div
              key={item.product.id}
              className="flex gap-4 sm:gap-6 p-4 sm:p-6 rounded-2xl
                         bg-white dark:bg-white/[0.02]
                         border border-gray-200 dark:border-white/5
                         animate-fade-in"
            >
              <Link
                href={`/products/${item.product.slug}`}
                className="relative w-24 h-24 sm:w-32 sm:h-32 rounded-xl overflow-hidden
                           bg-gray-200 dark:bg-white/5 shrink-0"
              >
                <Image
                  src={item.product.images[0]}
                  alt={item.product.name}
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-300"
                  sizes="128px"
                />
              </Link>

              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-4 mb-2">
                  <Link
                    href={`/products/${item.product.slug}`}
                    className="text-base sm:text-lg font-semibold text-gray-900 dark:text-white
                               hover:text-brand-500 dark:hover:text-brand-400
                               transition-colors duration-200 line-clamp-1"
                  >
                    {item.product.name}
                  </Link>
                  <button
                    onClick={() => removeItem(item.product.id)}
                    className="p-2 rounded-lg text-gray-400 hover:text-red-500
                               hover:bg-red-50 dark:hover:bg-red-500/10
                               transition-all duration-200 shrink-0"
                    aria-label="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <p className="text-sm text-gray-500 dark:text-gray-400 mb-4 line-clamp-1">
                  {item.product.description}
                </p>

                <div className="flex items-end justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1 rounded-xl
                                    bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/10">
                      <button
                        onClick={() =>
                          updateQuantity(item.product.id, item.quantity - 1)
                        }
                        className="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-white/10
                                   transition-colors duration-200"
                        aria-label="Decrease quantity"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="w-10 text-center text-sm font-semibold
                                       text-gray-900 dark:text-white">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() =>
                          updateQuantity(item.product.id, item.quantity + 1)
                        }
                        className="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-white/10
                                   transition-colors duration-200"
                        aria-label="Increase quantity"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="text-right">
                    <p className="text-lg font-bold text-gray-900 dark:text-white">
                      {formatPrice(item.product.price * item.quantity)}
                    </p>
                    {item.quantity > 1 && (
                      <p className="text-xs text-gray-400">
                        {formatPrice(item.product.price)} each
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}

          <Link
            href="/products"
            className="inline-flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400
                       hover:text-brand-500 transition-colors duration-200 mt-4"
          >
            <ArrowLeft className="w-4 h-4" />
            Continue Shopping
          </Link>
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="sticky top-24 p-6 rounded-2xl glass">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">
              Order Summary
            </h3>

            <div className="space-y-4 mb-6">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500 dark:text-gray-400">
                  Subtotal ({totalItems} items)
                </span>
                <span className="text-gray-900 dark:text-white font-medium">
                  {formatPrice(totalPrice)}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500 dark:text-gray-400">Shipping</span>
                <span className="text-gray-900 dark:text-white font-medium">
                  {shippingCost === 0 ? (
                    <span className="text-green-500">Free</span>
                  ) : (
                    formatPrice(shippingCost)
                  )}
                </span>
              </div>
              {shippingCost > 0 && (
                <p className="text-xs text-gray-400 dark:text-gray-500">
                  Free shipping on orders over €50
                </p>
              )}
              <div className="flex justify-between text-sm">
                <span className="text-gray-500 dark:text-gray-400">Tax (19%)</span>
                <span className="text-gray-900 dark:text-white font-medium">
                  {formatPrice(tax)}
                </span>
              </div>

              <div className="pt-4 border-t border-gray-200 dark:border-white/10">
                <div className="flex justify-between">
                  <span className="text-base font-semibold text-gray-900 dark:text-white">
                    Total
                  </span>
                  <span className="text-xl font-bold gradient-text">
                    {formatPrice(grandTotal)}
                  </span>
                </div>
              </div>
            </div>

            <Link
              href="/checkout"
              className="btn-primary w-full flex items-center justify-center gap-2"
            >
              Proceed to Checkout
              <ArrowRight className="w-4 h-4" />
            </Link>

            <div className="mt-4 p-3 rounded-xl bg-gray-50 dark:bg-white/[0.02]
                            border border-gray-100 dark:border-white/5">
              <p className="text-xs text-center text-gray-400 dark:text-gray-500">
                Secure checkout powered by Stripe
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
