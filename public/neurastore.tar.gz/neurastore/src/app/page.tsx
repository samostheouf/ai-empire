"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowRight, Sparkles, Shield, Truck, RotateCcw, Zap } from "lucide-react";
import ProductCard from "@/components/ProductCard";
import { products } from "@/lib/products";

const featuredProducts = products.slice(0, 8);

const features = [
  {
    icon: Truck,
    title: "Free Shipping",
    description: "On orders over €50",
  },
  {
    icon: Shield,
    title: "2-Year Warranty",
    description: "Full manufacturer coverage",
  },
  {
    icon: RotateCcw,
    title: "30-Day Returns",
    description: "Hassle-free returns",
  },
  {
    icon: Zap,
    title: "Same-Day Dispatch",
    description: "Order before 2pm",
  },
];

export default function HomePage() {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail("");
    }
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-dark" />
        <div className="absolute top-20 left-10 w-72 h-72 rounded-full
                        bg-brand-500/20 blur-[100px] animate-float" />
        <div className="absolute bottom-20 right-10 w-96 h-96 rounded-full
                        bg-neon-purple/20 blur-[120px] animate-float"
             style={{ animationDelay: "2s" }} />
        <div className="absolute top-40 right-1/3 w-64 h-64 rounded-full
                        bg-neon-pink/10 blur-[80px] animate-float"
             style={{ animationDelay: "4s" }} />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 sm:py-32 lg:py-40">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full
                            bg-brand-500/10 border border-brand-500/20 mb-8
                            animate-fade-in">
              <Sparkles className="w-4 h-4 text-brand-400" />
              <span className="text-sm font-medium text-brand-400">
                New Collection 2024
              </span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold
                           text-white mb-6 leading-tight animate-slide-up">
              Technology
              <br />
              <span className="gradient-text animate-gradient bg-[length:200%_200%]">
                Redefined
              </span>
            </h1>

            <p className="text-lg sm:text-xl text-gray-400 mb-10 max-w-2xl mx-auto
                          leading-relaxed animate-slide-up"
               style={{ animationDelay: "0.1s" }}>
              Discover premium tech products engineered for the future.
              Elevate your everyday with cutting-edge innovation.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4
                            animate-slide-up"
                 style={{ animationDelay: "0.2s" }}>
              <Link href="/products" className="btn-primary flex items-center gap-2 text-base">
                Explore Products
                <ArrowRight className="w-5 h-5" />
              </Link>
              <Link href="/products?category=Audio" className="btn-secondary text-base">
                Shop Audio
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Bar */}
      <section className="border-y border-gray-200 dark:border-white/5
                          bg-gray-50 dark:bg-black/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 divide-x divide-gray-200 dark:divide-white/5">
            {features.map((feature) => (
              <div key={feature.title} className="py-8 px-6 text-center">
                <feature.icon className="w-6 h-6 text-brand-500 mx-auto mb-3" />
                <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-1">
                  {feature.title}
                </h3>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 sm:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 mb-12">
            <div>
              <h2 className="section-title">Featured Products</h2>
              <p className="section-subtitle">
                Handpicked products that combine design, performance, and value.
              </p>
            </div>
            <Link
              href="/products"
              className="flex items-center gap-2 text-sm font-medium text-brand-500
                         hover:text-brand-600 transition-colors duration-200"
            >
              View All
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-20 sm:py-28 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-brand opacity-5" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px]
                        rounded-full bg-brand-500/10 blur-[150px]" />

        <div className="relative max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="section-title mb-4">Stay in the Loop</h2>
          <p className="section-subtitle mx-auto mb-8">
            Subscribe to our newsletter for exclusive deals, new product launches, and tech insights.
          </p>

          {subscribed ? (
            <div className="inline-flex items-center gap-2 px-6 py-3 rounded-xl
                            bg-green-500/10 border border-green-500/20 text-green-500
                            font-medium animate-fade-in">
              <Sparkles className="w-5 h-5" />
              Thanks for subscribing!
            </div>
          ) : (
            <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                required
                className="input-field flex-1"
              />
              <button type="submit" className="btn-primary whitespace-nowrap">
                Subscribe
              </button>
            </form>
          )}
        </div>
      </section>
    </div>
  );
}
