# NeuraAPI AI Agents Pro

A production-ready **Next.js 14** template for building AI agent chat experiences with streaming responses, multi-agent orchestration, and a modern dark-mode UI.

**Price: 49€** (downloadable template sold on NeuraAPI)

## Features

- Next.js 14 App Router + TypeScript
- Tailwind CSS 3.4 with dark mode
- Streaming chat via Server-Sent Events (SSE)
- Multi-agent list with create endpoint
- API key configuration page (localStorage)
- Responsive, gradient-accented modern UI
- lucide-react icons
- Mock LLM responses (swap in real provider)

## Pages

- `/` — Landing hero + features
- `/chat` — Chat interface with streaming
- `/agents` — List of agents (+ create)
- `/settings` — API key config

## API routes

- `POST /api/chat` — streams LLM response via SSE
- `GET /api/agents` — list agents
- `POST /api/agents` — create agent

## Getting started

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Environment

Copy `.env.example` to `.env.local` and fill in keys (optional — mock mode works without keys):

```bash
cp .env.example .env.local
```

## Deploy

```bash
npm run build
npm start
```

Or deploy to Vercel: `vercel`.

## Customizing

- Edit `src/lib/agents.ts` for agent definitions.
- Replace mock logic in `src/app/api/chat/route.ts` with a real LLM SDK call.
- Styling via `tailwind.config.ts` and `src/app/globals.css`.

## License

MIT — use in commercial projects.