"use client";

import { useEffect, useState } from "react";
import { Key, CheckCircle2, Eye, EyeOff, Save } from "lucide-react";

const PROVIDERS = [
  { id: "openai", label: "OpenAI", placeholder: "sk-..." },
  { id: "anthropic", label: "Anthropic", placeholder: "sk-ant-..." },
  { id: "google", label: "Google Gemini", placeholder: "AIza..." },
  { id: "mistral", label: "Mistral", placeholder: "..." },
];

export default function SettingsPage() {
  const [provider, setProvider] = useState("openai");
  const [apiKey, setApiKey] = useState("");
  const [show, setShow] = useState(false);
  const [saved, setSaved] = useState(false);
  const [model, setModel] = useState("gpt-4o-mini");
  const [temperature, setTemperature] = useState(0.7);

  useEffect(() => {
    try {
      const stored = localStorage.getItem("neuraapi.settings");
      if (stored) {
        const parsed = JSON.parse(stored);
        setProvider(parsed.provider ?? "openai");
        setApiKey(parsed.apiKey ?? "");
        setModel(parsed.model ?? "gpt-4o-mini");
        setTemperature(parsed.temperature ?? 0.7);
      }
    } catch {}
  }, []);

  const save = () => {
    localStorage.setItem(
      "neuraapi.settings",
      JSON.stringify({ provider, apiKey, model, temperature })
    );
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const placeholder = PROVIDERS.find((p) => p.id === provider)?.placeholder ?? "";

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-1">Settings</h1>
      <p className="text-gray-600 dark:text-gray-400 mb-8">
        Configure your LLM provider and API key. Stored locally in your browser.
      </p>

      <div className="rounded-2xl p-6 bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Provider
          </label>
          <select
            value={provider}
            onChange={(e) => setProvider(e.target.value)}
            className="input-field"
          >
            {PROVIDERS.map((p) => (
              <option key={p.id} value={p.id}>
                {p.label}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            API Key
          </label>
          <div className="relative">
            <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type={show ? "text" : "password"}
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder={placeholder}
              className="input-field pl-10 pr-10"
            />
            <button
              type="button"
              onClick={() => setShow((s) => !s)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
              aria-label="Toggle visibility"
            >
              {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
            Never committed to source. Stored in localStorage only.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Default model
            </label>
            <input
              value={model}
              onChange={(e) => setModel(e.target.value)}
              className="input-field"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Temperature ({temperature.toFixed(2)})
            </label>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={temperature}
              onChange={(e) => setTemperature(parseFloat(e.target.value))}
              className="w-full accent-brand-500"
            />
          </div>
        </div>

        <div className="flex items-center gap-3 pt-2">
          <button onClick={save} className="btn-primary inline-flex items-center gap-2">
            <Save className="w-4 h-4" /> Save settings
          </button>
          {saved && (
            <span className="inline-flex items-center gap-1.5 text-sm text-emerald-500">
              <CheckCircle2 className="w-4 h-4" /> Saved
            </span>
          )}
        </div>
      </div>

      <div className="mt-8 rounded-2xl p-6 bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Environment variables</h2>
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
          For server-side routes, set these in <code className="px-1.5 py-0.5 rounded bg-gray-100 dark:bg-white/10">.env.local</code>:
        </p>
        <pre className="text-xs bg-gray-100 dark:bg-black/40 rounded-xl p-4 overflow-x-auto text-gray-800 dark:text-gray-200">
{`OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
NEXT_PUBLIC_APP_URL=http://localhost:3000`}
        </pre>
      </div>
    </div>
  );
}