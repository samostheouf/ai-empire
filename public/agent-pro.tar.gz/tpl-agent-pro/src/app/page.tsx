import Link from "next/link";
import { Bot, Zap, Shield, Rocket, Sparkles, ArrowRight } from "lucide-react";

const features = [
  {
    icon: Zap,
    title: "Streaming Chat",
    desc: "Token-by-token SSE streaming for instant, responsive conversations.",
  },
  {
    icon: Bot,
    title: "Multi-Agent",
    desc: "Switch between specialized agents: researcher, coder, writer, analyst.",
  },
  {
    icon: Sparkles,
    title: "Tool Calling",
    desc: "Extensible tool layer for web search, code execution, and data analysis.",
  },
  {
    icon: Shield,
    title: "API Key Config",
    desc: "Secure client-side settings with masked keys and provider selection.",
  },
  {
    icon: Rocket,
    title: "Production Ready",
    desc: "Next.js 14 App Router, TypeScript, Tailwind, dark mode out of the box.",
  },
  {
    icon: ArrowRight,
    title: "Deploy Anywhere",
    desc: "One-click deploy to Vercel, Docker, or any Node host.",
  },
];

export default function Home() {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-dark opacity-60 dark:opacity-100" />
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-brand-500/20 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-neon-pink/20 rounded-full blur-3xl" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 sm:py-32 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-brand-500/10 border border-brand-500/20 text-brand-600 dark:text-brand-300 text-sm font-medium mb-6">
            <Sparkles className="w-4 h-4" />
            NeuraAPI AI Agents Pro — Template
          </div>
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold tracking-tight mb-6">
            Build <span className="gradient-text">AI Agents</span>
            <br /> that actually ship
          </h1>
          <p className="max-w-2xl mx-auto text-lg sm:text-xl text-gray-600 dark:text-gray-300 mb-10">
            A complete Next.js 14 template with streaming chat, multi-agent orchestration,
            and a modern UI. Download, customize, deploy in minutes.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/chat" className="btn-primary inline-flex items-center gap-2">
              Try the chat <ArrowRight className="w-4 h-4" />
            </Link>
            <Link href="/agents" className="btn-secondary inline-flex items-center gap-2">
              Browse agents
            </Link>
          </div>

          <div className="mt-16 grid grid-cols-2 sm:grid-cols-4 gap-6 max-w-3xl mx-auto">
            {[
              { label: "Agents", value: "6+" },
              { label: "Streaming", value: "SSE" },
              { label: "TypeScript", value: "100%" },
              { label: "Price", value: "49€" },
            ].map((s) => (
              <div key={s.label} className="text-center">
                <div className="text-3xl font-bold gradient-text">{s.value}</div>
                <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold mb-3">Everything you need</h2>
          <p className="text-gray-600 dark:text-gray-400 max-w-xl mx-auto">
            Production-grade building blocks, wired together and ready to customize.
          </p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((f) => (
            <div
              key={f.title}
              className="rounded-2xl p-6 bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10
                         hover:border-brand-400/50 hover:shadow-glow transition-all duration-300"
            >
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-brand-500 to-neon-purple flex items-center justify-center mb-4 shadow-glow">
                <f.icon className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">{f.title}</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="rounded-3xl p-10 sm:p-16 text-center bg-gradient-to-br from-brand-500 via-neon-purple to-neon-pink relative overflow-hidden">
          <div className="absolute inset-0 bg-black/10" />
          <div className="relative">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Ready to build?</h2>
            <p className="text-white/80 max-w-xl mx-auto mb-8">
              Clone the template, drop in your API key, and start shipping AI agents today.
            </p>
            <Link
              href="/settings"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white text-brand-600 font-semibold hover:scale-105 transition-all"
            >
              Configure API key <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}