"use client";

import { Suspense, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Bot, Loader2 } from "lucide-react";
import Sidebar, { type Conversation } from "@/components/Sidebar";
import ChatMessage, { type Message } from "@/components/ChatMessage";
import ChatInput from "@/components/ChatInput";
import { streamChat } from "@/lib/chat-client";
import { agents } from "@/lib/agents";
import { generateId } from "@/lib/utils";

function ChatPageInner() {
  const searchParams = useSearchParams();
  const agentId = searchParams.get("agent") ?? undefined;

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string | undefined>();
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const selectedAgent = agentId ? agents.find((a) => a.id === agentId) : undefined;

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const handleNew = () => {
    const id = generateId();
    const conv: Conversation = {
      id,
      title: "New conversation",
      agentId,
      updatedAt: Date.now(),
    };
    setConversations((prev) => [conv, ...prev]);
    setActiveId(id);
    setMessages([]);
  };

  const handleSelect = (id: string) => {
    setActiveId(id);
    // For demo, reset messages when switching (mock persistence)
    setMessages([]);
  };

  const handleDelete = (id: string) => {
    setConversations((prev) => prev.filter((c) => c.id !== id));
    if (activeId === id) {
      setActiveId(undefined);
      setMessages([]);
    }
  };

  const handleSend = async (text: string) => {
    const userMsg: Message = { id: generateId(), role: "user", content: text, timestamp: Date.now() };
    setMessages((prev) => [...prev, userMsg]);

    // ensure conversation exists
    if (!activeId) {
      const id = generateId();
      setConversations((prev) => [{ id, title: text.slice(0, 40), agentId, updatedAt: Date.now() }, ...prev]);
      setActiveId(id);
    } else {
      setConversations((prev) =>
        prev.map((c) => (c.id === activeId ? { ...c, title: c.title === "New conversation" ? text.slice(0, 40) : c.title, updatedAt: Date.now() } : c))
      );
    }

    const assistantMsg: Message = { id: generateId(), role: "assistant", content: "", timestamp: Date.now() };
    setMessages((prev) => [...prev, assistantMsg]);

    setLoading(true);
    const controller = new AbortController();
    abortRef.current = controller;

    const history = [...messages, userMsg].map((m) => ({ role: m.role, content: m.content }));

    await streamChat(
      history,
      { agentId, signal: controller.signal },
      {
        onToken: (token) => {
          setMessages((prev) =>
            prev.map((m) => (m.id === assistantMsg.id ? { ...m, content: m.content + token } : m))
          );
        },
        onDone: () => {
          setLoading(false);
          abortRef.current = null;
        },
        onError: (err) => {
          setMessages((prev) =>
            prev.map((m) =>
              m.id === assistantMsg.id ? { ...m, content: `Error: ${err.message}` } : m
            )
          );
          setLoading(false);
          abortRef.current = null;
        },
      }
    );
  };

  const handleStop = () => {
    abortRef.current?.abort();
    setLoading(false);
  };

  return (
    <div className="flex h-[calc(100vh-4rem)] sm:h-[calc(100vh-5rem)]">
      <div className="hidden md:block">
        <Sidebar
          conversations={conversations}
          activeId={activeId}
          onSelect={handleSelect}
          onNew={handleNew}
          onDelete={handleDelete}
        />
      </div>

      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-gray-200 dark:border-white/10 bg-white/60 dark:bg-black/20 backdrop-blur">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-brand-500 to-neon-purple flex items-center justify-center">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="text-sm font-semibold text-gray-900 dark:text-white">
              {selectedAgent ? selectedAgent.name : "NeuraAPI Agent"}
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400">
              {selectedAgent ? selectedAgent.description : "Streaming chat · mock responses"}
            </div>
          </div>
          {loading && <Loader2 className="w-4 h-4 animate-spin text-brand-500 ml-auto" />}
        </div>

        {/* Messages */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-6">
          <div className="max-w-3xl mx-auto space-y-6">
            {messages.length === 0 && (
              <div className="text-center py-20">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-brand-500 to-neon-purple mx-auto mb-4 flex items-center justify-center shadow-glow">
                  <Bot className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Start a conversation</h2>
                <p className="text-sm text-gray-500 dark:text-gray-400 max-w-md mx-auto">
                  Type a message below. Responses stream token-by-token from the mock API.
                </p>
              </div>
            )}
            {messages.map((m) => (
              <ChatMessage key={m.id} message={m} />
            ))}
          </div>
        </div>

        <ChatInput onSend={handleSend} onStop={handleStop} loading={loading} />
      </div>
    </div>
  );
}

export default function ChatPage() {
  return (
    <Suspense fallback={<div className="p-8 text-center text-gray-500">Loading chat…</div>}>
      <ChatPageInner />
    </Suspense>
  );
}