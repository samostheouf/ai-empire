import { NextRequest } from "next/server";
import { agents } from "@/lib/agents";

export const runtime = "nodejs";

type ChatBody = {
  messages?: { role: string; content: string }[];
  agentId?: string;
};

const MOCK_RESPONSES: string[] = [
  "Hello! I'm your NeuraAPI agent. I can help with research, coding, writing, and analysis. What would you like to explore today?",
  "Great question. Let me break that down for you step by step.\n\n1. First, understand the problem space.\n2. Then identify the key constraints.\n3. Finally, propose a solution with trade-offs.",
  "Here's a quick code snippet to get you started:\n\n```ts\nconst result = await agent.run({ task: 'summarize', input });\nconsole.log(result);\n```",
  "I've analyzed your request. The main insight is that streaming responses improve perceived latency by ~40%. Would you like me to elaborate on the architecture?",
];

function pickResponse(messages: { role: string; content: string }[]): string {
  const last = messages[messages.length - 1]?.content?.toLowerCase() ?? "";
  if (last.includes("code") || last.includes("function")) return MOCK_RESPONSES[2];
  if (last.includes("analyze") || last.includes("data")) return MOCK_RESPONSES[3];
  if (last.includes("hello") || last.includes("hi")) return MOCK_RESPONSES[0];
  return MOCK_RESPONSES[1];
}

export async function POST(req: NextRequest) {
  let body: ChatBody;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON body" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  const messages = body.messages ?? [];
  if (!Array.isArray(messages)) {
    return new Response(JSON.stringify({ error: "messages must be an array" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  const text = pickResponse(messages);
  const agent = body.agentId ? agents.find((a) => a.id === body.agentId) : undefined;
  const prefix = agent ? `[${agent.name}] ` : "";

  const stream = new ReadableStream({
    async start(controller) {
      const encoder = new TextEncoder();
      const send = (data: unknown) => {
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}\n\n`));
      };

      const full = prefix + text;
      // Simulate streaming token-by-token
      const tokens = full.split(/(\s+)/);
      for (const token of tokens) {
        if (req.signal.aborted) break;
        send({ token });
        await new Promise((r) => setTimeout(r, 35));
      }
      send({ done: true });
      controller.enqueue(encoder.encode("data: [DONE]\n\n"));
      controller.close();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}