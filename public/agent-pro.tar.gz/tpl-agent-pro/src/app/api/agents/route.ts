import { NextRequest, NextResponse } from "next/server";
import { agents, type Agent } from "@/lib/agents";

export const runtime = "nodejs";

// In-memory store for created agents (resets on server restart)
const created: Agent[] = [];

export async function GET() {
  return NextResponse.json({ agents: [...agents, ...created] });
}

export async function POST(req: NextRequest) {
  let body: Partial<Agent>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  if (!body.name || !body.description) {
    return NextResponse.json(
      { error: "name and description are required" },
      { status: 400 }
    );
  }

  const agent: Agent = {
    id: body.id ?? `agent-${Date.now()}`,
    name: body.name,
    description: body.description,
    model: body.model ?? "gpt-4o-mini",
    tools: body.tools ?? [],
    avatar: body.avatar ?? body.name.charAt(0).toUpperCase(),
    color: body.color ?? "from-brand-500 to-neon-purple",
    status: body.status ?? "online",
  };

  created.push(agent);
  return NextResponse.json({ agent }, { status: 201 });
}