export type ChatMessage = {
  role: "user" | "assistant" | "system";
  content: string;
};

export type StreamHandlers = {
  onToken: (token: string) => void;
  onDone?: () => void;
  onError?: (err: Error) => void;
};

export async function streamChat(
  messages: ChatMessage[],
  options: { agentId?: string; signal?: AbortSignal } = {},
  handlers: StreamHandlers
): Promise<void> {
  const res = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ messages, agentId: options.agentId }),
    signal: options.signal,
  });

  if (!res.ok || !res.body) {
    const text = await res.text().catch(() => "");
    handlers.onError?.(new Error(text || `Request failed: ${res.status}`));
    return;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("data:")) continue;
        const payload = trimmed.slice(5).trim();
        if (payload === "[DONE]") {
          handlers.onDone?.();
          return;
        }
        try {
          const json = JSON.parse(payload);
          if (json.error) {
            handlers.onError?.(new Error(json.error));
            return;
          }
          if (json.token) handlers.onToken(json.token);
          if (json.content) handlers.onToken(json.content);
        } catch {
          // ignore non-JSON chunks
        }
      }
    }
    handlers.onDone?.();
  } catch (err) {
    if ((err as Error).name !== "AbortError") {
      handlers.onError?.(err as Error);
    }
  }
}