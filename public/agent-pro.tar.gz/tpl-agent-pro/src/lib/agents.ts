export type Agent = {
  id: string;
  name: string;
  description: string;
  model: string;
  tools: string[];
  avatar: string;
  color: string;
  status: "online" | "busy" | "offline";
};

export const agents: Agent[] = [
  {
    id: "researcher",
    name: "Researcher",
    description: "Deep web research, source synthesis, and citation-ready summaries.",
    model: "gpt-4o",
    tools: ["web_search", "web_extract", "summarize"],
    avatar: "R",
    color: "from-blue-500 to-cyan-400",
    status: "online",
  },
  {
    id: "coder",
    name: "Coder",
    description: "Writes, refactors, and reviews code across multiple languages.",
    model: "gpt-4o",
    tools: ["code_gen", "lint", "test"],
    avatar: "C",
    color: "from-emerald-500 to-teal-400",
    status: "online",
  },
  {
    id: "writer",
    name: "Writer",
    description: "Long-form content, marketing copy, and tone adaptation.",
    model: "gpt-4o-mini",
    tools: ["draft", "rewrite", "seo"],
    avatar: "W",
    color: "from-purple-500 to-pink-400",
    status: "online",
  },
  {
    id: "analyst",
    name: "Analyst",
    description: "Data analysis, charts, and business insights from CSV/JSON.",
    model: "gpt-4o",
    tools: ["parse_csv", "chart", "sql"],
    avatar: "A",
    color: "from-amber-500 to-orange-400",
    status: "busy",
  },
  {
    id: "support",
    name: "Support",
    description: "Customer support triage, ticket routing, and FAQ answers.",
    model: "gpt-4o-mini",
    tools: ["classify", "reply", "escalate"],
    avatar: "S",
    color: "from-rose-500 to-red-400",
    status: "online",
  },
  {
    id: "planner",
    name: "Planner",
    description: "Project planning, task breakdown, and milestone scheduling.",
    model: "gpt-4o",
    tools: ["plan", "schedule", "estimate"],
    avatar: "P",
    color: "from-indigo-500 to-violet-400",
    status: "offline",
  },
];

export function getAgent(id: string): Agent | undefined {
  return agents.find((a) => a.id === id);
}

export function listAgents(): Agent[] {
  return agents;
}