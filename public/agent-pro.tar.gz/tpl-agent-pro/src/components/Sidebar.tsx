"use client";

import { useState } from "react";
import Link from "next/link";
import { Bot, Plus, MessageSquare, Trash2, ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

export type Conversation = {
  id: string;
  title: string;
  agentId?: string;
  updatedAt: number;
};

type Props = {
  conversations: Conversation[];
  activeId?: string;
  onSelect: (id: string) => void;
  onNew: () => void;
  onDelete: (id: string) => void;
};

export default function Sidebar({ conversations, activeId, onSelect, onNew, onDelete }: Props) {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <aside
      className={cn(
        "h-full flex flex-col border-r border-gray-200 dark:border-white/10 bg-gray-50 dark:bg-black/20 transition-all duration-300",
        collapsed ? "w-16" : "w-72"
      )}
    >
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-white/10">
        {!collapsed && (
          <span className="text-sm font-semibold text-gray-900 dark:text-white">Conversations</span>
        )}
        <button
          onClick={() => setCollapsed((c) => !c)}
          className="p-1.5 rounded-lg hover:bg-gray-200 dark:hover:bg-white/10 text-gray-500 dark:text-gray-400"
          aria-label="Toggle sidebar"
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      <div className="p-3">
        <button
          onClick={onNew}
          className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl
                     bg-gradient-to-r from-brand-500 to-neon-purple text-white text-sm font-medium
                     shadow-glow hover:scale-[1.02] transition-all"
        >
          <Plus className="w-4 h-4" />
          {!collapsed && "New chat"}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-2 py-2 space-y-1">
        {conversations.length === 0 && !collapsed && (
          <p className="text-xs text-gray-500 dark:text-gray-400 text-center py-6">
            No conversations yet
          </p>
        )}
        {conversations.map((c) => (
          <div
            key={c.id}
            onClick={() => onSelect(c.id)}
            className={cn(
              "group flex items-center gap-2 px-3 py-2.5 rounded-xl cursor-pointer transition-all",
              activeId === c.id
                ? "bg-brand-500/10 text-brand-600 dark:text-brand-300"
                : "hover:bg-gray-200 dark:hover:bg-white/5 text-gray-700 dark:text-gray-300"
            )}
          >
            <MessageSquare className="w-4 h-4 shrink-0" />
            {!collapsed && (
              <>
                <span className="flex-1 truncate text-sm">{c.title}</span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete(c.id);
                  }}
                  className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-red-500/10 text-gray-400 hover:text-red-500 transition-all"
                  aria-label="Delete conversation"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </>
            )}
          </div>
        ))}
      </div>

      <div className="p-3 border-t border-gray-200 dark:border-white/10">
        <Link
          href="/agents"
          className="flex items-center gap-2 px-3 py-2 rounded-xl text-sm text-gray-600 dark:text-gray-400
                     hover:bg-gray-200 dark:hover:bg-white/5 transition-all"
        >
          <Bot className="w-4 h-4" />
          {!collapsed && "Browse agents"}
        </Link>
      </div>
    </aside>
  );
}