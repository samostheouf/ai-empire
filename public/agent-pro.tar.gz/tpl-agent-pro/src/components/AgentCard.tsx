"use client";

import Link from "next/link";
import { Bot, Zap } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Agent } from "@/lib/agents";

type Props = {
  agent: Agent;
  onSelect?: (agent: Agent) => void;
};

const statusColor: Record<Agent["status"], string> = {
  online: "bg-emerald-400",
  busy: "bg-amber-400",
  offline: "bg-gray-400",
};

export default function AgentCard({ agent, onSelect }: Props) {
  return (
    <div
      onClick={() => onSelect?.(agent)}
      className="group relative rounded-2xl p-6 bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10
                 hover:border-brand-400/50 hover:shadow-glow transition-all duration-300 cursor-pointer overflow-hidden"
    >
      <div className="absolute inset-0 bg-gradient-card opacity-0 group-hover:opacity-100 transition-opacity" />
      <div className="relative">
        <div className="flex items-center justify-between mb-4">
          <div
            className={cn(
              "w-12 h-12 rounded-xl bg-gradient-to-br flex items-center justify-center text-white font-bold text-lg shadow-glow",
              agent.color
            )}
          >
            {agent.avatar}
          </div>
          <span className="flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400">
            <span className={cn("w-2 h-2 rounded-full", statusColor[agent.status])} />
            {agent.status}
          </span>
        </div>

        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">{agent.name}</h3>
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4 leading-relaxed">
          {agent.description}
        </p>

        <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400 mb-4">
          <Zap className="w-3.5 h-3.5" />
          <span>{agent.model}</span>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {agent.tools.map((t) => (
            <span
              key={t}
              className="px-2 py-0.5 rounded-md text-[11px] font-medium bg-brand-500/10 text-brand-600 dark:text-brand-300 border border-brand-500/20"
            >
              {t}
            </span>
          ))}
        </div>

        <div className="mt-5 flex items-center justify-between">
          <Link
            href={`/chat?agent=${agent.id}`}
            className="text-sm font-medium text-brand-500 dark:text-brand-400 hover:text-brand-600 dark:hover:text-brand-300"
          >
            Open chat →
          </Link>
          <Bot className="w-4 h-4 text-gray-400 group-hover:text-brand-400 transition-colors" />
        </div>
      </div>
    </div>
  );
}