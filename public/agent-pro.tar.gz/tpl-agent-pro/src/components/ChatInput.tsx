"use client";

import { useState, KeyboardEvent } from "react";
import { Send, Square } from "lucide-react";

type Props = {
  onSend: (text: string) => void;
  onStop?: () => void;
  loading?: boolean;
  disabled?: boolean;
};

export default function ChatInput({ onSend, onStop, loading, disabled }: Props) {
  const [value, setValue] = useState("");

  const submit = () => {
    const trimmed = value.trim();
    if (!trimmed || disabled) return;
    onSend(trimmed);
    setValue("");
  };

  const handleKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  };

  return (
    <div className="border-t border-gray-200 dark:border-white/10 bg-white/80 dark:bg-black/30 backdrop-blur-xl p-4">
      <div className="max-w-3xl mx-auto flex items-end gap-2">
        <textarea
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={handleKey}
          placeholder="Ask anything… (Enter to send, Shift+Enter for newline)"
          rows={1}
          disabled={disabled}
          className="input-field resize-none max-h-40"
        />
        {loading ? (
          <button
            onClick={onStop}
            className="shrink-0 w-11 h-11 rounded-xl bg-gray-200 dark:bg-white/10 flex items-center justify-center
                       hover:bg-gray-300 dark:hover:bg-white/20 transition-all"
            aria-label="Stop"
          >
            <Square className="w-5 h-5 text-gray-700 dark:text-gray-300" />
          </button>
        ) : (
          <button
            onClick={submit}
            disabled={!value.trim() || disabled}
            className="shrink-0 w-11 h-11 rounded-xl bg-gradient-to-br from-brand-500 to-neon-purple
                       flex items-center justify-center text-white shadow-glow
                       disabled:opacity-40 disabled:cursor-not-allowed hover:scale-105 transition-all"
            aria-label="Send"
          >
            <Send className="w-5 h-5" />
          </button>
        )}
      </div>
    </div>
  );
}